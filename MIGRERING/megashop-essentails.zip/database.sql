# WordPress MySQL database migration
#
# Generated: Friday 21. April 2023 12:03 UTC
# Hostname: localhost
# Database: `mega-shop`
# URL: //localhost/WP-Mega
# Path: C:\\MAMP\\htdocs\\WP-Mega
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users, wp_wc_admin_note_actions, wp_wc_admin_notes, wp_wc_category_lookup, wp_wc_customer_lookup, wp_wc_download_log, wp_wc_order_coupon_lookup, wp_wc_order_product_lookup, wp_wc_order_stats, wp_wc_order_tax_lookup, wp_wc_product_attributes_lookup, wp_wc_product_download_directories, wp_wc_product_meta_lookup, wp_wc_rate_limits, wp_wc_reserved_stock, wp_wc_tax_rate_classes, wp_wc_webhooks, wp_woocommerce_api_keys, wp_woocommerce_attribute_taxonomies, wp_woocommerce_downloadable_product_permissions, wp_woocommerce_log, wp_woocommerce_order_itemmeta, wp_woocommerce_order_items, wp_woocommerce_payment_tokenmeta, wp_woocommerce_payment_tokens, wp_woocommerce_sessions, wp_woocommerce_shipping_zone_locations, wp_woocommerce_shipping_zone_methods, wp_woocommerce_shipping_zones, wp_woocommerce_tax_rate_locations, wp_woocommerce_tax_rates
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, greet, page, post, product, product_variation, shop_coupon, shop_order, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `args` varchar(191) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `schedule` longtext COLLATE utf8mb4_unicode_520_ci,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `attempts` int(11) NOT NULL DEFAULT '0',
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `extended_args` varchar(8000) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook` (`hook`),
  KEY `status` (`status`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=224 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(6, 'action_scheduler/migration_hook', 'complete', '2023-04-20 09:45:06', '2023-04-20 11:45:06', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681983906;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681983906;s:19:"scheduled_timestamp";i:1681983906;s:9:"timestamp";i:1681983906;}', 1, 1, '2023-04-20 09:45:11', '2023-04-20 11:45:11', 0, NULL),
(7, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-20 09:44:08', '2023-04-20 11:44:08', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1681983848;s:18:"\0*\0first_timestamp";i:1681983848;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1681983848;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1681983848;s:15:"first_timestamp";i:1681983848;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1681983848;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-20 09:45:11', '2023-04-20 11:45:11', 0, NULL),
(8, 'woocommerce_cleanup_draft_orders', 'complete', '2023-04-21 09:45:11', '2023-04-21 11:45:11', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682070311;s:18:"\0*\0first_timestamp";i:1681983848;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682070311;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682070311;s:15:"first_timestamp";i:1681983848;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682070311;s:19:"interval_in_seconds";i:86400;}', 0, 1, '2023-04-21 09:57:55', '2023-04-21 11:57:55', 0, NULL),
(9, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:03:46', '2023-04-20 12:03:46', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985026;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985026;s:19:"scheduled_timestamp";i:1681985026;s:9:"timestamp";i:1681985026;}', 2, 1, '2023-04-20 10:03:48', '2023-04-20 12:03:48', 0, NULL),
(10, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:04:11', '2023-04-20 12:04:11', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985051;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985051;s:19:"scheduled_timestamp";i:1681985051;s:9:"timestamp";i:1681985051;}', 2, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(11, 'woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications', 'failed', '2023-04-20 10:04:14', '2023-04-20 10:04:14', '[]', 'O:28:"ActionScheduler_NullSchedule":0:{}', 0, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(12, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:04:45', '2023-04-20 12:04:45', '[14,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985085;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985085;s:19:"scheduled_timestamp";i:1681985085;s:9:"timestamp";i:1681985085;}', 2, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(13, 'adjust_download_permissions', 'complete', '2023-04-20 10:04:46', '2023-04-20 12:04:46', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985086;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985086;s:19:"scheduled_timestamp";i:1681985086;s:9:"timestamp";i:1681985086;}', 0, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(14, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:04:46', '2023-04-20 12:04:46', '[13,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985086;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985086;s:19:"scheduled_timestamp";i:1681985086;s:9:"timestamp";i:1681985086;}', 2, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(15, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:04:58', '2023-04-20 12:04:58', '[14,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985098;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985098;s:19:"scheduled_timestamp";i:1681985098;s:9:"timestamp";i:1681985098;}', 2, 1, '2023-04-20 10:04:58', '2023-04-20 12:04:58', 0, NULL),
(16, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:04', '2023-04-20 12:05:04', '[14,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985104;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985104;s:19:"scheduled_timestamp";i:1681985104;s:9:"timestamp";i:1681985104;}', 2, 1, '2023-04-20 10:05:18', '2023-04-20 12:05:18', 0, NULL),
(17, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:04', '2023-04-20 12:05:04', '[13,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985104;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985104;s:19:"scheduled_timestamp";i:1681985104;s:9:"timestamp";i:1681985104;}', 2, 1, '2023-04-20 10:05:18', '2023-04-20 12:05:18', 0, NULL),
(18, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:19', '2023-04-20 12:05:19', '[15,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985119;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985119;s:19:"scheduled_timestamp";i:1681985119;s:9:"timestamp";i:1681985119;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(19, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:19', '2023-04-20 12:05:19', '[16,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985119;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985119;s:19:"scheduled_timestamp";i:1681985119;s:9:"timestamp";i:1681985119;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(20, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:19', '2023-04-20 12:05:19', '[17,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985119;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985119;s:19:"scheduled_timestamp";i:1681985119;s:9:"timestamp";i:1681985119;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(21, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:19', '2023-04-20 12:05:19', '[18,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985119;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985119;s:19:"scheduled_timestamp";i:1681985119;s:9:"timestamp";i:1681985119;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(22, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[19,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(23, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[20,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(24, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[21,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(25, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[22,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(26, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[23,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:16', '2023-04-20 12:06:16', 0, NULL),
(27, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[24,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(28, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[25,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(29, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[26,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(30, 'adjust_download_permissions', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 0, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(31, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:20', '2023-04-20 12:05:20', '[13,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985120;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985120;s:19:"scheduled_timestamp";i:1681985120;s:9:"timestamp";i:1681985120;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(32, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:44', '2023-04-20 12:05:44', '[15,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985144;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985144;s:19:"scheduled_timestamp";i:1681985144;s:9:"timestamp";i:1681985144;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(33, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:44', '2023-04-20 12:05:44', '[16,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985144;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985144;s:19:"scheduled_timestamp";i:1681985144;s:9:"timestamp";i:1681985144;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(34, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:44', '2023-04-20 12:05:44', '[17,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985144;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985144;s:19:"scheduled_timestamp";i:1681985144;s:9:"timestamp";i:1681985144;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(35, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[18,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(36, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[19,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(37, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[20,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(38, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[21,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(39, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(40, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[23,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(41, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[24,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(42, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(43, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:05:45', '2023-04-20 12:05:45', '[26,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985145;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985145;s:19:"scheduled_timestamp";i:1681985145;s:9:"timestamp";i:1681985145;}', 2, 1, '2023-04-20 10:06:17', '2023-04-20 12:06:17', 0, NULL),
(44, 'adjust_download_permissions', 'complete', '2023-04-20 10:06:18', '2023-04-20 12:06:18', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985178;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985178;s:19:"scheduled_timestamp";i:1681985178;s:9:"timestamp";i:1681985178;}', 0, 1, '2023-04-20 10:07:20', '2023-04-20 12:07:20', 0, NULL),
(45, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:06:18', '2023-04-20 12:06:18', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985178;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985178;s:19:"scheduled_timestamp";i:1681985178;s:9:"timestamp";i:1681985178;}', 2, 1, '2023-04-20 10:07:20', '2023-04-20 12:07:20', 0, NULL),
(46, 'adjust_download_permissions', 'complete', '2023-04-20 10:07:32', '2023-04-20 12:07:32', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985252;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985252;s:19:"scheduled_timestamp";i:1681985252;s:9:"timestamp";i:1681985252;}', 0, 1, '2023-04-20 10:08:06', '2023-04-20 12:08:06', 0, NULL),
(47, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:07:32', '2023-04-20 12:07:32', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985252;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985252;s:19:"scheduled_timestamp";i:1681985252;s:9:"timestamp";i:1681985252;}', 2, 1, '2023-04-20 10:08:06', '2023-04-20 12:08:06', 0, NULL),
(48, 'adjust_download_permissions', 'complete', '2023-04-20 10:08:07', '2023-04-20 12:08:07', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985287;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985287;s:19:"scheduled_timestamp";i:1681985287;s:9:"timestamp";i:1681985287;}', 0, 1, '2023-04-20 10:08:22', '2023-04-20 12:08:22', 0, NULL),
(49, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:08:07', '2023-04-20 12:08:07', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985287;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985287;s:19:"scheduled_timestamp";i:1681985287;s:9:"timestamp";i:1681985287;}', 2, 1, '2023-04-20 10:08:22', '2023-04-20 12:08:22', 0, NULL),
(50, 'adjust_download_permissions', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 0, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(51, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[15,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(52, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[16,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(53, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[17,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(54, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[18,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(55, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[19,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(56, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[20,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(57, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[21,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(58, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[22,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(59, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[23,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(60, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[24,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(61, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[25,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(62, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:13:44', '2023-04-20 12:13:44', '[26,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985624;s:19:"scheduled_timestamp";i:1681985624;s:9:"timestamp";i:1681985624;}', 2, 1, '2023-04-20 10:14:21', '2023-04-20 12:14:21', 0, NULL),
(63, 'adjust_download_permissions', 'complete', '2023-04-20 10:15:26', '2023-04-20 12:15:26', '[13]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985726;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985726;s:19:"scheduled_timestamp";i:1681985726;s:9:"timestamp";i:1681985726;}', 0, 1, '2023-04-20 10:15:47', '2023-04-20 12:15:47', 0, NULL),
(64, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:15:26', '2023-04-20 12:15:26', '[13,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681985726;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681985726;s:19:"scheduled_timestamp";i:1681985726;s:9:"timestamp";i:1681985726;}', 2, 1, '2023-04-20 10:15:47', '2023-04-20 12:15:47', 0, NULL),
(65, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:24:06', '2023-04-20 12:24:06', '[44,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986246;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986246;s:19:"scheduled_timestamp";i:1681986246;s:9:"timestamp";i:1681986246;}', 2, 1, '2023-04-20 10:25:17', '2023-04-20 12:25:17', 0, NULL),
(66, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:25:43', '2023-04-20 12:25:43', '[44,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986343;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986343;s:19:"scheduled_timestamp";i:1681986343;s:9:"timestamp";i:1681986343;}', 2, 1, '2023-04-20 10:26:14', '2023-04-20 12:26:14', 0, NULL),
(67, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[20,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(68, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[21,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(69, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[22,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(70, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[23,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(71, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[24,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(72, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[25,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(73, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[26,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(74, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[15,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(75, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[16,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(76, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[17,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(77, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[18,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(78, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[19,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(79, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:27:45', '2023-04-20 12:27:45', '[13,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986465;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986465;s:19:"scheduled_timestamp";i:1681986465;s:9:"timestamp";i:1681986465;}', 2, 1, '2023-04-20 10:28:50', '2023-04-20 12:28:50', 0, NULL),
(80, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:43', '2023-04-20 12:29:43', '[46,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986583;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986583;s:19:"scheduled_timestamp";i:1681986583;s:9:"timestamp";i:1681986583;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(81, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[48,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(82, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[49,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(83, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[50,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(84, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[51,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(85, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[52,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(86, 'adjust_download_permissions', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[46]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 0, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(87, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:29:44', '2023-04-20 12:29:44', '[46,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986584;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986584;s:19:"scheduled_timestamp";i:1681986584;s:9:"timestamp";i:1681986584;}', 2, 1, '2023-04-20 10:30:08', '2023-04-20 12:30:08', 0, NULL),
(88, 'adjust_download_permissions', 'complete', '2023-04-20 10:30:09', '2023-04-20 12:30:09', '[46]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986609;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986609;s:19:"scheduled_timestamp";i:1681986609;s:9:"timestamp";i:1681986609;}', 0, 1, '2023-04-20 10:30:14', '2023-04-20 12:30:14', 0, NULL),
(89, 'adjust_download_permissions', 'complete', '2023-04-20 10:30:24', '2023-04-20 12:30:24', '[46]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986624;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986624;s:19:"scheduled_timestamp";i:1681986624;s:9:"timestamp";i:1681986624;}', 0, 1, '2023-04-20 10:31:07', '2023-04-20 12:31:07', 0, NULL),
(90, 'adjust_download_permissions', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[46]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 0, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(91, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[48,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 2, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(92, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[49,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 2, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(93, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[50,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 2, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(94, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[51,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 2, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(95, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:11', '2023-04-20 12:31:11', '[52,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986671;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986671;s:19:"scheduled_timestamp";i:1681986671;s:9:"timestamp";i:1681986671;}', 2, 1, '2023-04-20 10:31:11', '2023-04-20 12:31:11', 0, NULL),
(96, 'adjust_download_permissions', 'complete', '2023-04-20 10:31:24', '2023-04-20 12:31:24', '[46]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986684;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986684;s:19:"scheduled_timestamp";i:1681986684;s:9:"timestamp";i:1681986684;}', 0, 1, '2023-04-20 10:32:38', '2023-04-20 12:32:38', 0, NULL),
(97, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:31:24', '2023-04-20 12:31:24', '[46,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986684;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986684;s:19:"scheduled_timestamp";i:1681986684;s:9:"timestamp";i:1681986684;}', 2, 1, '2023-04-20 10:32:38', '2023-04-20 12:32:38', 0, NULL),
(98, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:36', '2023-04-20 12:33:36', '[53,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986816;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986816;s:19:"scheduled_timestamp";i:1681986816;s:9:"timestamp";i:1681986816;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(99, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[54,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(100, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[55,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(101, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[56,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(102, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[57,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(103, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[58,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(104, 'adjust_download_permissions', 'complete', '2023-04-20 10:33:37', '2023-04-20 12:33:37', '[53]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986817;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986817;s:19:"scheduled_timestamp";i:1681986817;s:9:"timestamp";i:1681986817;}', 0, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(105, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[55,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL) ;
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(106, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[56,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(107, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[57,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(108, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[58,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:53', '2023-04-20 12:33:53', 0, NULL),
(109, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[54,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:54', '2023-04-20 12:33:54', 0, NULL),
(110, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:33:53', '2023-04-20 12:33:53', '[53,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681986833;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681986833;s:19:"scheduled_timestamp";i:1681986833;s:9:"timestamp";i:1681986833;}', 2, 1, '2023-04-20 10:33:54', '2023-04-20 12:33:54', 0, NULL),
(111, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:38:06', '2023-04-20 12:38:06', '[59,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987086;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987086;s:19:"scheduled_timestamp";i:1681987086;s:9:"timestamp";i:1681987086;}', 2, 1, '2023-04-20 10:39:07', '2023-04-20 12:39:07', 0, NULL),
(112, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:09', '2023-04-20 12:39:09', '[59,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987149;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987149;s:19:"scheduled_timestamp";i:1681987149;s:9:"timestamp";i:1681987149;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(113, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[64,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(114, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[65,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(115, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[66,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(116, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[67,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(117, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[68,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(118, 'adjust_download_permissions', 'complete', '2023-04-20 10:39:44', '2023-04-20 12:39:44', '[59]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987184;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987184;s:19:"scheduled_timestamp";i:1681987184;s:9:"timestamp";i:1681987184;}', 0, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(119, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[64,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(120, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[65,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(121, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[66,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(122, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[67,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(123, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[68,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(124, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:03', '2023-04-20 12:40:03', '[59,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987203;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987203;s:19:"scheduled_timestamp";i:1681987203;s:9:"timestamp";i:1681987203;}', 2, 1, '2023-04-20 10:40:10', '2023-04-20 12:40:10', 0, NULL),
(125, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[64,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 2, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(126, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[65,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 2, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(127, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[66,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 2, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(128, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[67,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 2, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(129, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[68,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 2, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(130, 'adjust_download_permissions', 'complete', '2023-04-20 10:40:11', '2023-04-20 12:40:11', '[59]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987211;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987211;s:19:"scheduled_timestamp";i:1681987211;s:9:"timestamp";i:1681987211;}', 0, 1, '2023-04-20 10:40:11', '2023-04-20 12:40:11', 0, NULL),
(131, 'adjust_download_permissions', 'complete', '2023-04-20 10:40:25', '2023-04-20 12:40:25', '[59]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987225;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987225;s:19:"scheduled_timestamp";i:1681987225;s:9:"timestamp";i:1681987225;}', 0, 1, '2023-04-20 10:41:11', '2023-04-20 12:41:11', 0, NULL),
(132, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:40:32', '2023-04-20 12:40:32', '[59,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987232;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987232;s:19:"scheduled_timestamp";i:1681987232;s:9:"timestamp";i:1681987232;}', 2, 1, '2023-04-20 10:41:11', '2023-04-20 12:41:11', 0, NULL),
(133, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:11', '2023-04-20 12:47:11', '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987631;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987631;s:19:"scheduled_timestamp";i:1681987631;s:9:"timestamp";i:1681987631;}', 2, 1, '2023-04-20 10:47:53', '2023-04-20 12:47:53', 0, NULL),
(134, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[78,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:53', '2023-04-20 12:47:53', 0, NULL),
(135, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[79,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(136, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[80,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(137, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[81,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(138, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[82,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(139, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[83,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(140, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[84,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(141, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[85,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(142, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[86,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(143, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:44', '2023-04-20 12:47:44', '[87,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987664;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987664;s:19:"scheduled_timestamp";i:1681987664;s:9:"timestamp";i:1681987664;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(144, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[88,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(145, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[89,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(146, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[90,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(147, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[91,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(148, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[92,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(149, 'adjust_download_permissions', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 0, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(150, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:45', '2023-04-20 12:47:45', '[70,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987665;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987665;s:19:"scheduled_timestamp";i:1681987665;s:9:"timestamp";i:1681987665;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(151, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[89,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(152, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[90,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(153, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[91,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(154, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[92,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(155, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[79,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(156, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[80,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(157, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[81,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(158, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[82,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(159, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[83,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(160, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[84,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(161, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[85,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(162, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[86,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(163, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[87,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(164, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[88,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(165, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:47:53', '2023-04-20 12:47:53', '[78,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987673;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987673;s:19:"scheduled_timestamp";i:1681987673;s:9:"timestamp";i:1681987673;}', 2, 1, '2023-04-20 10:47:54', '2023-04-20 12:47:54', 0, NULL),
(166, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:01', '2023-04-20 12:48:01', '[89,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987681;s:19:"scheduled_timestamp";i:1681987681;s:9:"timestamp";i:1681987681;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(167, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:01', '2023-04-20 12:48:01', '[90,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987681;s:19:"scheduled_timestamp";i:1681987681;s:9:"timestamp";i:1681987681;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(168, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:01', '2023-04-20 12:48:01', '[91,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987681;s:19:"scheduled_timestamp";i:1681987681;s:9:"timestamp";i:1681987681;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(169, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:01', '2023-04-20 12:48:01', '[92,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987681;s:19:"scheduled_timestamp";i:1681987681;s:9:"timestamp";i:1681987681;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(170, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:01', '2023-04-20 12:48:01', '[79,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987681;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987681;s:19:"scheduled_timestamp";i:1681987681;s:9:"timestamp";i:1681987681;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(171, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[80,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(172, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[81,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(173, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[82,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(174, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[83,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(175, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[84,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(176, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[85,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(177, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[86,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(178, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[87,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(179, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[88,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(180, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[78,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(181, 'adjust_download_permissions', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 0, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(182, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:48:02', '2023-04-20 12:48:02', '[70,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987682;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987682;s:19:"scheduled_timestamp";i:1681987682;s:9:"timestamp";i:1681987682;}', 2, 1, '2023-04-20 10:48:13', '2023-04-20 12:48:13', 0, NULL),
(183, 'adjust_download_permissions', 'complete', '2023-04-20 10:48:15', '2023-04-20 12:48:15', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987695;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987695;s:19:"scheduled_timestamp";i:1681987695;s:9:"timestamp";i:1681987695;}', 0, 1, '2023-04-20 10:49:31', '2023-04-20 12:49:31', 0, NULL),
(184, 'adjust_download_permissions', 'complete', '2023-04-20 10:49:32', '2023-04-20 12:49:32', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987772;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987772;s:19:"scheduled_timestamp";i:1681987772;s:9:"timestamp";i:1681987772;}', 0, 1, '2023-04-20 10:50:18', '2023-04-20 12:50:18', 0, NULL),
(185, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:49:36', '2023-04-20 12:49:36', '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987776;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987776;s:19:"scheduled_timestamp";i:1681987776;s:9:"timestamp";i:1681987776;}', 2, 1, '2023-04-20 10:50:18', '2023-04-20 12:50:18', 0, NULL),
(186, 'adjust_download_permissions', 'complete', '2023-04-20 10:50:56', '2023-04-20 12:50:56', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987856;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987856;s:19:"scheduled_timestamp";i:1681987856;s:9:"timestamp";i:1681987856;}', 0, 1, '2023-04-20 10:51:24', '2023-04-20 12:51:24', 0, NULL),
(187, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:50:56', '2023-04-20 12:50:56', '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987856;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987856;s:19:"scheduled_timestamp";i:1681987856;s:9:"timestamp";i:1681987856;}', 2, 1, '2023-04-20 10:51:24', '2023-04-20 12:51:24', 0, NULL),
(188, 'adjust_download_permissions', 'complete', '2023-04-20 10:51:30', '2023-04-20 12:51:30', '[70]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987890;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987890;s:19:"scheduled_timestamp";i:1681987890;s:9:"timestamp";i:1681987890;}', 0, 1, '2023-04-20 10:51:47', '2023-04-20 12:51:47', 0, NULL),
(189, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:51:30', '2023-04-20 12:51:30', '[70,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681987890;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681987890;s:19:"scheduled_timestamp";i:1681987890;s:9:"timestamp";i:1681987890;}', 2, 1, '2023-04-20 10:51:48', '2023-04-20 12:51:48', 0, NULL),
(190, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:54:43', '2023-04-20 12:54:43', '[93,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988083;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988083;s:19:"scheduled_timestamp";i:1681988083;s:9:"timestamp";i:1681988083;}', 2, 1, '2023-04-20 10:54:59', '2023-04-20 12:54:59', 0, NULL),
(191, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 10:55:08', '2023-04-20 12:55:08', '[93,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681988108;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681988108;s:19:"scheduled_timestamp";i:1681988108;s:9:"timestamp";i:1681988108;}', 2, 1, '2023-04-20 10:56:06', '2023-04-20 12:56:06', 0, NULL),
(192, 'wc-admin_import_orders', 'complete', '2023-04-20 12:33:21', '2023-04-20 14:33:21', '[99]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994001;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994001;s:19:"scheduled_timestamp";i:1681994001;s:9:"timestamp";i:1681994001;}', 3, 1, '2023-04-20 12:33:54', '2023-04-20 14:33:54', 0, NULL),
(193, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 12:35:03', '2023-04-20 14:35:03', '[93,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994103;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994103;s:19:"scheduled_timestamp";i:1681994103;s:9:"timestamp";i:1681994103;}', 2, 1, '2023-04-20 12:35:06', '2023-04-20 14:35:06', 0, NULL),
(194, 'wc-admin_import_orders', 'complete', '2023-04-20 12:36:40', '2023-04-20 14:36:40', '[100]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994200;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994200;s:19:"scheduled_timestamp";i:1681994200;s:9:"timestamp";i:1681994200;}', 3, 1, '2023-04-20 12:37:22', '2023-04-20 14:37:22', 0, NULL),
(195, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-20 12:40:23', '2023-04-20 14:40:23', '[93,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994423;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994423;s:19:"scheduled_timestamp";i:1681994423;s:9:"timestamp";i:1681994423;}', 2, 1, '2023-04-20 12:40:23', '2023-04-20 14:40:23', 0, NULL),
(196, 'wc-admin_import_orders', 'complete', '2023-04-20 12:42:44', '2023-04-20 14:42:44', '[100]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994564;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994564;s:19:"scheduled_timestamp";i:1681994564;s:9:"timestamp";i:1681994564;}', 3, 1, '2023-04-20 12:43:17', '2023-04-20 14:43:17', 0, NULL),
(197, 'wc-admin_import_orders', 'complete', '2023-04-20 12:47:57', '2023-04-20 14:47:57', '[99]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681994877;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681994877;s:19:"scheduled_timestamp";i:1681994877;s:9:"timestamp";i:1681994877;}', 3, 1, '2023-04-20 12:48:06', '2023-04-20 14:48:06', 0, NULL),
(198, 'action_scheduler/migration_hook', 'complete', '2023-04-20 12:55:20', '2023-04-20 14:55:20', '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1681995320;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1681995320;s:19:"scheduled_timestamp";i:1681995320;s:9:"timestamp";i:1681995320;}', 1, 1, '2023-04-20 12:55:22', '2023-04-20 14:55:22', 0, NULL),
(199, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:30:26', '2023-04-21 08:30:26', '[101,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058626;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058626;s:19:"scheduled_timestamp";i:1682058626;s:9:"timestamp";i:1682058626;}', 2, 1, '2023-04-21 06:31:28', '2023-04-21 08:31:28', 0, NULL),
(200, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:32:52', '2023-04-21 08:32:52', '[105,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058772;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058772;s:19:"scheduled_timestamp";i:1682058772;s:9:"timestamp";i:1682058772;}', 2, 1, '2023-04-21 06:33:05', '2023-04-21 08:33:05', 0, NULL),
(201, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:33:06', '2023-04-21 08:33:06', '[106,1]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058786;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058786;s:19:"scheduled_timestamp";i:1682058786;s:9:"timestamp";i:1682058786;}', 2, 1, '2023-04-21 06:33:53', '2023-04-21 08:33:53', 0, NULL),
(202, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:33:52', '2023-04-21 08:33:52', '[106,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058832;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058832;s:19:"scheduled_timestamp";i:1682058832;s:9:"timestamp";i:1682058832;}', 2, 1, '2023-04-21 06:33:53', '2023-04-21 08:33:53', 0, NULL),
(203, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:35:03', '2023-04-21 08:35:03', '[108,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058903;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058903;s:19:"scheduled_timestamp";i:1682058903;s:9:"timestamp";i:1682058903;}', 2, 1, '2023-04-21 06:35:04', '2023-04-21 08:35:04', 0, NULL),
(204, 'adjust_download_permissions', 'complete', '2023-04-21 06:36:10', '2023-04-21 08:36:10', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058970;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058970;s:19:"scheduled_timestamp";i:1682058970;s:9:"timestamp";i:1682058970;}', 0, 1, '2023-04-21 06:37:05', '2023-04-21 08:37:05', 0, NULL),
(205, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:36:10', '2023-04-21 08:36:10', '[101,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682058970;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682058970;s:19:"scheduled_timestamp";i:1682058970;s:9:"timestamp";i:1682058970;}', 2, 1, '2023-04-21 06:37:05', '2023-04-21 08:37:05', 0, NULL) ;
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(206, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:37:32', '2023-04-21 08:37:32', '[108,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059052;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059052;s:19:"scheduled_timestamp";i:1682059052;s:9:"timestamp";i:1682059052;}', 2, 1, '2023-04-21 06:38:14', '2023-04-21 08:38:14', 0, NULL),
(207, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:37:32', '2023-04-21 08:37:32', '[106,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059052;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059052;s:19:"scheduled_timestamp";i:1682059052;s:9:"timestamp";i:1682059052;}', 2, 1, '2023-04-21 06:38:14', '2023-04-21 08:38:14', 0, NULL),
(208, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:37:32', '2023-04-21 08:37:32', '[105,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059052;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059052;s:19:"scheduled_timestamp";i:1682059052;s:9:"timestamp";i:1682059052;}', 2, 1, '2023-04-21 06:38:14', '2023-04-21 08:38:14', 0, NULL),
(209, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:38:26', '2023-04-21 08:38:26', '[108,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059106;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059106;s:19:"scheduled_timestamp";i:1682059106;s:9:"timestamp";i:1682059106;}', 2, 1, '2023-04-21 06:39:32', '2023-04-21 08:39:32', 0, NULL),
(210, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:38:26', '2023-04-21 08:38:26', '[106,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059106;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059106;s:19:"scheduled_timestamp";i:1682059106;s:9:"timestamp";i:1682059106;}', 2, 1, '2023-04-21 06:39:32', '2023-04-21 08:39:32', 0, NULL),
(211, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:38:26', '2023-04-21 08:38:26', '[105,3]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059106;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059106;s:19:"scheduled_timestamp";i:1682059106;s:9:"timestamp";i:1682059106;}', 2, 1, '2023-04-21 06:39:32', '2023-04-21 08:39:32', 0, NULL),
(212, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:43:57', '2023-04-21 08:43:57', '[109,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682059437;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682059437;s:19:"scheduled_timestamp";i:1682059437;s:9:"timestamp";i:1682059437;}', 2, 1, '2023-04-21 06:44:17', '2023-04-21 08:44:17', 0, NULL),
(213, 'adjust_download_permissions', 'complete', '2023-04-21 06:58:24', '2023-04-21 08:58:24', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060304;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060304;s:19:"scheduled_timestamp";i:1682060304;s:9:"timestamp";i:1682060304;}', 0, 1, '2023-04-21 06:58:45', '2023-04-21 08:58:45', 0, NULL),
(214, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:58:24', '2023-04-21 08:58:24', '[101,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060304;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060304;s:19:"scheduled_timestamp";i:1682060304;s:9:"timestamp";i:1682060304;}', 2, 1, '2023-04-21 06:58:45', '2023-04-21 08:58:45', 0, NULL),
(215, 'adjust_download_permissions', 'complete', '2023-04-21 06:59:07', '2023-04-21 08:59:07', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060347;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060347;s:19:"scheduled_timestamp";i:1682060347;s:9:"timestamp";i:1682060347;}', 0, 1, '2023-04-21 07:00:22', '2023-04-21 09:00:22', 0, NULL),
(216, 'woocommerce_run_product_attribute_lookup_update_callback', 'complete', '2023-04-21 06:59:07', '2023-04-21 08:59:07', '[101,2]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060347;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060347;s:19:"scheduled_timestamp";i:1682060347;s:9:"timestamp";i:1682060347;}', 2, 1, '2023-04-21 07:00:22', '2023-04-21 09:00:22', 0, NULL),
(217, 'wc-admin_import_orders', 'complete', '2023-04-21 07:04:46', '2023-04-21 09:04:46', '[114]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060686;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060686;s:19:"scheduled_timestamp";i:1682060686;s:9:"timestamp";i:1682060686;}', 3, 1, '2023-04-21 07:05:06', '2023-04-21 09:05:06', 0, NULL),
(218, 'wc-admin_import_orders', 'complete', '2023-04-21 07:05:50', '2023-04-21 09:05:50', '[114]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682060750;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682060750;s:19:"scheduled_timestamp";i:1682060750;s:9:"timestamp";i:1682060750;}', 3, 1, '2023-04-21 07:06:09', '2023-04-21 09:06:09', 0, NULL),
(219, 'woocommerce_cleanup_draft_orders', 'pending', '2023-04-22 09:57:55', '2023-04-22 11:57:55', '[]', 'O:32:"ActionScheduler_IntervalSchedule":10:{s:22:"\0*\0scheduled_timestamp";i:1682157475;s:18:"\0*\0first_timestamp";i:1681983848;s:13:"\0*\0recurrence";i:86400;s:49:"\0ActionScheduler_IntervalSchedule\0start_timestamp";i:1682157475;s:53:"\0ActionScheduler_IntervalSchedule\0interval_in_seconds";i:86400;s:19:"scheduled_timestamp";i:1682157475;s:15:"first_timestamp";i:1681983848;s:10:"recurrence";i:86400;s:15:"start_timestamp";i:1682157475;s:19:"interval_in_seconds";i:86400;}', 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL),
(220, 'adjust_download_permissions', 'complete', '2023-04-21 11:12:29', '2023-04-21 13:12:29', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682075549;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682075549;s:19:"scheduled_timestamp";i:1682075549;s:9:"timestamp";i:1682075549;}', 0, 1, '2023-04-21 11:13:10', '2023-04-21 13:13:10', 0, NULL),
(221, 'adjust_download_permissions', 'complete', '2023-04-21 11:33:23', '2023-04-21 13:33:23', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682076803;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682076803;s:19:"scheduled_timestamp";i:1682076803;s:9:"timestamp";i:1682076803;}', 0, 1, '2023-04-21 11:34:54', '2023-04-21 13:34:54', 0, NULL),
(222, 'adjust_download_permissions', 'complete', '2023-04-21 11:47:14', '2023-04-21 13:47:14', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682077634;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682077634;s:19:"scheduled_timestamp";i:1682077634;s:9:"timestamp";i:1682077634;}', 0, 1, '2023-04-21 11:47:31', '2023-04-21 13:47:31', 0, NULL),
(223, 'adjust_download_permissions', 'complete', '2023-04-21 11:49:07', '2023-04-21 13:49:07', '[101]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1682077747;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1682077747;s:19:"scheduled_timestamp";i:1682077747;s:9:"timestamp";i:1682077747;}', 0, 1, '2023-04-21 11:49:45', '2023-04-21 13:49:45', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=251 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration'),
(2, 'woocommerce-db-updates'),
(3, 'wc-admin-data') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=653 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 6, 'action created', '2023-04-20 09:44:06', '2023-04-20 11:44:06'),
(2, 7, 'action created', '2023-04-20 09:44:08', '2023-04-20 11:44:08'),
(3, 7, 'action started via Async Request', '2023-04-20 09:45:11', '2023-04-20 11:45:11'),
(4, 7, 'action complete via Async Request', '2023-04-20 09:45:11', '2023-04-20 11:45:11'),
(5, 8, 'action created', '2023-04-20 09:45:11', '2023-04-20 11:45:11'),
(6, 6, 'action started via Async Request', '2023-04-20 09:45:11', '2023-04-20 11:45:11'),
(7, 6, 'action complete via Async Request', '2023-04-20 09:45:11', '2023-04-20 11:45:11'),
(8, 9, 'action created', '2023-04-20 10:03:45', '2023-04-20 12:03:45'),
(9, 9, 'action started via Async Request', '2023-04-20 10:03:47', '2023-04-20 12:03:47'),
(10, 9, 'action complete via Async Request', '2023-04-20 10:03:48', '2023-04-20 12:03:48'),
(11, 10, 'action created', '2023-04-20 10:04:10', '2023-04-20 12:04:10'),
(12, 11, 'action created', '2023-04-20 10:04:14', '2023-04-20 12:04:14'),
(13, 12, 'action created', '2023-04-20 10:04:44', '2023-04-20 12:04:44'),
(14, 13, 'action created', '2023-04-20 10:04:45', '2023-04-20 12:04:45'),
(15, 14, 'action created', '2023-04-20 10:04:45', '2023-04-20 12:04:45'),
(16, 15, 'action created', '2023-04-20 10:04:57', '2023-04-20 12:04:57'),
(17, 10, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(18, 10, 'action complete via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(19, 11, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(20, 11, 'action failed via Async Request: Scheduled action for woocommerce_admin/stored_state_setup_for_products/async/run_remote_notifications will not be executed as no callbacks are registered.', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(21, 12, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(22, 12, 'action complete via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(23, 13, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(24, 13, 'action complete via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(25, 14, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(26, 14, 'action complete via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(27, 15, 'action started via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(28, 15, 'action complete via Async Request', '2023-04-20 10:04:58', '2023-04-20 12:04:58'),
(29, 16, 'action created', '2023-04-20 10:05:03', '2023-04-20 12:05:03'),
(30, 17, 'action created', '2023-04-20 10:05:03', '2023-04-20 12:05:03'),
(31, 16, 'action started via WP Cron', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(32, 16, 'action complete via WP Cron', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(33, 17, 'action started via WP Cron', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(34, 17, 'action complete via WP Cron', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(35, 18, 'action created', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(36, 19, 'action created', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(37, 20, 'action created', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(38, 21, 'action created', '2023-04-20 10:05:18', '2023-04-20 12:05:18'),
(39, 22, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(40, 23, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(41, 24, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(42, 25, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(43, 26, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(44, 27, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(45, 28, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(46, 29, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(47, 30, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(48, 31, 'action created', '2023-04-20 10:05:19', '2023-04-20 12:05:19'),
(49, 32, 'action created', '2023-04-20 10:05:43', '2023-04-20 12:05:43'),
(50, 33, 'action created', '2023-04-20 10:05:43', '2023-04-20 12:05:43'),
(51, 34, 'action created', '2023-04-20 10:05:43', '2023-04-20 12:05:43'),
(52, 35, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(53, 36, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(54, 37, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(55, 38, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(56, 39, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(57, 40, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(58, 41, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(59, 42, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(60, 43, 'action created', '2023-04-20 10:05:44', '2023-04-20 12:05:44'),
(61, 18, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(62, 18, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(63, 19, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(64, 19, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(65, 20, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(66, 20, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(67, 21, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(68, 21, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(69, 22, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(70, 22, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(71, 23, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(72, 23, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(73, 24, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(74, 24, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(75, 25, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(76, 25, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(77, 26, 'action started via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(78, 26, 'action complete via WP Cron', '2023-04-20 10:06:16', '2023-04-20 12:06:16'),
(79, 27, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(80, 27, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(81, 28, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(82, 28, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(83, 29, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(84, 29, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(85, 30, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(86, 30, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(87, 31, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(88, 31, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(89, 32, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(90, 32, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(91, 33, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(92, 33, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(93, 34, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(94, 34, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(95, 35, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(96, 35, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(97, 36, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(98, 36, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(99, 37, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(100, 37, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(101, 38, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(102, 38, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(103, 39, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(104, 39, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(105, 40, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(106, 44, 'action created', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(107, 40, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(108, 41, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(109, 45, 'action created', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(110, 41, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(111, 42, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(112, 42, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(113, 43, 'action started via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(114, 43, 'action complete via WP Cron', '2023-04-20 10:06:17', '2023-04-20 12:06:17'),
(115, 44, 'action started via WP Cron', '2023-04-20 10:07:20', '2023-04-20 12:07:20'),
(116, 44, 'action complete via WP Cron', '2023-04-20 10:07:20', '2023-04-20 12:07:20'),
(117, 45, 'action started via WP Cron', '2023-04-20 10:07:20', '2023-04-20 12:07:20'),
(118, 45, 'action complete via WP Cron', '2023-04-20 10:07:20', '2023-04-20 12:07:20'),
(119, 46, 'action created', '2023-04-20 10:07:31', '2023-04-20 12:07:31'),
(120, 47, 'action created', '2023-04-20 10:07:31', '2023-04-20 12:07:31'),
(121, 46, 'action started via WP Cron', '2023-04-20 10:08:05', '2023-04-20 12:08:05'),
(122, 46, 'action complete via WP Cron', '2023-04-20 10:08:06', '2023-04-20 12:08:06'),
(123, 47, 'action started via WP Cron', '2023-04-20 10:08:06', '2023-04-20 12:08:06'),
(124, 47, 'action complete via WP Cron', '2023-04-20 10:08:06', '2023-04-20 12:08:06'),
(125, 48, 'action created', '2023-04-20 10:08:06', '2023-04-20 12:08:06'),
(126, 49, 'action created', '2023-04-20 10:08:06', '2023-04-20 12:08:06'),
(127, 48, 'action started via Async Request', '2023-04-20 10:08:22', '2023-04-20 12:08:22'),
(128, 48, 'action complete via Async Request', '2023-04-20 10:08:22', '2023-04-20 12:08:22'),
(129, 49, 'action started via Async Request', '2023-04-20 10:08:22', '2023-04-20 12:08:22'),
(130, 49, 'action complete via Async Request', '2023-04-20 10:08:22', '2023-04-20 12:08:22'),
(131, 50, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(132, 51, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(133, 52, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(134, 53, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(135, 54, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(136, 55, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(137, 56, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(138, 57, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(139, 58, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(140, 59, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(141, 60, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(142, 61, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(143, 62, 'action created', '2023-04-20 10:13:43', '2023-04-20 12:13:43'),
(144, 50, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(145, 50, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(146, 51, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(147, 51, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(148, 52, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(149, 52, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(150, 53, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(151, 53, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(152, 54, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(153, 54, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(154, 55, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(155, 55, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(156, 56, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(157, 56, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(158, 57, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(159, 57, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(160, 58, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(161, 58, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(162, 59, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(163, 59, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(164, 60, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(165, 60, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(166, 61, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(167, 61, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(168, 62, 'action started via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(169, 62, 'action complete via WP Cron', '2023-04-20 10:14:21', '2023-04-20 12:14:21'),
(170, 63, 'action created', '2023-04-20 10:15:25', '2023-04-20 12:15:25'),
(171, 64, 'action created', '2023-04-20 10:15:25', '2023-04-20 12:15:25'),
(172, 63, 'action started via Async Request', '2023-04-20 10:15:47', '2023-04-20 12:15:47'),
(173, 63, 'action complete via Async Request', '2023-04-20 10:15:47', '2023-04-20 12:15:47'),
(174, 64, 'action started via Async Request', '2023-04-20 10:15:47', '2023-04-20 12:15:47'),
(175, 64, 'action complete via Async Request', '2023-04-20 10:15:47', '2023-04-20 12:15:47'),
(176, 65, 'action created', '2023-04-20 10:24:05', '2023-04-20 12:24:05'),
(177, 65, 'action started via WP Cron', '2023-04-20 10:25:17', '2023-04-20 12:25:17'),
(178, 65, 'action complete via WP Cron', '2023-04-20 10:25:17', '2023-04-20 12:25:17'),
(179, 66, 'action created', '2023-04-20 10:25:42', '2023-04-20 12:25:42'),
(180, 66, 'action started via WP Cron', '2023-04-20 10:26:14', '2023-04-20 12:26:14'),
(181, 66, 'action complete via WP Cron', '2023-04-20 10:26:14', '2023-04-20 12:26:14'),
(182, 67, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(183, 68, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(184, 69, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(185, 70, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(186, 71, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(187, 72, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(188, 73, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(189, 74, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(190, 75, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(191, 76, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(192, 77, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(193, 78, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(194, 79, 'action created', '2023-04-20 10:27:44', '2023-04-20 12:27:44'),
(195, 67, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(196, 67, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(197, 68, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(198, 68, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(199, 69, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(200, 69, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(201, 70, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(202, 70, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(203, 71, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(204, 71, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(205, 72, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(206, 72, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(207, 73, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(208, 73, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(209, 74, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(210, 74, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(211, 75, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(212, 75, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(213, 76, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(214, 76, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(215, 77, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(216, 77, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(217, 78, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(218, 78, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(219, 79, 'action started via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(220, 79, 'action complete via WP Cron', '2023-04-20 10:28:50', '2023-04-20 12:28:50'),
(221, 80, 'action created', '2023-04-20 10:29:42', '2023-04-20 12:29:42'),
(222, 81, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(223, 82, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(224, 83, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(225, 84, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(226, 85, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(227, 86, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(228, 87, 'action created', '2023-04-20 10:29:43', '2023-04-20 12:29:43'),
(229, 80, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(230, 80, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(231, 81, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(232, 81, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(233, 82, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(234, 82, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(235, 83, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(236, 83, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(237, 84, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(238, 84, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(239, 85, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(240, 85, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(241, 86, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(242, 86, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(243, 87, 'action started via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(244, 87, 'action complete via WP Cron', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(245, 88, 'action created', '2023-04-20 10:30:08', '2023-04-20 12:30:08'),
(246, 88, 'action started via Async Request', '2023-04-20 10:30:14', '2023-04-20 12:30:14'),
(247, 88, 'action complete via Async Request', '2023-04-20 10:30:14', '2023-04-20 12:30:14'),
(248, 89, 'action created', '2023-04-20 10:30:23', '2023-04-20 12:30:23'),
(249, 89, 'action started via WP Cron', '2023-04-20 10:31:07', '2023-04-20 12:31:07'),
(250, 89, 'action complete via WP Cron', '2023-04-20 10:31:07', '2023-04-20 12:31:07'),
(251, 90, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(252, 91, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(253, 92, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(254, 93, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(255, 94, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(256, 95, 'action created', '2023-04-20 10:31:10', '2023-04-20 12:31:10'),
(257, 90, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(258, 90, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(259, 91, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(260, 91, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(261, 92, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(262, 92, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(263, 93, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(264, 93, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(265, 94, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(266, 94, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(267, 95, 'action started via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(268, 95, 'action complete via Async Request', '2023-04-20 10:31:11', '2023-04-20 12:31:11'),
(269, 96, 'action created', '2023-04-20 10:31:23', '2023-04-20 12:31:23'),
(270, 97, 'action created', '2023-04-20 10:31:23', '2023-04-20 12:31:23'),
(271, 96, 'action started via WP Cron', '2023-04-20 10:32:38', '2023-04-20 12:32:38'),
(272, 96, 'action complete via WP Cron', '2023-04-20 10:32:38', '2023-04-20 12:32:38'),
(273, 97, 'action started via WP Cron', '2023-04-20 10:32:38', '2023-04-20 12:32:38'),
(274, 97, 'action complete via WP Cron', '2023-04-20 10:32:38', '2023-04-20 12:32:38'),
(275, 98, 'action created', '2023-04-20 10:33:35', '2023-04-20 12:33:35'),
(276, 99, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(277, 100, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(278, 101, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(279, 102, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(280, 103, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(281, 104, 'action created', '2023-04-20 10:33:36', '2023-04-20 12:33:36'),
(282, 105, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(283, 106, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(284, 107, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(285, 108, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(286, 109, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(287, 110, 'action created', '2023-04-20 10:33:52', '2023-04-20 12:33:52'),
(288, 98, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(289, 98, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(290, 99, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(291, 99, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(292, 100, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(293, 100, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(294, 101, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(295, 101, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(296, 102, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(297, 102, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(298, 103, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(299, 103, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(300, 104, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(301, 104, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(302, 105, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(303, 105, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(304, 106, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(305, 106, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(306, 107, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(307, 107, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(308, 108, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(309, 108, 'action complete via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(310, 109, 'action started via Async Request', '2023-04-20 10:33:53', '2023-04-20 12:33:53'),
(311, 109, 'action complete via Async Request', '2023-04-20 10:33:54', '2023-04-20 12:33:54'),
(312, 110, 'action started via Async Request', '2023-04-20 10:33:54', '2023-04-20 12:33:54'),
(313, 110, 'action complete via Async Request', '2023-04-20 10:33:54', '2023-04-20 12:33:54'),
(314, 111, 'action created', '2023-04-20 10:38:05', '2023-04-20 12:38:05'),
(315, 111, 'action started via WP Cron', '2023-04-20 10:39:07', '2023-04-20 12:39:07'),
(316, 111, 'action complete via WP Cron', '2023-04-20 10:39:07', '2023-04-20 12:39:07'),
(317, 112, 'action created', '2023-04-20 10:39:08', '2023-04-20 12:39:08'),
(318, 113, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(319, 114, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(320, 115, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(321, 116, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(322, 117, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(323, 118, 'action created', '2023-04-20 10:39:43', '2023-04-20 12:39:43'),
(324, 119, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(325, 120, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(326, 121, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(327, 122, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(328, 123, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(329, 124, 'action created', '2023-04-20 10:40:02', '2023-04-20 12:40:02'),
(330, 112, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(331, 112, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(332, 113, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(333, 113, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(334, 114, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(335, 114, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(336, 115, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(337, 115, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(338, 116, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(339, 116, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(340, 117, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(341, 117, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(342, 118, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(343, 118, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(344, 119, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(345, 119, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(346, 120, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(347, 120, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(348, 121, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(349, 121, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(350, 122, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(351, 122, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(352, 123, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(353, 123, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(354, 124, 'action started via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(355, 124, 'action complete via WP Cron', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(356, 125, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(357, 126, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(358, 127, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(359, 128, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(360, 129, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(361, 130, 'action created', '2023-04-20 10:40:10', '2023-04-20 12:40:10'),
(362, 125, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(363, 125, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(364, 126, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(365, 126, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(366, 127, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(367, 127, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(368, 128, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(369, 128, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(370, 129, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(371, 129, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(372, 130, 'action started via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(373, 130, 'action complete via Async Request', '2023-04-20 10:40:11', '2023-04-20 12:40:11'),
(374, 131, 'action created', '2023-04-20 10:40:24', '2023-04-20 12:40:24'),
(375, 132, 'action created', '2023-04-20 10:40:31', '2023-04-20 12:40:31'),
(376, 131, 'action started via WP Cron', '2023-04-20 10:41:10', '2023-04-20 12:41:10'),
(377, 131, 'action complete via WP Cron', '2023-04-20 10:41:11', '2023-04-20 12:41:11'),
(378, 132, 'action started via WP Cron', '2023-04-20 10:41:11', '2023-04-20 12:41:11'),
(379, 132, 'action complete via WP Cron', '2023-04-20 10:41:11', '2023-04-20 12:41:11'),
(380, 133, 'action created', '2023-04-20 10:47:10', '2023-04-20 12:47:10'),
(381, 134, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(382, 135, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(383, 136, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(384, 137, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(385, 138, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(386, 139, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(387, 140, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(388, 141, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(389, 142, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(390, 143, 'action created', '2023-04-20 10:47:43', '2023-04-20 12:47:43'),
(391, 144, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(392, 145, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(393, 146, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(394, 147, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(395, 148, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(396, 149, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(397, 150, 'action created', '2023-04-20 10:47:44', '2023-04-20 12:47:44'),
(398, 151, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(399, 152, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(400, 153, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(401, 154, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(402, 155, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(403, 156, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(404, 157, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(405, 158, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(406, 159, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(407, 160, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(408, 161, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(409, 162, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(410, 163, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(411, 164, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(412, 165, 'action created', '2023-04-20 10:47:52', '2023-04-20 12:47:52'),
(413, 133, 'action started via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(414, 133, 'action complete via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(415, 134, 'action started via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(416, 134, 'action complete via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(417, 135, 'action started via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(418, 135, 'action complete via Async Request', '2023-04-20 10:47:53', '2023-04-20 12:47:53'),
(419, 136, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(420, 136, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(421, 137, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(422, 137, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(423, 138, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(424, 138, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(425, 139, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(426, 139, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(427, 140, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(428, 140, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(429, 141, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(430, 141, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(431, 142, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(432, 142, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(433, 143, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(434, 143, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(435, 144, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(436, 144, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(437, 145, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(438, 145, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(439, 146, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(440, 146, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(441, 147, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(442, 147, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(443, 148, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(444, 148, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(445, 149, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(446, 149, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(447, 150, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(448, 150, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(449, 151, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(450, 151, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(451, 152, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(452, 152, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(453, 153, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(454, 153, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(455, 154, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(456, 154, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(457, 155, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(458, 155, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(459, 156, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(460, 156, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(461, 157, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(462, 157, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(463, 158, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(464, 158, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(465, 159, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(466, 159, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(467, 160, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(468, 160, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(469, 161, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(470, 161, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(471, 162, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(472, 162, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(473, 163, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(474, 163, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(475, 164, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(476, 164, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(477, 165, 'action started via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(478, 165, 'action complete via Async Request', '2023-04-20 10:47:54', '2023-04-20 12:47:54'),
(479, 166, 'action created', '2023-04-20 10:48:00', '2023-04-20 12:48:00'),
(480, 167, 'action created', '2023-04-20 10:48:00', '2023-04-20 12:48:00'),
(481, 168, 'action created', '2023-04-20 10:48:00', '2023-04-20 12:48:00'),
(482, 169, 'action created', '2023-04-20 10:48:00', '2023-04-20 12:48:00'),
(483, 170, 'action created', '2023-04-20 10:48:00', '2023-04-20 12:48:00'),
(484, 171, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(485, 172, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(486, 173, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(487, 174, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(488, 175, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(489, 176, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(490, 177, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(491, 178, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(492, 179, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(493, 180, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(494, 181, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(495, 182, 'action created', '2023-04-20 10:48:01', '2023-04-20 12:48:01'),
(496, 166, 'action started via WP Cron', '2023-04-20 10:48:12', '2023-04-20 12:48:12'),
(497, 166, 'action complete via WP Cron', '2023-04-20 10:48:12', '2023-04-20 12:48:12'),
(498, 167, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(499, 167, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(500, 168, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(501, 168, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(502, 169, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(503, 169, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(504, 170, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(505, 170, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(506, 171, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(507, 171, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(508, 172, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(509, 172, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(510, 173, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(511, 173, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(512, 174, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(513, 174, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(514, 175, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(515, 175, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(516, 176, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(517, 176, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(518, 177, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(519, 177, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(520, 178, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(521, 178, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(522, 179, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(523, 179, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(524, 180, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(525, 180, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(526, 181, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(527, 181, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(528, 182, 'action started via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(529, 182, 'action complete via WP Cron', '2023-04-20 10:48:13', '2023-04-20 12:48:13'),
(530, 183, 'action created', '2023-04-20 10:48:14', '2023-04-20 12:48:14'),
(531, 183, 'action started via WP Cron', '2023-04-20 10:49:31', '2023-04-20 12:49:31'),
(532, 183, 'action complete via WP Cron', '2023-04-20 10:49:31', '2023-04-20 12:49:31'),
(533, 184, 'action created', '2023-04-20 10:49:31', '2023-04-20 12:49:31'),
(534, 185, 'action created', '2023-04-20 10:49:35', '2023-04-20 12:49:35'),
(535, 184, 'action started via WP Cron', '2023-04-20 10:50:18', '2023-04-20 12:50:18'),
(536, 184, 'action complete via WP Cron', '2023-04-20 10:50:18', '2023-04-20 12:50:18'),
(537, 185, 'action started via WP Cron', '2023-04-20 10:50:18', '2023-04-20 12:50:18'),
(538, 185, 'action complete via WP Cron', '2023-04-20 10:50:18', '2023-04-20 12:50:18'),
(539, 186, 'action created', '2023-04-20 10:50:55', '2023-04-20 12:50:55'),
(540, 187, 'action created', '2023-04-20 10:50:55', '2023-04-20 12:50:55'),
(541, 186, 'action started via WP Cron', '2023-04-20 10:51:23', '2023-04-20 12:51:23'),
(542, 186, 'action complete via WP Cron', '2023-04-20 10:51:24', '2023-04-20 12:51:24'),
(543, 187, 'action started via WP Cron', '2023-04-20 10:51:24', '2023-04-20 12:51:24'),
(544, 187, 'action complete via WP Cron', '2023-04-20 10:51:24', '2023-04-20 12:51:24'),
(545, 188, 'action created', '2023-04-20 10:51:29', '2023-04-20 12:51:29'),
(546, 189, 'action created', '2023-04-20 10:51:29', '2023-04-20 12:51:29'),
(547, 188, 'action started via Async Request', '2023-04-20 10:51:47', '2023-04-20 12:51:47'),
(548, 188, 'action complete via Async Request', '2023-04-20 10:51:47', '2023-04-20 12:51:47'),
(549, 189, 'action started via Async Request', '2023-04-20 10:51:47', '2023-04-20 12:51:47'),
(550, 189, 'action complete via Async Request', '2023-04-20 10:51:48', '2023-04-20 12:51:48'),
(551, 190, 'action created', '2023-04-20 10:54:42', '2023-04-20 12:54:42'),
(552, 190, 'action started via Async Request', '2023-04-20 10:54:59', '2023-04-20 12:54:59'),
(553, 190, 'action complete via Async Request', '2023-04-20 10:54:59', '2023-04-20 12:54:59'),
(554, 191, 'action created', '2023-04-20 10:55:07', '2023-04-20 12:55:07'),
(555, 191, 'action started via WP Cron', '2023-04-20 10:56:06', '2023-04-20 12:56:06'),
(556, 191, 'action complete via WP Cron', '2023-04-20 10:56:06', '2023-04-20 12:56:06'),
(557, 192, 'action created', '2023-04-20 12:33:16', '2023-04-20 14:33:16'),
(558, 192, 'action started via Async Request', '2023-04-20 12:33:54', '2023-04-20 14:33:54'),
(559, 192, 'action complete via Async Request', '2023-04-20 12:33:54', '2023-04-20 14:33:54'),
(560, 193, 'action created', '2023-04-20 12:35:02', '2023-04-20 14:35:02'),
(561, 193, 'action started via WP Cron', '2023-04-20 12:35:06', '2023-04-20 14:35:06'),
(562, 193, 'action complete via WP Cron', '2023-04-20 12:35:06', '2023-04-20 14:35:06'),
(563, 194, 'action created', '2023-04-20 12:36:35', '2023-04-20 14:36:35'),
(564, 194, 'action started via WP Cron', '2023-04-20 12:37:22', '2023-04-20 14:37:22'),
(565, 194, 'action complete via WP Cron', '2023-04-20 12:37:22', '2023-04-20 14:37:22'),
(566, 195, 'action created', '2023-04-20 12:40:22', '2023-04-20 14:40:22'),
(567, 195, 'action started via Async Request', '2023-04-20 12:40:23', '2023-04-20 14:40:23'),
(568, 195, 'action complete via Async Request', '2023-04-20 12:40:23', '2023-04-20 14:40:23'),
(569, 196, 'action created', '2023-04-20 12:42:39', '2023-04-20 14:42:39'),
(570, 196, 'action started via WP Cron', '2023-04-20 12:43:17', '2023-04-20 14:43:17'),
(571, 196, 'action complete via WP Cron', '2023-04-20 12:43:17', '2023-04-20 14:43:17'),
(572, 197, 'action created', '2023-04-20 12:47:52', '2023-04-20 14:47:52'),
(573, 197, 'action started via WP Cron', '2023-04-20 12:48:05', '2023-04-20 14:48:05'),
(574, 197, 'action complete via WP Cron', '2023-04-20 12:48:06', '2023-04-20 14:48:06'),
(575, 198, 'action created', '2023-04-20 12:54:20', '2023-04-20 14:54:20'),
(576, 198, 'action started via WP Cron', '2023-04-20 12:55:22', '2023-04-20 14:55:22'),
(577, 198, 'action complete via WP Cron', '2023-04-20 12:55:22', '2023-04-20 14:55:22'),
(578, 199, 'action created', '2023-04-21 06:30:25', '2023-04-21 08:30:25'),
(579, 199, 'action started via WP Cron', '2023-04-21 06:31:28', '2023-04-21 08:31:28'),
(580, 199, 'action complete via WP Cron', '2023-04-21 06:31:28', '2023-04-21 08:31:28'),
(581, 200, 'action created', '2023-04-21 06:32:51', '2023-04-21 08:32:51'),
(582, 200, 'action started via WP Cron', '2023-04-21 06:33:05', '2023-04-21 08:33:05'),
(583, 200, 'action complete via WP Cron', '2023-04-21 06:33:05', '2023-04-21 08:33:05'),
(584, 201, 'action created', '2023-04-21 06:33:05', '2023-04-21 08:33:05'),
(585, 202, 'action created', '2023-04-21 06:33:51', '2023-04-21 08:33:51'),
(586, 201, 'action started via Async Request', '2023-04-21 06:33:53', '2023-04-21 08:33:53'),
(587, 201, 'action complete via Async Request', '2023-04-21 06:33:53', '2023-04-21 08:33:53'),
(588, 202, 'action started via Async Request', '2023-04-21 06:33:53', '2023-04-21 08:33:53'),
(589, 202, 'action complete via Async Request', '2023-04-21 06:33:53', '2023-04-21 08:33:53'),
(590, 203, 'action created', '2023-04-21 06:35:02', '2023-04-21 08:35:02'),
(591, 203, 'action started via WP Cron', '2023-04-21 06:35:04', '2023-04-21 08:35:04'),
(592, 203, 'action complete via WP Cron', '2023-04-21 06:35:04', '2023-04-21 08:35:04'),
(593, 204, 'action created', '2023-04-21 06:36:09', '2023-04-21 08:36:09'),
(594, 205, 'action created', '2023-04-21 06:36:09', '2023-04-21 08:36:09'),
(595, 204, 'action started via WP Cron', '2023-04-21 06:37:05', '2023-04-21 08:37:05'),
(596, 204, 'action complete via WP Cron', '2023-04-21 06:37:05', '2023-04-21 08:37:05'),
(597, 205, 'action started via WP Cron', '2023-04-21 06:37:05', '2023-04-21 08:37:05'),
(598, 205, 'action complete via WP Cron', '2023-04-21 06:37:05', '2023-04-21 08:37:05'),
(599, 206, 'action created', '2023-04-21 06:37:31', '2023-04-21 08:37:31'),
(600, 207, 'action created', '2023-04-21 06:37:31', '2023-04-21 08:37:31') ;
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(601, 208, 'action created', '2023-04-21 06:37:31', '2023-04-21 08:37:31'),
(602, 206, 'action started via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(603, 206, 'action complete via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(604, 207, 'action started via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(605, 207, 'action complete via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(606, 208, 'action started via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(607, 208, 'action complete via WP Cron', '2023-04-21 06:38:14', '2023-04-21 08:38:14'),
(608, 209, 'action created', '2023-04-21 06:38:25', '2023-04-21 08:38:25'),
(609, 210, 'action created', '2023-04-21 06:38:25', '2023-04-21 08:38:25'),
(610, 211, 'action created', '2023-04-21 06:38:25', '2023-04-21 08:38:25'),
(611, 209, 'action started via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(612, 209, 'action complete via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(613, 210, 'action started via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(614, 210, 'action complete via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(615, 211, 'action started via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(616, 211, 'action complete via WP Cron', '2023-04-21 06:39:32', '2023-04-21 08:39:32'),
(617, 212, 'action created', '2023-04-21 06:43:56', '2023-04-21 08:43:56'),
(618, 212, 'action started via WP Cron', '2023-04-21 06:44:17', '2023-04-21 08:44:17'),
(619, 212, 'action complete via WP Cron', '2023-04-21 06:44:17', '2023-04-21 08:44:17'),
(620, 213, 'action created', '2023-04-21 06:58:23', '2023-04-21 08:58:23'),
(621, 214, 'action created', '2023-04-21 06:58:23', '2023-04-21 08:58:23'),
(622, 213, 'action started via Async Request', '2023-04-21 06:58:45', '2023-04-21 08:58:45'),
(623, 213, 'action complete via Async Request', '2023-04-21 06:58:45', '2023-04-21 08:58:45'),
(624, 214, 'action started via Async Request', '2023-04-21 06:58:45', '2023-04-21 08:58:45'),
(625, 214, 'action complete via Async Request', '2023-04-21 06:58:45', '2023-04-21 08:58:45'),
(626, 215, 'action created', '2023-04-21 06:59:06', '2023-04-21 08:59:06'),
(627, 216, 'action created', '2023-04-21 06:59:06', '2023-04-21 08:59:06'),
(628, 215, 'action started via WP Cron', '2023-04-21 07:00:22', '2023-04-21 09:00:22'),
(629, 215, 'action complete via WP Cron', '2023-04-21 07:00:22', '2023-04-21 09:00:22'),
(630, 216, 'action started via WP Cron', '2023-04-21 07:00:22', '2023-04-21 09:00:22'),
(631, 216, 'action complete via WP Cron', '2023-04-21 07:00:22', '2023-04-21 09:00:22'),
(632, 217, 'action created', '2023-04-21 07:04:41', '2023-04-21 09:04:41'),
(633, 217, 'action started via WP Cron', '2023-04-21 07:05:06', '2023-04-21 09:05:06'),
(634, 217, 'action complete via WP Cron', '2023-04-21 07:05:06', '2023-04-21 09:05:06'),
(635, 218, 'action created', '2023-04-21 07:05:45', '2023-04-21 09:05:45'),
(636, 218, 'action started via WP Cron', '2023-04-21 07:06:08', '2023-04-21 09:06:08'),
(637, 218, 'action complete via WP Cron', '2023-04-21 07:06:09', '2023-04-21 09:06:09'),
(638, 8, 'action started via WP Cron', '2023-04-21 09:57:55', '2023-04-21 11:57:55'),
(639, 8, 'action complete via WP Cron', '2023-04-21 09:57:55', '2023-04-21 11:57:55'),
(640, 219, 'action created', '2023-04-21 09:57:55', '2023-04-21 11:57:55'),
(641, 220, 'action created', '2023-04-21 11:12:28', '2023-04-21 13:12:28'),
(642, 220, 'action started via WP Cron', '2023-04-21 11:13:10', '2023-04-21 13:13:10'),
(643, 220, 'action complete via WP Cron', '2023-04-21 11:13:10', '2023-04-21 13:13:10'),
(644, 221, 'action created', '2023-04-21 11:33:22', '2023-04-21 13:33:22'),
(645, 221, 'action started via WP Cron', '2023-04-21 11:34:54', '2023-04-21 13:34:54'),
(646, 221, 'action complete via WP Cron', '2023-04-21 11:34:54', '2023-04-21 13:34:54'),
(647, 222, 'action created', '2023-04-21 11:47:13', '2023-04-21 13:47:13'),
(648, 222, 'action started via Async Request', '2023-04-21 11:47:31', '2023-04-21 13:47:31'),
(649, 222, 'action complete via Async Request', '2023-04-21 11:47:31', '2023-04-21 13:47:31'),
(650, 223, 'action created', '2023-04-21 11:49:06', '2023-04-21 13:49:06'),
(651, 223, 'action started via Async Request', '2023-04-21 11:49:45', '2023-04-21 13:49:45'),
(652, 223, 'action complete via Async Request', '2023-04-21 11:49:45', '2023-04-21 13:49:45') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10)),
  KEY `woo_idx_comment_type` (`comment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'En kommentarsförfattare', 'wapuu@wordpress.example', 'https://sv.wordpress.org/', '', '2023-04-20 11:41:33', '2023-04-20 09:41:33', 'Hej, det här är en kommentar.\nFör att komma igång med granskning, redigering och borttagning av kommentarer, gå till vyn ”Kommentarer” i adminpanelen.\nKommentarsförfattares profilbilder kommer från <a href="https://sv.gravatar.com/">Gravatar</a>.', 0, 'post-trashed', '', 'comment', 0, 0),
(2, 99, 'WooCommerce', '', '', '', '2023-04-20 14:33:16', '2023-04-20 12:33:16', 'Payment to be made upon delivery. Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(3, 100, 'WooCommerce', '', '', '', '2023-04-20 14:36:35', '2023-04-20 12:36:35', 'Payment to be made upon delivery. Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(4, 100, 'medie-admin', 'henrikutbildare@gmail.com', '', '', '2023-04-20 14:42:41', '2023-04-20 12:42:41', 'Order status changed from On hold to Completed.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(5, 99, 'medie-admin', 'henrikutbildare@gmail.com', '', '', '2023-04-20 14:47:54', '2023-04-20 12:47:54', 'Order status changed from On hold to Completed.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(6, 114, 'WooCommerce', '', '', '', '2023-04-21 09:04:41', '2023-04-21 07:04:41', 'Payment to be made upon delivery. Order status changed from Pending payment to On hold.', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(7, 114, 'medie-admin', 'henrikutbildare@gmail.com', '', '', '2023-04-21 09:05:47', '2023-04-21 07:05:47', 'Order status changed from On hold to Completed.', 0, '1', 'WooCommerce', 'order_note', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1504 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/WP-Mega', 'yes'),
(2, 'home', 'http://localhost/WP-Mega', 'yes'),
(3, 'blogname', 'Mega Shop', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'henrikutbildare@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'Y-m-d H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:188:{s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:7:"shop/?$";s:27:"index.php?post_type=product";s:37:"shop/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:32:"shop/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:24:"shop/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:21:"^index.php/wp-json/?$";s:22:"index.php?rest_route=/";s:24:"^index.php/wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:17:"^wp-sitemap\\.xml$";s:23:"index.php?sitemap=index";s:17:"^wp-sitemap\\.xsl$";s:36:"index.php?sitemap-stylesheet=sitemap";s:23:"^wp-sitemap-index\\.xsl$";s:34:"index.php?sitemap-stylesheet=index";s:48:"^wp-sitemap-([a-z]+?)-([a-z\\d_-]+?)-(\\d+?)\\.xml$";s:75:"index.php?sitemap=$matches[1]&sitemap-subtype=$matches[2]&paged=$matches[3]";s:34:"^wp-sitemap-([a-z]+?)-(\\d+?)\\.xml$";s:47:"index.php?sitemap=$matches[1]&paged=$matches[2]";s:8:"greet/?$";s:25:"index.php?post_type=greet";s:38:"greet/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=greet&feed=$matches[1]";s:33:"greet/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?post_type=greet&feed=$matches[1]";s:25:"greet/page/([0-9]{1,})/?$";s:43:"index.php?post_type=greet&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:55:"product-category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:50:"product-category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:31:"product-category/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:43:"product-category/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:25:"product-category/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:52:"product-tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:47:"product-tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:28:"product-tag/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:40:"product-tag/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:22:"product-tag/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"product/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"product/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"product/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"product/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"product/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"product/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"product/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"product/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"product/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"product/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"product/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"product/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"product/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"product/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"product/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"product/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"product/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"product/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"product/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"product/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:33:"greet/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:43:"greet/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:63:"greet/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"greet/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:58:"greet/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:39:"greet/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:22:"greet/([^/]+)/embed/?$";s:38:"index.php?greet=$matches[1]&embed=true";s:26:"greet/([^/]+)/trackback/?$";s:32:"index.php?greet=$matches[1]&tb=1";s:46:"greet/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?greet=$matches[1]&feed=$matches[2]";s:41:"greet/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?greet=$matches[1]&feed=$matches[2]";s:34:"greet/([^/]+)/page/?([0-9]{1,})/?$";s:45:"index.php?greet=$matches[1]&paged=$matches[2]";s:41:"greet/([^/]+)/comment-page-([0-9]{1,})/?$";s:45:"index.php?greet=$matches[1]&cpage=$matches[2]";s:31:"greet/([^/]+)/wc-api(/(.*))?/?$";s:46:"index.php?greet=$matches[1]&wc-api=$matches[3]";s:37:"greet/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:48:"greet/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:30:"greet/([^/]+)(?:/([0-9]+))?/?$";s:44:"index.php?greet=$matches[1]&page=$matches[2]";s:22:"greet/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:32:"greet/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:52:"greet/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"greet/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:47:"greet/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"greet/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:38:"index.php?&page_id=6&cpage=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:53:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/embed/?$";s:91:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:62:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/wc-api(/(.*))?/?$";s:99:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&wc-api=$matches[6]";s:62:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:73:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:61:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(?:/([0-9]+))?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:53:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:25:"(.?.+?)/orders(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&orders=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:28:"(.?.+?)/downloads(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&downloads=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:34:"(.?.+?)/payment-methods(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&payment-methods=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:40:"(.?.+?)/delete-payment-method(/(.*))?/?$";s:64:"index.php?pagename=$matches[1]&delete-payment-method=$matches[3]";s:45:"(.?.+?)/set-default-payment-method(/(.*))?/?$";s:69:"index.php?pagename=$matches[1]&set-default-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:27:"weeklygreet/weeklygreet.php";i:1;s:45:"woocommerce-services/woocommerce-services.php";i:2;s:27:"woocommerce/woocommerce.php";i:3;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'blocksy', 'yes'),
(41, 'stylesheet', 'blocksy-child', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '53496', 'yes'),
(47, 'uploads_use_yearmonth_folders', '', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', '', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:1:{s:45:"woocommerce-services/woocommerce-services.php";a:2:{i:0;s:17:"WC_Connect_Loader";i:1;s:16:"plugin_uninstall";}}', 'no'),
(80, 'timezone_string', 'Europe/Stockholm', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '6', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1697535693', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '53496', 'yes'),
(100, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:114:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop manager";s:12:"capabilities";a:92:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"edit_theme_options";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'sv_SE', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:159:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste inläggen</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:231:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Senaste kommentarer</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:143:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Arkiv</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:150:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Kategorier</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(105, 'sidebars_widgets', 'a:10:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:19:"sidebar-woocommerce";a:0:{}s:19:"ct-footer-sidebar-1";a:0:{}s:19:"ct-footer-sidebar-2";a:0:{}s:19:"ct-footer-sidebar-3";a:0:{}s:19:"ct-footer-sidebar-4";a:0:{}s:19:"ct-footer-sidebar-5";a:0:{}s:19:"ct-footer-sidebar-6";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:19:{i:1682078644;a:1:{s:26:"action_scheduler_run_queue";a:1:{s:32:"0d04ed39571b55704c122d726248bbac";a:3:{s:8:"schedule";s:12:"every_minute";s:4:"args";a:1:{i:0;s:7:"WP Cron";}s:8:"interval";i:60;}}}i:1682080893;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682081045;a:2:{s:24:"woocommerce_cleanup_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:31:"woocommerce_cleanup_rate_limits";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682081046;a:1:{s:33:"wc_admin_process_orders_milestone";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682081054;a:1:{s:29:"wc_admin_unsnooze_admin_notes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1682081956;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1682091845;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682113293;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682113299;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1682114400;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682156493;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682156499;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682156501;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682156645;a:1:{s:14:"wc_admin_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682156655;a:2:{s:33:"woocommerce_cleanup_personal_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682161208;a:1:{s:20:"jetpack_v2_heartbeat";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1682674893;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1683279905;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:11:"fifteendays";s:4:"args";a:0:{}s:8:"interval";i:1296000;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:0:{}', 'yes'),
(125, 'theme_mods_twentytwentythree', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1681983943;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(131, 'https_detection_errors', 'a:1:{s:20:"https_request_failed";a:1:{i:0;s:28:"HTTPS-begäran misslyckades.";}}', 'yes'),
(141, 'can_compress_scripts', '0', 'no'),
(159, 'finished_updating_comment_type', '1', 'yes'),
(160, 'recently_activated', 'a:1:{s:19:"jetpack/jetpack.php";i:1681995260;}', 'yes'),
(165, 'action_scheduler_hybrid_store_demarkation', '5', 'yes'),
(166, 'schema-ActionScheduler_StoreSchema', '6.0.1681983844', 'yes'),
(167, 'schema-ActionScheduler_LoggerSchema', '3.0.1681983844', 'yes'),
(170, 'woocommerce_schema_version', '430', 'yes'),
(171, 'woocommerce_store_address', 'Gatan7', 'yes'),
(172, 'woocommerce_store_address_2', '', 'yes'),
(173, 'woocommerce_store_city', 'Kohagen', 'yes'),
(174, 'woocommerce_default_country', 'SE', 'yes'),
(175, 'woocommerce_store_postcode', '444 22', 'yes'),
(176, 'woocommerce_allowed_countries', 'all', 'yes'),
(177, 'woocommerce_all_except_countries', 'a:0:{}', 'yes'),
(178, 'woocommerce_specific_allowed_countries', 'a:0:{}', 'yes'),
(179, 'woocommerce_ship_to_countries', '', 'yes'),
(180, 'woocommerce_specific_ship_to_countries', 'a:0:{}', 'yes'),
(181, 'woocommerce_default_customer_address', 'base', 'yes'),
(182, 'woocommerce_calc_taxes', 'yes', 'yes'),
(183, 'woocommerce_enable_coupons', 'yes', 'yes'),
(184, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(185, 'woocommerce_currency', 'SEK', 'yes'),
(186, 'woocommerce_currency_pos', 'right_space', 'yes'),
(187, 'woocommerce_price_thousand_sep', '', 'yes'),
(188, 'woocommerce_price_decimal_sep', ',', 'yes'),
(189, 'woocommerce_price_num_decimals', '0', 'yes'),
(190, 'woocommerce_shop_page_id', '6', 'yes'),
(191, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(192, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(193, 'woocommerce_placeholder_image', '5', 'yes'),
(194, 'woocommerce_weight_unit', 'kg', 'yes'),
(195, 'woocommerce_dimension_unit', 'cm', 'yes'),
(196, 'woocommerce_enable_reviews', 'yes', 'yes'),
(197, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(198, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(199, 'woocommerce_enable_review_rating', 'yes', 'yes'),
(200, 'woocommerce_review_rating_required', 'yes', 'no'),
(201, 'woocommerce_manage_stock', 'yes', 'yes'),
(202, 'woocommerce_hold_stock_minutes', '60', 'no'),
(203, 'woocommerce_notify_low_stock', 'yes', 'no'),
(204, 'woocommerce_notify_no_stock', 'yes', 'no'),
(205, 'woocommerce_stock_email_recipient', 'henrikutbildare@gmail.com', 'no'),
(206, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(207, 'woocommerce_notify_no_stock_amount', '0', 'yes'),
(208, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(209, 'woocommerce_stock_format', '', 'yes'),
(210, 'woocommerce_file_download_method', 'force', 'no'),
(211, 'woocommerce_downloads_redirect_fallback_allowed', 'no', 'no'),
(212, 'woocommerce_downloads_require_login', 'no', 'no'),
(213, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(214, 'woocommerce_downloads_deliver_inline', '', 'no'),
(215, 'woocommerce_downloads_add_hash_to_filename', 'yes', 'yes'),
(216, 'woocommerce_attribute_lookup_enabled', 'no', 'yes'),
(217, 'woocommerce_attribute_lookup_direct_updates', 'no', 'yes'),
(218, 'woocommerce_prices_include_tax', 'yes', 'yes'),
(219, 'woocommerce_tax_based_on', 'billing', 'yes'),
(220, 'woocommerce_shipping_tax_class', 'inherit', 'yes'),
(221, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(222, 'woocommerce_tax_classes', '', 'yes'),
(223, 'woocommerce_tax_display_shop', 'incl', 'yes'),
(224, 'woocommerce_tax_display_cart', 'incl', 'yes'),
(225, 'woocommerce_price_display_suffix', '', 'yes'),
(226, 'woocommerce_tax_total_display', 'single', 'no'),
(227, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(228, 'woocommerce_shipping_cost_requires_address', 'no', 'yes'),
(229, 'woocommerce_ship_to_destination', 'billing', 'no'),
(230, 'woocommerce_shipping_debug_mode', 'no', 'yes'),
(231, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(232, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(233, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(234, 'woocommerce_enable_myaccount_registration', 'yes', 'no'),
(235, 'woocommerce_registration_generate_username', 'yes', 'no'),
(236, 'woocommerce_registration_generate_password', 'yes', 'no'),
(237, 'woocommerce_erasure_request_removes_order_data', 'no', 'no'),
(238, 'woocommerce_erasure_request_removes_download_data', 'no', 'no'),
(239, 'woocommerce_allow_bulk_remove_personal_data', 'no', 'no'),
(240, 'woocommerce_registration_privacy_policy_text', 'Your personal data will be used to support your experience throughout this website, to manage access to your account, and for other purposes described in our [privacy_policy].', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(241, 'woocommerce_checkout_privacy_policy_text', 'Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our [privacy_policy].', 'yes'),
(242, 'woocommerce_delete_inactive_accounts', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(243, 'woocommerce_trash_pending_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(244, 'woocommerce_trash_failed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(245, 'woocommerce_trash_cancelled_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:4:"days";}', 'no'),
(246, 'woocommerce_anonymize_completed_orders', 'a:2:{s:6:"number";s:0:"";s:4:"unit";s:6:"months";}', 'no'),
(247, 'woocommerce_email_from_name', 'Mega Shop', 'no'),
(248, 'woocommerce_email_from_address', 'henrikutbildare@gmail.com', 'no'),
(249, 'woocommerce_email_header_image', '', 'no'),
(250, 'woocommerce_email_footer_text', '{site_title} &mdash; Built with {WooCommerce}', 'no'),
(251, 'woocommerce_email_base_color', '#7f54b3', 'no'),
(252, 'woocommerce_email_background_color', '#f7f7f7', 'no'),
(253, 'woocommerce_email_body_background_color', '#ffffff', 'no'),
(254, 'woocommerce_email_text_color', '#3c3c3c', 'no'),
(255, 'woocommerce_merchant_email_notifications', 'no', 'no'),
(256, 'woocommerce_cart_page_id', '7', 'no'),
(257, 'woocommerce_checkout_page_id', '8', 'no'),
(258, 'woocommerce_myaccount_page_id', '9', 'no'),
(259, 'woocommerce_terms_page_id', '', 'no'),
(260, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(261, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(262, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(263, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(264, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(265, 'woocommerce_myaccount_delete_payment_method_endpoint', 'delete-payment-method', 'yes'),
(266, 'woocommerce_myaccount_set_default_payment_method_endpoint', 'set-default-payment-method', 'yes'),
(267, 'woocommerce_myaccount_orders_endpoint', 'orders', 'yes'),
(268, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(269, 'woocommerce_myaccount_downloads_endpoint', 'downloads', 'yes'),
(270, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(271, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(272, 'woocommerce_myaccount_payment_methods_endpoint', 'payment-methods', 'yes'),
(273, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(274, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(275, 'woocommerce_api_enabled', 'no', 'yes'),
(276, 'woocommerce_allow_tracking', 'no', 'no'),
(277, 'woocommerce_show_marketplace_suggestions', 'yes', 'no'),
(278, 'woocommerce_analytics_enabled', 'yes', 'yes'),
(279, 'woocommerce_navigation_enabled', 'no', 'yes'),
(280, 'woocommerce_new_product_management_enabled', 'no', 'yes'),
(281, 'woocommerce_feature_custom_order_tables_enabled', 'no', 'yes'),
(282, 'woocommerce_single_image_width', '600', 'yes'),
(283, 'woocommerce_thumbnail_image_width', '300', 'yes'),
(284, 'woocommerce_checkout_highlight_required_fields', 'yes', 'yes'),
(285, 'woocommerce_demo_store', 'no', 'no'),
(286, 'wc_downloads_approved_directories_mode', 'enabled', 'yes'),
(287, 'woocommerce_permalinks', 'a:5:{s:12:"product_base";s:7:"product";s:13:"category_base";s:16:"product-category";s:8:"tag_base";s:11:"product-tag";s:14:"attribute_base";s:0:"";s:22:"use_verbose_page_rules";b:0;}', 'yes'),
(288, 'current_theme_supports_woocommerce', 'yes', 'yes'),
(289, 'woocommerce_queue_flush_rewrite_rules', 'no', 'yes'),
(292, 'default_product_cat', '15', 'yes'),
(294, 'woocommerce_refund_returns_page_id', '10', 'yes'),
(297, 'woocommerce_paypal_settings', 'a:23:{s:7:"enabled";s:2:"no";s:5:"title";s:6:"PayPal";s:11:"description";s:85:"Pay via PayPal; you can pay with your credit card if you don\'t have a PayPal account.";s:5:"email";s:25:"henrikutbildare@gmail.com";s:8:"advanced";s:0:"";s:8:"testmode";s:2:"no";s:5:"debug";s:2:"no";s:16:"ipn_notification";s:3:"yes";s:14:"receiver_email";s:25:"henrikutbildare@gmail.com";s:14:"identity_token";s:0:"";s:14:"invoice_prefix";s:3:"WC-";s:13:"send_shipping";s:3:"yes";s:16:"address_override";s:2:"no";s:13:"paymentaction";s:4:"sale";s:9:"image_url";s:0:"";s:11:"api_details";s:0:"";s:12:"api_username";s:0:"";s:12:"api_password";s:0:"";s:13:"api_signature";s:0:"";s:20:"sandbox_api_username";s:0:"";s:20:"sandbox_api_password";s:0:"";s:21:"sandbox_api_signature";s:0:"";s:12:"_should_load";s:2:"no";}', 'yes'),
(298, 'woocommerce_version', '7.6.0', 'yes'),
(299, 'woocommerce_db_version', '7.6.0', 'yes'),
(300, 'woocommerce_admin_install_timestamp', '1681983846', 'yes'),
(301, 'woocommerce_inbox_variant_assignment', '8', 'yes'),
(306, 'action_scheduler_lock_async-request-runner', '1682078555', 'yes'),
(307, 'woocommerce_admin_notices', 'a:1:{i:0;s:20:"no_secure_connection";}', 'yes'),
(308, 'woocommerce_maxmind_geolocation_settings', 'a:1:{s:15:"database_prefix";s:32:"EfByt9o0Trcpi9rpdEjo4E8H5v7FHEFM";}', 'yes'),
(310, 'widget_woocommerce_widget_cart', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(311, 'widget_woocommerce_layered_nav_filters', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(312, 'widget_woocommerce_layered_nav', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(313, 'widget_woocommerce_price_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(314, 'widget_woocommerce_product_categories', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(315, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(316, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(317, 'widget_woocommerce_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(318, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(319, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(320, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(321, 'widget_woocommerce_rating_filter', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(331, 'wc_remote_inbox_notifications_stored_state', 'O:8:"stdClass":2:{s:22:"there_were_no_products";b:1;s:22:"there_are_now_products";b:1;}', 'no'),
(336, 'wc_blocks_db_schema_version', '260', 'yes'),
(348, 'woocommerce_task_list_tracked_completed_tasks', 'a:7:{i:0;s:8:"purchase";i:1;s:13:"store_details";i:2;s:8:"shipping";i:3;s:8:"products";i:4;s:15:"review-shipping";i:5;s:8:"payments";i:6;s:3:"tax";}', 'yes'),
(356, 'woocommerce_onboarding_profile', 'a:11:{s:18:"is_agree_marketing";b:0;s:11:"store_email";s:25:"henrikutbildare@gmail.com";s:20:"is_store_country_set";b:1;s:8:"industry";a:1:{i:0;a:1:{s:4:"slug";s:27:"fashion-apparel-accessories";}}s:13:"product_types";a:2:{i:0;s:8:"physical";i:1;s:9:"downloads";}s:13:"product_count";s:4:"1-10";s:14:"selling_venues";s:2:"no";s:12:"setup_client";b:0;s:19:"business_extensions";a:0:{}s:5:"theme";s:10:"storefront";s:9:"completed";b:1;}', 'yes'),
(357, 'woocommerce_task_list_dismissed_tasks', 'a:0:{}', 'yes'),
(364, 'current_theme', 'Blocksy-child', 'yes'),
(365, 'theme_switched', '', 'yes'),
(366, 'theme_mods_storefront', 'a:3:{s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1681986696;s:4:"data";a:7:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:8:"header-1";a:0:{}s:8:"footer-1";a:0:{}s:8:"footer-2";a:0:{}s:8:"footer-3";a:0:{}s:8:"footer-4";a:0:{}}}}', 'yes'),
(367, 'woocommerce_catalog_rows', '4', 'yes'),
(368, 'woocommerce_catalog_columns', '3', 'yes'),
(369, 'woocommerce_maybe_regenerate_images_hash', '49a4f2b458b3338b96cfc25d8aef8745', 'yes'),
(371, 'storefront_nux_fresh_site', '0', 'yes'),
(379, 'woocommerce_admin_created_default_shipping_zones', 'yes', 'yes'),
(381, 'woocommerce_task_list_prompt_shown', '1', 'yes'),
(398, 'theme_mods_blocksy', 'a:13:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:38:"blocksy_woocommerce_thumbnail_cropping";s:6:"custom";s:18:"custom_css_post_id";i:-1;s:21:"single_page_structure";s:6:"type-4";s:24:"single_page_hero_enabled";s:3:"yes";s:35:"single_blog_post_has_featured_image";s:3:"yes";s:30:"single_blog_post_has_post_tags";s:3:"yes";s:30:"single_blog_post_has_share_box";s:3:"yes";s:34:"single_blog_post_has_related_posts";s:3:"yes";s:16:"sidebars_widgets";a:2:{s:4:"time";i:1682061661;s:4:"data";a:9:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:19:"sidebar-woocommerce";a:0:{}s:19:"ct-footer-sidebar-1";a:0:{}s:19:"ct-footer-sidebar-2";a:0:{}s:19:"ct-footer-sidebar-3";a:0:{}s:19:"ct-footer-sidebar-4";a:0:{}s:19:"ct-footer-sidebar-5";a:0:{}s:19:"ct-footer-sidebar-6";a:0:{}}}s:25:"single_page_content_style";a:4:{s:7:"desktop";s:5:"boxed";s:6:"tablet";s:5:"boxed";s:6:"mobile";s:5:"boxed";s:9:"__changed";a:0:{}}s:32:"single_page_content_area_spacing";s:3:"top";}', 'yes'),
(399, 'elementor_disable_color_schemes', 'yes', 'yes'),
(400, 'elementor_disable_typography_schemes', 'yes', 'yes'),
(401, 'elementor_viewport_lg', '1000', 'yes'),
(402, 'elementor_viewport_md', '690', 'yes'),
(404, 'woocommerce_thumbnail_cropping', 'custom', 'yes'),
(405, 'woocommerce_thumbnail_cropping_custom_width', '3', 'yes'),
(406, 'woocommerce_thumbnail_cropping_custom_height', '4', 'yes'),
(414, 'blocksy_db_version', '1.8.83', 'yes'),
(532, 'dismissed-blocksy_plugin_notice', '1', 'yes'),
(820, 'woocommerce_admin_reviewed_default_shipping_zones', 'yes', 'yes'),
(822, 'woocommerce_flat_rate_2_settings', 'a:6:{s:5:"title";s:9:"Flat rate";s:10:"tax_status";s:7:"taxable";s:4:"cost";s:2:"50";s:13:"class_cost_25";s:3:"199";s:13:"no_class_cost";s:0:"";s:4:"type";s:5:"class";}', 'yes'),
(823, 'woocommerce_local_pickup_3_settings', 'a:3:{s:5:"title";s:12:"Local pickup";s:10:"tax_status";s:4:"none";s:4:"cost";s:0:"";}', 'yes'),
(826, 'woocommerce_cod_settings', 'a:6:{s:7:"enabled";s:3:"yes";s:5:"title";s:22:"Betala vid avhämtning";s:11:"description";s:28:"Pay with cash upon delivery.";s:12:"instructions";s:28:"Pay with cash upon delivery.";s:18:"enable_for_methods";s:0:"";s:18:"enable_for_virtual";s:3:"yes";}', 'yes'),
(846, 'jetpack_connection_active_plugins', 'a:1:{s:7:"jetpack";a:1:{s:4:"name";s:7:"Jetpack";}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(851, 'wc_connect_options', 'a:1:{s:12:"tos_accepted";b:1;}', 'yes'),
(852, 'do_activate', '0', 'yes'),
(897, 'woocommerce_free_shipping_1_settings', 'a:4:{s:5:"title";s:13:"Free shipping";s:8:"requires";s:6:"either";s:10:"min_amount";s:3:"500";s:16:"ignore_discounts";s:3:"yes";}', 'yes'),
(1022, 'woocommerce_orders_report_date_tour_shown', 'yes', 'yes'),
(1049, 'woocommerce_admin_last_orders_milestone', '1', 'yes'),
(1052, 'woocommerce_revenue_report_date_tour_shown', 'yes', 'yes'),
(1119, 'action_scheduler_migration_status', 'complete', 'yes'),
(1170, 'product_cat_children', 'a:0:{}', 'yes'),
(1229, 'theme_mods_blocksy-child', 'a:21:{i:0;b:0;s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:14:"selectionColor";a:2:{s:7:"default";a:1:{s:5:"color";s:7:"#ffffff";}s:5:"hover";a:1:{s:5:"color";s:7:"#28befa";}}s:12:"colorPalette";a:10:{s:6:"color1";a:1:{s:5:"color";s:7:"#3eaf7c";}s:6:"color2";a:1:{s:5:"color";s:7:"#33a370";}s:6:"color3";a:1:{s:5:"color";s:7:"#415161";}s:6:"color4";a:1:{s:5:"color";s:7:"#2c3e50";}s:6:"color5";a:1:{s:5:"color";s:7:"#E2E7ED";}s:6:"color6";a:1:{s:5:"color";s:7:"#edeff2";}s:6:"color7";a:1:{s:5:"color";s:7:"#f8f9fb";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}s:15:"current_palette";s:9:"palette-1";s:8:"palettes";a:15:{i:0;a:9:{s:2:"id";s:9:"palette-2";s:6:"color1";a:1:{s:5:"color";s:7:"#2872fa";}s:6:"color2";a:1:{s:5:"color";s:7:"#1559ed";}s:6:"color3";a:1:{s:5:"color";s:7:"#3A4F66";}s:6:"color4";a:1:{s:5:"color";s:7:"#192a3d";}s:6:"color5";a:1:{s:5:"color";s:7:"#e1e8ed";}s:6:"color6";a:1:{s:5:"color";s:7:"#f2f5f7";}s:6:"color7";a:1:{s:5:"color";s:7:"#FAFBFC";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:1;a:9:{s:2:"id";s:9:"palette-1";s:6:"color1";a:1:{s:5:"color";s:7:"#3eaf7c";}s:6:"color2";a:1:{s:5:"color";s:7:"#33a370";}s:6:"color3";a:1:{s:5:"color";s:7:"#415161";}s:6:"color4";a:1:{s:5:"color";s:7:"#2c3e50";}s:6:"color5";a:1:{s:5:"color";s:7:"#E2E7ED";}s:6:"color6";a:1:{s:5:"color";s:7:"#edeff2";}s:6:"color7";a:1:{s:5:"color";s:7:"#f8f9fb";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:2;a:9:{s:2:"id";s:9:"palette-3";s:6:"color1";a:1:{s:5:"color";s:7:"#FB7258";}s:6:"color2";a:1:{s:5:"color";s:7:"#F74D67";}s:6:"color3";a:1:{s:5:"color";s:7:"#6e6d76";}s:6:"color4";a:1:{s:5:"color";s:7:"#0e0c1b";}s:6:"color5";a:1:{s:5:"color";s:7:"#DFDFE2";}s:6:"color6";a:1:{s:5:"color";s:7:"#F4F4F5";}s:6:"color7";a:1:{s:5:"color";s:7:"#FBFBFB";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:3;a:9:{s:2:"id";s:9:"palette-4";s:6:"color1";a:1:{s:5:"color";s:7:"#98c1d9";}s:6:"color2";a:1:{s:5:"color";s:7:"#E84855";}s:6:"color3";a:1:{s:5:"color";s:7:"#475671";}s:6:"color4";a:1:{s:5:"color";s:7:"#293241";}s:6:"color5";a:1:{s:5:"color";s:7:"#E7E9EF";}s:6:"color6";a:1:{s:5:"color";s:7:"#f3f4f7";}s:6:"color7";a:1:{s:5:"color";s:7:"#FBFBFC";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:4;a:9:{s:2:"id";s:9:"palette-5";s:6:"color1";a:1:{s:5:"color";s:7:"#006466";}s:6:"color2";a:1:{s:5:"color";s:7:"#065A60";}s:6:"color3";a:1:{s:5:"color";s:7:"#7F8C9A";}s:6:"color4";a:1:{s:5:"color";s:7:"#ffffff";}s:6:"color5";a:1:{s:5:"color";s:7:"#1e2933";}s:6:"color6";a:1:{s:5:"color";s:7:"#0F141A";}s:6:"color7";a:1:{s:5:"color";s:7:"#141b22";}s:6:"color8";a:1:{s:5:"color";s:7:"#1B242C";}}i:5;a:9:{s:2:"id";s:9:"palette-6";s:6:"color1";a:1:{s:5:"color";s:7:"#007f5f";}s:6:"color2";a:1:{s:5:"color";s:7:"#55a630";}s:6:"color3";a:1:{s:5:"color";s:7:"#365951";}s:6:"color4";a:1:{s:5:"color";s:7:"#192c27";}s:6:"color5";a:1:{s:5:"color";s:7:"#E6F0EE";}s:6:"color6";a:1:{s:5:"color";s:7:"#F2F7F6";}s:6:"color7";a:1:{s:5:"color";s:7:"#FBFCFC";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:6;a:9:{s:2:"id";s:9:"palette-7";s:6:"color1";a:1:{s:5:"color";s:7:"#7456f1";}s:6:"color2";a:1:{s:5:"color";s:7:"#5e3fde";}s:6:"color3";a:1:{s:5:"color";s:7:"#4d5d6d";}s:6:"color4";a:1:{s:5:"color";s:7:"#102136";}s:6:"color5";a:1:{s:5:"color";s:7:"#E7EBEE";}s:6:"color6";a:1:{s:5:"color";s:7:"#F3F5F7";}s:6:"color7";a:1:{s:5:"color";s:7:"#FBFBFC";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:7;a:9:{s:2:"id";s:9:"palette-8";s:6:"color1";a:1:{s:5:"color";s:7:"#00509d";}s:6:"color2";a:1:{s:5:"color";s:7:"#003f88";}s:6:"color3";a:1:{s:5:"color";s:7:"#828487";}s:6:"color4";a:1:{s:5:"color";s:7:"#28292a";}s:6:"color5";a:1:{s:5:"color";s:7:"#e8ebed";}s:6:"color6";a:1:{s:5:"color";s:7:"#f4f5f6";}s:6:"color7";a:1:{s:5:"color";s:7:"#FBFBFC";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:8;a:9:{s:2:"id";s:9:"palette-9";s:6:"color1";a:1:{s:5:"color";s:7:"#84a98c";}s:6:"color2";a:1:{s:5:"color";s:7:"#52796f";}s:6:"color3";a:1:{s:5:"color";s:7:"#cad2c5";}s:6:"color4";a:1:{s:5:"color";s:7:"#84a98c";}s:6:"color5";a:1:{s:5:"color";s:7:"#384b56";}s:6:"color6";a:1:{s:5:"color";s:7:"#212b31";}s:6:"color7";a:1:{s:5:"color";s:7:"#29363d";}s:6:"color8";a:1:{s:5:"color";s:7:"#314149";}}i:9;a:9:{s:2:"id";s:10:"palette-10";s:6:"color1";a:1:{s:5:"color";s:7:"#ff6d00";}s:6:"color2";a:1:{s:5:"color";s:7:"#ff8500";}s:6:"color3";a:1:{s:5:"color";s:7:"#cfa9ef";}s:6:"color4";a:1:{s:5:"color";s:7:"#e3cbf6";}s:6:"color5";a:1:{s:5:"color";s:7:"#5a189a";}s:6:"color6";a:1:{s:5:"color";s:7:"#240046";}s:6:"color7";a:1:{s:5:"color";s:7:"#3c096c";}s:6:"color8";a:1:{s:5:"color";s:7:"#410a75";}}i:10;a:9:{s:2:"id";s:10:"palette-11";s:6:"color1";a:1:{s:5:"color";s:7:"#ffcd05";}s:6:"color2";a:1:{s:5:"color";s:7:"#fcb424";}s:6:"color3";a:1:{s:5:"color";s:7:"#504e4a";}s:6:"color4";a:1:{s:5:"color";s:7:"#0a0500";}s:6:"color5";a:1:{s:5:"color";s:7:"#edeff2";}s:6:"color6";a:1:{s:5:"color";s:7:"#f9fafb";}s:6:"color7";a:1:{s:5:"color";s:7:"#FDFDFD";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:11;a:9:{s:2:"id";s:10:"palette-12";s:6:"color1";a:1:{s:5:"color";s:7:"#a8977b";}s:6:"color2";a:1:{s:5:"color";s:7:"#7f715c";}s:6:"color3";a:1:{s:5:"color";s:7:"#3f4245";}s:6:"color4";a:1:{s:5:"color";s:7:"#111518";}s:6:"color5";a:1:{s:5:"color";s:7:"#eaeaec";}s:6:"color6";a:1:{s:5:"color";s:7:"#f4f4f5";}s:6:"color7";a:1:{s:5:"color";s:7:"#ffffff";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:12;a:9:{s:2:"id";s:10:"palette-13";s:6:"color1";a:1:{s:5:"color";s:7:"#48bca2";}s:6:"color2";a:1:{s:5:"color";s:7:"#25ad99";}s:6:"color3";a:1:{s:5:"color";s:7:"#4f4f4f";}s:6:"color4";a:1:{s:5:"color";s:7:"#0a0500";}s:6:"color5";a:1:{s:5:"color";s:7:"#EBEBEB";}s:6:"color6";a:1:{s:5:"color";s:7:"#F5F5F5";}s:6:"color7";a:1:{s:5:"color";s:7:"#ffffff";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:13;a:9:{s:2:"id";s:10:"palette-14";s:6:"color1";a:1:{s:5:"color";s:7:"#ff6310";}s:6:"color2";a:1:{s:5:"color";s:7:"#fd7c47";}s:6:"color3";a:1:{s:5:"color";s:7:"#687279";}s:6:"color4";a:1:{s:5:"color";s:7:"#111518";}s:6:"color5";a:1:{s:5:"color";s:7:"#E9EBEC";}s:6:"color6";a:1:{s:5:"color";s:7:"#F4F5F6";}s:6:"color7";a:1:{s:5:"color";s:7:"#ffffff";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}i:14;a:9:{s:2:"id";s:10:"palette-15";s:6:"color1";a:1:{s:5:"color";s:7:"#fca311";}s:6:"color2";a:1:{s:5:"color";s:7:"#23396c";}s:6:"color3";a:1:{s:5:"color";s:7:"#707070";}s:6:"color4";a:1:{s:5:"color";s:7:"#000000";}s:6:"color5";a:1:{s:5:"color";s:7:"#e0e0e0";}s:6:"color6";a:1:{s:5:"color";s:7:"#f1f1f1";}s:6:"color7";a:1:{s:5:"color";s:7:"#fafafa";}s:6:"color8";a:1:{s:5:"color";s:7:"#ffffff";}}}}s:12:"border_color";a:1:{s:7:"default";a:1:{s:5:"color";s:7:"#7a7a7a";}}s:14:"blog_structure";s:4:"grid";s:21:"single_page_structure";s:6:"type-4";s:25:"single_page_content_style";a:4:{s:7:"desktop";s:5:"boxed";s:6:"tablet";s:5:"boxed";s:6:"mobile";s:5:"boxed";s:9:"__changed";a:0:{}}s:15:"shop_cards_type";s:6:"type-1";s:19:"product_image_hover";s:7:"zoom-in";s:22:"has_product_categories";s:2:"no";s:17:"cardProductRadius";a:4:{s:7:"desktop";a:5:{s:3:"top";s:3:"5px";s:6:"bottom";s:3:"5px";s:4:"left";s:3:"5px";s:5:"right";s:3:"5px";s:6:"linked";b:1;}s:6:"tablet";a:5:{s:3:"top";s:3:"5px";s:6:"bottom";s:3:"5px";s:4:"left";s:3:"5px";s:5:"right";s:3:"5px";s:6:"linked";b:1;}s:6:"mobile";a:5:{s:3:"top";s:3:"5px";s:6:"bottom";s:3:"5px";s:4:"left";s:3:"5px";s:5:"right";s:3:"5px";s:6:"linked";b:1;}s:9:"__changed";a:0:{}}s:26:"woo_categories_has_sidebar";s:2:"no";s:20:"has_ajax_add_to_cart";s:2:"no";s:27:"woo_categories_hero_section";s:6:"type-1";s:30:"woo_categories_hero_alignment2";a:4:{s:7:"desktop";s:6:"center";s:6:"tablet";s:6:"center";s:6:"mobile";s:6:"center";s:9:"__changed";a:0:{}}s:38:"woo_categories_hero_vertical_alignment";a:4:{s:7:"desktop";s:6:"center";s:6:"tablet";s:6:"center";s:6:"mobile";s:6:"center";s:9:"__changed";a:0:{}}s:29:"woo_categories_hero_structure";s:6:"narrow";s:11:"custom_logo";i:150;s:17:"header_placements";a:4:{s:15:"current_section";s:6:"type-1";s:8:"sections";a:1:{i:0;a:6:{s:2:"id";s:6:"type-1";s:4:"mode";s:10:"placements";s:5:"items";a:1:{i:0;a:2:{s:2:"id";s:4:"logo";s:6:"values";a:3:{s:11:"custom_logo";a:7:{i:0;i:150;i:1;i:150;i:2;i:150;s:7:"desktop";i:150;s:6:"tablet";i:150;s:6:"mobile";i:150;s:9:"__changed";a:0:{}}s:14:"has_site_title";s:2:"no";s:13:"logoMaxHeight";a:4:{s:7:"desktop";s:2:"60";s:6:"tablet";s:2:"60";s:6:"mobile";s:2:"60";s:9:"__changed";a:0:{}}}}}s:8:"settings";a:0:{}s:7:"desktop";a:4:{i:0;a:2:{s:2:"id";s:7:"top-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:0:{}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:0:{}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:1;a:2:{s:2:"id";s:10:"middle-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:1:{i:0;s:4:"logo";}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:2:{i:0;s:4:"menu";i:1;s:6:"search";}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:2;a:2:{s:2:"id";s:10:"bottom-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:0:{}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:0:{}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:3;a:2:{s:2:"id";s:9:"offcanvas";s:10:"placements";a:1:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:0:{}}}}}s:6:"mobile";a:4:{i:0;a:2:{s:2:"id";s:7:"top-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:0:{}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:0:{}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:1;a:2:{s:2:"id";s:10:"middle-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:1:{i:0;s:4:"logo";}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:1:{i:0;s:7:"trigger";}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:2;a:2:{s:2:"id";s:10:"bottom-row";s:10:"placements";a:5:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:0:{}}i:1;a:2:{s:2:"id";s:6:"middle";s:5:"items";a:0:{}}i:2;a:2:{s:2:"id";s:3:"end";s:5:"items";a:0:{}}i:3;a:2:{s:2:"id";s:12:"start-middle";s:5:"items";a:0:{}}i:4;a:2:{s:2:"id";s:10:"end-middle";s:5:"items";a:0:{}}}}i:3;a:2:{s:2:"id";s:9:"offcanvas";s:10:"placements";a:1:{i:0;a:2:{s:2:"id";s:5:"start";s:5:"items";a:1:{i:0;s:11:"mobile-menu";}}}}}}}s:18:"__should_refresh__";b:0;s:23:"__should_refresh_item__";s:16:"logo:custom_logo";}}', 'yes'),
(1331, 'woocommerce_sales_record_date', '2023-04-20', 'yes'),
(1332, 'woocommerce_sales_record_amount', '1198', 'yes'),
(1410, 'woocommerce_shop_page_display', '', 'yes'),
(1428, 'site_logo', '150', 'yes'),
(1482, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1682078593;}', 'no'),
(1495, 'wpmdb_folder_transfers_core_62bdff1c-3f09-428e-bdf9-7e33fd301129', 'a:1:{s:11:"wp-includes";a:10:{s:9:"nice_name";s:0:"";s:13:"relative_path";s:12:"\\wp-includes";s:6:"is_dir";b:0;s:13:"absolute_path";s:35:"C:\\MAMP\\htdocs\\WP-Mega\\\\wp-includes";s:9:"item_size";i:54806;s:4:"size";i:43684254;s:10:"batch_size";i:2907240;s:18:"folder_transferred";i:36864901;s:26:"folder_percent_transferred";d:0.84389448426886259913004550980986095964908599853515625;s:17:"total_transferred";i:3038875;}}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=1593 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', 'woocommerce-placeholder.png'),
(4, 5, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1200;s:6:"height";i:1200;s:4:"file";s:27:"woocommerce-placeholder.png";s:8:"filesize";i:102644;s:5:"sizes";a:7:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"woocommerce-placeholder-300x400.png";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:19364;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2314;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"woocommerce-placeholder-600x600.png";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:40273;}s:6:"medium";a:5:{s:4:"file";s:35:"woocommerce-placeholder-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:12560;}s:5:"large";a:5:{s:4:"file";s:37:"woocommerce-placeholder-1024x1024.png";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:92182;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"woocommerce-placeholder-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:4228;}s:12:"medium_large";a:5:{s:4:"file";s:35:"woocommerce-placeholder-768x768.png";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:58715;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(5, 2, '_wp_trash_meta_status', 'publish'),
(6, 2, '_wp_trash_meta_time', '1681984293'),
(7, 2, '_wp_desired_post_slug', 'exempelsida'),
(8, 1, '_wp_trash_meta_status', 'publish'),
(9, 1, '_wp_trash_meta_time', '1681984305'),
(10, 1, '_wp_desired_post_slug', 'hej-varlden'),
(11, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(12, 13, '_edit_last', '1'),
(13, 13, '_edit_lock', '1681986079:1'),
(14, 13, 'total_sales', '0'),
(15, 13, '_tax_status', 'taxable'),
(16, 13, '_tax_class', ''),
(17, 13, '_manage_stock', 'yes'),
(18, 13, '_backorders', 'no'),
(19, 13, '_sold_individually', 'no'),
(20, 13, '_virtual', 'no'),
(21, 13, '_downloadable', 'no'),
(22, 13, '_download_limit', '-1'),
(23, 13, '_download_expiry', '-1'),
(24, 13, '_stock', '10'),
(25, 13, '_stock_status', 'instock'),
(26, 13, '_wc_average_rating', '0'),
(27, 13, '_wc_review_count', '0'),
(28, 13, '_product_attributes', 'a:2:{s:4:"farg";a:6:{s:4:"name";s:5:"Färg";s:5:"value";s:22:"Svart | Grafit | Grön";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}s:7:"storlek";a:6:{s:4:"name";s:7:"Storlek";s:5:"value";s:14:"S | M | L | XL";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(29, 13, '_product_version', '7.6.0'),
(30, 13, '_sku', 'MegaShop - 0001'),
(33, 13, '_weight', '0.2'),
(34, 13, '_length', '10'),
(35, 13, '_width', '10'),
(36, 13, '_height', '10'),
(55, 15, '_variation_description', ''),
(56, 15, 'total_sales', '0'),
(57, 15, '_tax_status', 'taxable'),
(58, 15, '_tax_class', 'parent'),
(59, 15, '_manage_stock', 'yes'),
(60, 15, '_backorders', 'no'),
(61, 15, '_sold_individually', 'no'),
(62, 15, '_virtual', 'no'),
(63, 15, '_downloadable', 'no'),
(64, 15, '_download_limit', '-1'),
(65, 15, '_download_expiry', '-1'),
(66, 15, '_stock', '10'),
(67, 15, '_stock_status', 'instock'),
(68, 15, '_wc_average_rating', '0'),
(69, 15, '_wc_review_count', '0'),
(70, 15, 'attribute_storlek', 'S'),
(71, 15, 'attribute_farg', 'Svart'),
(72, 15, '_product_version', '7.6.0'),
(73, 16, '_variation_description', ''),
(74, 16, 'total_sales', '0'),
(75, 16, '_tax_status', 'taxable'),
(76, 16, '_tax_class', 'parent'),
(77, 16, '_manage_stock', 'no'),
(78, 16, '_backorders', 'no'),
(79, 16, '_sold_individually', 'no'),
(80, 16, '_virtual', 'no'),
(81, 16, '_downloadable', 'no'),
(82, 16, '_download_limit', '-1'),
(83, 16, '_download_expiry', '-1'),
(84, 16, '_stock', '0'),
(85, 16, '_stock_status', 'instock'),
(86, 16, '_wc_average_rating', '0'),
(87, 16, '_wc_review_count', '0'),
(88, 16, 'attribute_storlek', 'M'),
(89, 16, 'attribute_farg', 'Svart'),
(90, 16, '_product_version', '7.6.0'),
(91, 17, '_variation_description', ''),
(92, 17, 'total_sales', '0'),
(93, 17, '_tax_status', 'taxable'),
(94, 17, '_tax_class', 'parent'),
(95, 17, '_manage_stock', 'no'),
(96, 17, '_backorders', 'no'),
(97, 17, '_sold_individually', 'no'),
(98, 17, '_virtual', 'no'),
(99, 17, '_downloadable', 'no'),
(100, 17, '_download_limit', '-1'),
(101, 17, '_download_expiry', '-1'),
(102, 17, '_stock', '0'),
(103, 17, '_stock_status', 'instock'),
(104, 17, '_wc_average_rating', '0'),
(105, 17, '_wc_review_count', '0'),
(106, 17, 'attribute_storlek', 'L'),
(107, 17, 'attribute_farg', 'Svart'),
(108, 17, '_product_version', '7.6.0'),
(109, 18, '_variation_description', ''),
(110, 18, 'total_sales', '0'),
(111, 18, '_tax_status', 'taxable'),
(112, 18, '_tax_class', 'parent'),
(113, 18, '_manage_stock', 'no'),
(114, 18, '_backorders', 'no'),
(115, 18, '_sold_individually', 'no'),
(116, 18, '_virtual', 'no'),
(117, 18, '_downloadable', 'no'),
(118, 18, '_download_limit', '-1'),
(119, 18, '_download_expiry', '-1'),
(120, 18, '_stock', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(121, 18, '_stock_status', 'instock'),
(122, 18, '_wc_average_rating', '0'),
(123, 18, '_wc_review_count', '0'),
(124, 18, 'attribute_storlek', 'XL'),
(125, 18, 'attribute_farg', 'Svart'),
(126, 18, '_product_version', '7.6.0'),
(127, 19, '_variation_description', ''),
(128, 19, 'total_sales', '0'),
(129, 19, '_tax_status', 'taxable'),
(130, 19, '_tax_class', 'parent'),
(131, 19, '_manage_stock', 'no'),
(132, 19, '_backorders', 'no'),
(133, 19, '_sold_individually', 'no'),
(134, 19, '_virtual', 'no'),
(135, 19, '_downloadable', 'no'),
(136, 19, '_download_limit', '-1'),
(137, 19, '_download_expiry', '-1'),
(138, 19, '_stock', '0'),
(139, 19, '_stock_status', 'instock'),
(140, 19, '_wc_average_rating', '0'),
(141, 19, '_wc_review_count', '0'),
(142, 19, 'attribute_storlek', 'S'),
(143, 19, 'attribute_farg', 'Grafit'),
(144, 19, '_product_version', '7.6.0'),
(145, 20, '_variation_description', ''),
(146, 20, 'total_sales', '0'),
(147, 20, '_tax_status', 'taxable'),
(148, 20, '_tax_class', 'parent'),
(149, 20, '_manage_stock', 'no'),
(150, 20, '_backorders', 'no'),
(151, 20, '_sold_individually', 'no'),
(152, 20, '_virtual', 'no'),
(153, 20, '_downloadable', 'no'),
(154, 20, '_download_limit', '-1'),
(155, 20, '_download_expiry', '-1'),
(156, 20, '_stock', '0'),
(157, 20, '_stock_status', 'instock'),
(158, 20, '_wc_average_rating', '0'),
(159, 20, '_wc_review_count', '0'),
(160, 20, 'attribute_storlek', 'M'),
(161, 20, 'attribute_farg', 'Grafit'),
(162, 20, '_product_version', '7.6.0'),
(163, 21, '_variation_description', ''),
(164, 21, 'total_sales', '0'),
(165, 21, '_tax_status', 'taxable'),
(166, 21, '_tax_class', 'parent'),
(167, 21, '_manage_stock', 'no'),
(168, 21, '_backorders', 'no'),
(169, 21, '_sold_individually', 'no'),
(170, 21, '_virtual', 'no'),
(171, 21, '_downloadable', 'no'),
(172, 21, '_download_limit', '-1'),
(173, 21, '_download_expiry', '-1'),
(174, 21, '_stock', '0'),
(175, 21, '_stock_status', 'instock'),
(176, 21, '_wc_average_rating', '0'),
(177, 21, '_wc_review_count', '0'),
(178, 21, 'attribute_storlek', 'L'),
(179, 21, 'attribute_farg', 'Grafit'),
(180, 21, '_product_version', '7.6.0'),
(181, 22, '_variation_description', ''),
(182, 22, 'total_sales', '0'),
(183, 22, '_tax_status', 'taxable'),
(184, 22, '_tax_class', 'parent'),
(185, 22, '_manage_stock', 'no'),
(186, 22, '_backorders', 'no'),
(187, 22, '_sold_individually', 'no'),
(188, 22, '_virtual', 'no'),
(189, 22, '_downloadable', 'no'),
(190, 22, '_download_limit', '-1'),
(191, 22, '_download_expiry', '-1'),
(192, 22, '_stock', '0'),
(193, 22, '_stock_status', 'instock'),
(194, 22, '_wc_average_rating', '0'),
(195, 22, '_wc_review_count', '0'),
(196, 22, 'attribute_storlek', 'XL'),
(197, 22, 'attribute_farg', 'Grafit'),
(198, 22, '_product_version', '7.6.0'),
(199, 23, '_variation_description', ''),
(200, 23, 'total_sales', '0'),
(201, 23, '_tax_status', 'taxable'),
(202, 23, '_tax_class', 'parent'),
(203, 23, '_manage_stock', 'no'),
(204, 23, '_backorders', 'no'),
(205, 23, '_sold_individually', 'no'),
(206, 23, '_virtual', 'no'),
(207, 23, '_downloadable', 'no'),
(208, 23, '_download_limit', '-1'),
(209, 23, '_download_expiry', '-1'),
(210, 23, '_stock', '0'),
(211, 23, '_stock_status', 'instock'),
(212, 23, '_wc_average_rating', '0'),
(213, 23, '_wc_review_count', '0'),
(214, 23, 'attribute_storlek', 'S'),
(215, 23, 'attribute_farg', 'Grön'),
(216, 23, '_product_version', '7.6.0'),
(217, 24, '_variation_description', ''),
(218, 24, 'total_sales', '0'),
(219, 24, '_tax_status', 'taxable'),
(220, 24, '_tax_class', 'parent') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(221, 24, '_manage_stock', 'no'),
(222, 24, '_backorders', 'no'),
(223, 24, '_sold_individually', 'no'),
(224, 24, '_virtual', 'no'),
(225, 24, '_downloadable', 'no'),
(226, 24, '_download_limit', '-1'),
(227, 24, '_download_expiry', '-1'),
(228, 24, '_stock', '0'),
(229, 24, '_stock_status', 'instock'),
(230, 24, '_wc_average_rating', '0'),
(231, 24, '_wc_review_count', '0'),
(232, 24, 'attribute_storlek', 'M'),
(233, 24, 'attribute_farg', 'Grön'),
(234, 24, '_product_version', '7.6.0'),
(235, 25, '_variation_description', ''),
(236, 25, 'total_sales', '0'),
(237, 25, '_tax_status', 'taxable'),
(238, 25, '_tax_class', 'parent'),
(239, 25, '_manage_stock', 'no'),
(240, 25, '_backorders', 'no'),
(241, 25, '_sold_individually', 'no'),
(242, 25, '_virtual', 'no'),
(243, 25, '_downloadable', 'no'),
(244, 25, '_download_limit', '-1'),
(245, 25, '_download_expiry', '-1'),
(246, 25, '_stock', '0'),
(247, 25, '_stock_status', 'instock'),
(248, 25, '_wc_average_rating', '0'),
(249, 25, '_wc_review_count', '0'),
(250, 25, 'attribute_storlek', 'L'),
(251, 25, 'attribute_farg', 'Grön'),
(252, 25, '_product_version', '7.6.0'),
(253, 26, '_variation_description', ''),
(254, 26, 'total_sales', '0'),
(255, 26, '_tax_status', 'taxable'),
(256, 26, '_tax_class', 'parent'),
(257, 26, '_manage_stock', 'no'),
(258, 26, '_backorders', 'no'),
(259, 26, '_sold_individually', 'no'),
(260, 26, '_virtual', 'no'),
(261, 26, '_downloadable', 'no'),
(262, 26, '_download_limit', '-1'),
(263, 26, '_download_expiry', '-1'),
(264, 26, '_stock', '0'),
(265, 26, '_stock_status', 'instock'),
(266, 26, '_wc_average_rating', '0'),
(267, 26, '_wc_review_count', '0'),
(268, 26, 'attribute_storlek', 'XL'),
(269, 26, 'attribute_farg', 'Grön'),
(270, 26, '_product_version', '7.6.0'),
(271, 15, '_regular_price', '599'),
(273, 15, '_price', '599'),
(274, 15, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(275, 16, '_regular_price', '599'),
(277, 16, '_price', '599'),
(278, 16, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(279, 17, '_regular_price', '599'),
(281, 17, '_price', '599'),
(282, 17, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(283, 18, '_regular_price', '599'),
(285, 18, '_price', '599'),
(286, 18, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(287, 19, '_regular_price', '599'),
(289, 19, '_price', '599'),
(290, 19, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(291, 20, '_regular_price', '599'),
(293, 20, '_price', '599'),
(294, 20, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(295, 21, '_regular_price', '599'),
(297, 21, '_price', '599'),
(298, 21, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(299, 22, '_regular_price', '599'),
(301, 22, '_price', '599'),
(302, 22, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(303, 23, '_regular_price', '599'),
(305, 23, '_price', '599'),
(306, 23, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(307, 24, '_regular_price', '599'),
(309, 24, '_price', '599'),
(310, 24, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(311, 25, '_regular_price', '599'),
(313, 25, '_price', '599'),
(314, 25, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(315, 26, '_regular_price', '599'),
(317, 26, '_price', '599'),
(318, 26, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(330, 13, '_product_image_gallery', '30,29,28,38,37,36,35,34,33,31,32'),
(347, 13, '_price', '599'),
(348, 39, '_wp_trash_meta_status', 'publish'),
(349, 39, '_wp_trash_meta_time', '1681985868'),
(350, 40, '_wp_trash_meta_status', 'publish'),
(351, 40, '_wp_trash_meta_time', '1681985909'),
(352, 41, '_wp_trash_meta_status', 'publish'),
(353, 41, '_wp_trash_meta_time', '1681985915'),
(354, 42, '_wp_trash_meta_status', 'publish'),
(355, 42, '_wp_trash_meta_time', '1681985925'),
(356, 43, '_wp_trash_meta_status', 'publish'),
(357, 43, '_wp_trash_meta_time', '1681985963'),
(358, 44, '_edit_last', '1'),
(359, 44, '_edit_lock', '1681988138:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(361, 44, '_regular_price', '199'),
(362, 44, 'total_sales', '0'),
(363, 44, '_tax_status', 'taxable'),
(364, 44, '_tax_class', ''),
(365, 44, '_manage_stock', 'no'),
(366, 44, '_backorders', 'no'),
(367, 44, '_sold_individually', 'no'),
(368, 44, '_virtual', 'no'),
(369, 44, '_downloadable', 'no'),
(370, 44, '_download_limit', '-1'),
(371, 44, '_download_expiry', '-1'),
(372, 44, '_stock', NULL),
(373, 44, '_stock_status', 'instock'),
(374, 44, '_wc_average_rating', '0'),
(375, 44, '_wc_review_count', '0'),
(376, 44, '_product_version', '7.6.0'),
(377, 44, '_price', '199'),
(380, 20, '_wp_trash_meta_status', 'publish'),
(381, 20, '_wp_trash_meta_time', '1681986464'),
(382, 20, '_wp_desired_post_slug', 'icaniwill-tights-m-grafit'),
(383, 21, '_wp_trash_meta_status', 'publish'),
(384, 21, '_wp_trash_meta_time', '1681986464'),
(385, 21, '_wp_desired_post_slug', 'icaniwill-tights-l-grafit'),
(386, 22, '_wp_trash_meta_status', 'publish'),
(387, 22, '_wp_trash_meta_time', '1681986464'),
(388, 22, '_wp_desired_post_slug', 'icaniwill-tights-xl-grafit'),
(389, 23, '_wp_trash_meta_status', 'publish'),
(390, 23, '_wp_trash_meta_time', '1681986464'),
(391, 23, '_wp_desired_post_slug', 'icaniwill-tights-s-gron'),
(392, 24, '_wp_trash_meta_status', 'publish'),
(393, 24, '_wp_trash_meta_time', '1681986464'),
(394, 24, '_wp_desired_post_slug', 'icaniwill-tights-m-gron'),
(395, 25, '_wp_trash_meta_status', 'publish'),
(396, 25, '_wp_trash_meta_time', '1681986464'),
(397, 25, '_wp_desired_post_slug', 'icaniwill-tights-l-gron'),
(398, 26, '_wp_trash_meta_status', 'publish'),
(399, 26, '_wp_trash_meta_time', '1681986464'),
(400, 26, '_wp_desired_post_slug', 'icaniwill-tights-xl-gron'),
(401, 15, '_wp_trash_meta_status', 'publish'),
(402, 15, '_wp_trash_meta_time', '1681986464'),
(403, 15, '_wp_desired_post_slug', 'icaniwill-tights-s-svart'),
(404, 16, '_wp_trash_meta_status', 'publish'),
(405, 16, '_wp_trash_meta_time', '1681986464'),
(406, 16, '_wp_desired_post_slug', 'icaniwill-tights-m-svart'),
(407, 17, '_wp_trash_meta_status', 'publish'),
(408, 17, '_wp_trash_meta_time', '1681986464'),
(409, 17, '_wp_desired_post_slug', 'icaniwill-tights-l-svart'),
(410, 18, '_wp_trash_meta_status', 'publish'),
(411, 18, '_wp_trash_meta_time', '1681986464'),
(412, 18, '_wp_desired_post_slug', 'icaniwill-tights-xl-svart'),
(413, 19, '_wp_trash_meta_status', 'publish'),
(414, 19, '_wp_trash_meta_time', '1681986464'),
(415, 19, '_wp_desired_post_slug', 'icaniwill-tights-s-grafit'),
(416, 13, '_wp_trash_meta_status', 'publish'),
(417, 13, '_wp_trash_meta_time', '1681986464'),
(418, 13, '_wp_desired_post_slug', 'icaniwill-tights'),
(419, 46, '_edit_last', '1'),
(420, 46, '_edit_lock', '1681986549:1'),
(421, 47, '_wp_attached_file', 'overall_001.jpg'),
(422, 47, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:15:"overall_001.jpg";s:8:"filesize";i:526666;s:5:"sizes";a:8:{s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:23:"overall_001-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8363;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:23:"overall_001-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1876;}s:18:"woocommerce_single";a:5:{s:4:"file";s:23:"overall_001-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16060;}s:6:"medium";a:5:{s:4:"file";s:23:"overall_001-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6181;}s:5:"large";a:5:{s:4:"file";s:25:"overall_001-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35651;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"overall_001-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2779;}s:12:"medium_large";a:5:{s:4:"file";s:23:"overall_001-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22817;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"overall_001-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67969;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(423, 47, '_wp_attachment_image_alt', 'overall_001'),
(424, 46, 'total_sales', '0'),
(425, 46, '_tax_status', 'taxable'),
(426, 46, '_tax_class', ''),
(427, 46, '_manage_stock', 'yes'),
(428, 46, '_backorders', 'no'),
(429, 46, '_sold_individually', 'no'),
(430, 46, '_virtual', 'no'),
(431, 46, '_downloadable', 'no'),
(432, 46, '_download_limit', '-1'),
(433, 46, '_download_expiry', '-1'),
(434, 46, '_stock', '10'),
(435, 46, '_stock_status', 'instock'),
(436, 46, '_wc_average_rating', '0'),
(437, 46, '_wc_review_count', '0'),
(438, 46, '_product_attributes', 'a:1:{s:7:"storlek";a:6:{s:4:"name";s:7:"Storlek";s:5:"value";s:19:"XS | S | M | L | XL";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(439, 46, '_product_version', '7.6.0'),
(440, 48, '_variation_description', ''),
(441, 48, 'total_sales', '0'),
(442, 48, '_tax_status', 'taxable'),
(443, 48, '_tax_class', 'parent'),
(444, 48, '_manage_stock', 'no'),
(445, 48, '_backorders', 'no'),
(446, 48, '_sold_individually', 'no'),
(447, 48, '_virtual', 'no'),
(448, 48, '_downloadable', 'no'),
(449, 48, '_download_limit', '-1'),
(450, 48, '_download_expiry', '-1'),
(451, 48, '_stock', NULL),
(452, 48, '_stock_status', 'instock'),
(453, 48, '_wc_average_rating', '0'),
(454, 48, '_wc_review_count', '0'),
(455, 48, 'attribute_storlek', 'XS'),
(456, 48, '_product_version', '7.6.0'),
(457, 49, '_variation_description', ''),
(458, 49, 'total_sales', '0'),
(459, 49, '_tax_status', 'taxable'),
(460, 49, '_tax_class', 'parent'),
(461, 49, '_manage_stock', 'no'),
(462, 49, '_backorders', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(463, 49, '_sold_individually', 'no'),
(464, 49, '_virtual', 'no'),
(465, 49, '_downloadable', 'no'),
(466, 49, '_download_limit', '-1'),
(467, 49, '_download_expiry', '-1'),
(468, 49, '_stock', NULL),
(469, 49, '_stock_status', 'instock'),
(470, 49, '_wc_average_rating', '0'),
(471, 49, '_wc_review_count', '0'),
(472, 49, 'attribute_storlek', 'S'),
(473, 49, '_product_version', '7.6.0'),
(474, 50, '_variation_description', ''),
(475, 50, 'total_sales', '0'),
(476, 50, '_tax_status', 'taxable'),
(477, 50, '_tax_class', 'parent'),
(478, 50, '_manage_stock', 'no'),
(479, 50, '_backorders', 'no'),
(480, 50, '_sold_individually', 'no'),
(481, 50, '_virtual', 'no'),
(482, 50, '_downloadable', 'no'),
(483, 50, '_download_limit', '-1'),
(484, 50, '_download_expiry', '-1'),
(485, 50, '_stock', NULL),
(486, 50, '_stock_status', 'instock'),
(487, 50, '_wc_average_rating', '0'),
(488, 50, '_wc_review_count', '0'),
(489, 50, 'attribute_storlek', 'M'),
(490, 50, '_product_version', '7.6.0'),
(491, 51, '_variation_description', ''),
(492, 51, 'total_sales', '0'),
(493, 51, '_tax_status', 'taxable'),
(494, 51, '_tax_class', 'parent'),
(495, 51, '_manage_stock', 'no'),
(496, 51, '_backorders', 'no'),
(497, 51, '_sold_individually', 'no'),
(498, 51, '_virtual', 'no'),
(499, 51, '_downloadable', 'no'),
(500, 51, '_download_limit', '-1'),
(501, 51, '_download_expiry', '-1'),
(502, 51, '_stock', NULL),
(503, 51, '_stock_status', 'instock'),
(504, 51, '_wc_average_rating', '0'),
(505, 51, '_wc_review_count', '0'),
(506, 51, 'attribute_storlek', 'L'),
(507, 51, '_product_version', '7.6.0'),
(508, 52, '_variation_description', ''),
(509, 52, 'total_sales', '0'),
(510, 52, '_tax_status', 'taxable'),
(511, 52, '_tax_class', 'parent'),
(512, 52, '_manage_stock', 'no'),
(513, 52, '_backorders', 'no'),
(514, 52, '_sold_individually', 'no'),
(515, 52, '_virtual', 'no'),
(516, 52, '_downloadable', 'no'),
(517, 52, '_download_limit', '-1'),
(518, 52, '_download_expiry', '-1'),
(519, 52, '_stock', NULL),
(520, 52, '_stock_status', 'instock'),
(521, 52, '_wc_average_rating', '0'),
(522, 52, '_wc_review_count', '0'),
(523, 52, 'attribute_storlek', 'XL'),
(524, 52, '_product_version', '7.6.0'),
(525, 49, '_regular_price', '1099'),
(526, 49, '_thumbnail_id', '47'),
(527, 49, '_price', '699'),
(528, 50, '_regular_price', '1099'),
(529, 50, '_thumbnail_id', '47'),
(530, 50, '_price', '699'),
(531, 51, '_regular_price', '1099'),
(532, 51, '_thumbnail_id', '47'),
(533, 51, '_price', '699'),
(534, 52, '_regular_price', '1099'),
(535, 52, '_thumbnail_id', '47'),
(536, 52, '_price', '699'),
(537, 48, '_regular_price', '1099'),
(538, 48, '_thumbnail_id', '47'),
(539, 48, '_price', '699'),
(542, 49, '_sale_price', '699'),
(543, 50, '_sale_price', '699'),
(544, 51, '_sale_price', '699'),
(545, 52, '_sale_price', '699'),
(546, 48, '_sale_price', '699'),
(549, 46, '_price', '699'),
(550, 46, '_thumbnail_id', '47'),
(551, 46, '_sku', 'MegaShop - 0001'),
(552, 46, '_regular_price', '1099'),
(553, 46, '_sale_price', '699'),
(554, 53, '_sku', 'MegaShop - 0001-1'),
(555, 53, 'total_sales', '0'),
(556, 53, '_tax_status', 'taxable'),
(557, 53, '_tax_class', ''),
(558, 53, '_manage_stock', 'yes'),
(559, 53, '_backorders', 'no'),
(560, 53, '_sold_individually', 'no'),
(561, 53, '_virtual', 'no'),
(562, 53, '_downloadable', 'no'),
(563, 53, '_download_limit', '-1'),
(564, 53, '_download_expiry', '-1'),
(565, 53, '_thumbnail_id', '47'),
(566, 53, '_stock', '10') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(567, 53, '_stock_status', 'instock'),
(568, 53, '_wc_average_rating', '0'),
(569, 53, '_wc_review_count', '0'),
(570, 53, '_product_attributes', 'a:1:{s:7:"storlek";a:6:{s:4:"name";s:7:"Storlek";s:5:"value";s:19:"XS | S | M | L | XL";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(571, 53, '_product_version', '7.6.0'),
(572, 54, '_variation_description', ''),
(573, 54, '_regular_price', '1099'),
(574, 54, '_sale_price', '699'),
(575, 54, 'total_sales', '0'),
(576, 54, '_tax_status', 'taxable'),
(577, 54, '_tax_class', 'parent'),
(578, 54, '_manage_stock', 'no'),
(579, 54, '_backorders', 'no'),
(580, 54, '_sold_individually', 'no'),
(581, 54, '_virtual', 'no'),
(582, 54, '_downloadable', 'no'),
(583, 54, '_download_limit', '-1'),
(584, 54, '_download_expiry', '-1'),
(585, 54, '_thumbnail_id', '47'),
(586, 54, '_stock', NULL),
(587, 54, '_stock_status', 'instock'),
(588, 54, '_wc_average_rating', '0'),
(589, 54, '_wc_review_count', '0'),
(590, 54, 'attribute_storlek', 'XS'),
(591, 54, '_price', '699'),
(592, 54, '_product_version', '7.6.0'),
(593, 55, '_variation_description', ''),
(594, 55, '_regular_price', '1099'),
(595, 55, '_sale_price', '699'),
(596, 55, 'total_sales', '0'),
(597, 55, '_tax_status', 'taxable'),
(598, 55, '_tax_class', 'parent'),
(599, 55, '_manage_stock', 'no'),
(600, 55, '_backorders', 'no'),
(601, 55, '_sold_individually', 'no'),
(602, 55, '_virtual', 'no'),
(603, 55, '_downloadable', 'no'),
(604, 55, '_download_limit', '-1'),
(605, 55, '_download_expiry', '-1'),
(606, 55, '_thumbnail_id', '47'),
(607, 55, '_stock', NULL),
(608, 55, '_stock_status', 'instock'),
(609, 55, '_wc_average_rating', '0'),
(610, 55, '_wc_review_count', '0'),
(611, 55, 'attribute_storlek', 'S'),
(612, 55, '_price', '699'),
(613, 55, '_product_version', '7.6.0'),
(614, 56, '_variation_description', ''),
(615, 56, '_regular_price', '1099'),
(616, 56, '_sale_price', '699'),
(617, 56, 'total_sales', '0'),
(618, 56, '_tax_status', 'taxable'),
(619, 56, '_tax_class', 'parent'),
(620, 56, '_manage_stock', 'no'),
(621, 56, '_backorders', 'no'),
(622, 56, '_sold_individually', 'no'),
(623, 56, '_virtual', 'no'),
(624, 56, '_downloadable', 'no'),
(625, 56, '_download_limit', '-1'),
(626, 56, '_download_expiry', '-1'),
(627, 56, '_thumbnail_id', '47'),
(628, 56, '_stock', NULL),
(629, 56, '_stock_status', 'instock'),
(630, 56, '_wc_average_rating', '0'),
(631, 56, '_wc_review_count', '0'),
(632, 56, 'attribute_storlek', 'M'),
(633, 56, '_price', '699'),
(634, 56, '_product_version', '7.6.0'),
(635, 57, '_variation_description', ''),
(636, 57, '_regular_price', '1099'),
(637, 57, '_sale_price', '699'),
(638, 57, 'total_sales', '0'),
(639, 57, '_tax_status', 'taxable'),
(640, 57, '_tax_class', 'parent'),
(641, 57, '_manage_stock', 'no'),
(642, 57, '_backorders', 'no'),
(643, 57, '_sold_individually', 'no'),
(644, 57, '_virtual', 'no'),
(645, 57, '_downloadable', 'no'),
(646, 57, '_download_limit', '-1'),
(647, 57, '_download_expiry', '-1'),
(648, 57, '_thumbnail_id', '47'),
(649, 57, '_stock', NULL),
(650, 57, '_stock_status', 'instock'),
(651, 57, '_wc_average_rating', '0'),
(652, 57, '_wc_review_count', '0'),
(653, 57, 'attribute_storlek', 'L'),
(654, 57, '_price', '699'),
(655, 57, '_product_version', '7.6.0'),
(656, 58, '_variation_description', ''),
(657, 58, '_regular_price', '1099'),
(658, 58, '_sale_price', '699'),
(659, 58, 'total_sales', '0'),
(660, 58, '_tax_status', 'taxable'),
(661, 58, '_tax_class', 'parent'),
(662, 58, '_manage_stock', 'no'),
(663, 58, '_backorders', 'no'),
(664, 58, '_sold_individually', 'no'),
(665, 58, '_virtual', 'no'),
(666, 58, '_downloadable', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(667, 58, '_download_limit', '-1'),
(668, 58, '_download_expiry', '-1'),
(669, 58, '_thumbnail_id', '47'),
(670, 58, '_stock', NULL),
(671, 58, '_stock_status', 'instock'),
(672, 58, '_wc_average_rating', '0'),
(673, 58, '_wc_review_count', '0'),
(674, 58, 'attribute_storlek', 'XL'),
(675, 58, '_price', '699'),
(676, 58, '_product_version', '7.6.0'),
(677, 53, '_price', '699'),
(678, 53, '_edit_lock', '1681986691:1'),
(679, 55, '_wp_trash_meta_status', 'publish'),
(680, 55, '_wp_trash_meta_time', '1681986832'),
(681, 55, '_wp_desired_post_slug', 'laila-w-tracksuit-set-s-2'),
(682, 56, '_wp_trash_meta_status', 'publish'),
(683, 56, '_wp_trash_meta_time', '1681986832'),
(684, 56, '_wp_desired_post_slug', 'laila-w-tracksuit-set-m-2'),
(685, 57, '_wp_trash_meta_status', 'publish'),
(686, 57, '_wp_trash_meta_time', '1681986832'),
(687, 57, '_wp_desired_post_slug', 'laila-w-tracksuit-set-l-2'),
(688, 58, '_wp_trash_meta_status', 'publish'),
(689, 58, '_wp_trash_meta_time', '1681986832'),
(690, 58, '_wp_desired_post_slug', 'laila-w-tracksuit-set-xl-2'),
(691, 54, '_wp_trash_meta_status', 'publish'),
(692, 54, '_wp_trash_meta_time', '1681986832'),
(693, 54, '_wp_desired_post_slug', 'laila-w-tracksuit-set-xs-2'),
(694, 53, '_wp_trash_meta_status', 'draft'),
(695, 53, '_wp_trash_meta_time', '1681986833'),
(696, 53, '_wp_desired_post_slug', ''),
(697, 59, '_edit_last', '1'),
(698, 59, '_edit_lock', '1681987391:1'),
(699, 60, '_wp_attached_file', 'MegaShop_0002-tights_01.jpg'),
(700, 60, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:27:"MegaShop_0002-tights_01.jpg";s:8:"filesize";i:661811;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_01-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8135;}s:5:"large";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_01-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:44297;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_01-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3645;}s:12:"medium_large";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_01-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28523;}s:9:"1536x1536";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_01-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:86140;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"MegaShop_0002-tights_01-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10896;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_01-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20216;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_01-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2339;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1596018576";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(701, 61, '_wp_attached_file', 'MegaShop_0002-tights_02.jpg'),
(702, 61, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:27:"MegaShop_0002-tights_02.jpg";s:8:"filesize";i:644619;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_02-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7922;}s:5:"large";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_02-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:43168;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_02-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3582;}s:12:"medium_large";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_02-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:28170;}s:9:"1536x1536";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_02-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:83900;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"MegaShop_0002-tights_02-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10876;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_02-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19858;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_02-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2450;}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"11";s:6:"credit";s:0:"";s:6:"camera";s:20:"Canon EOS 5D Mark IV";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1596018832";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"42";s:3:"iso";s:3:"320";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(703, 62, '_wp_attached_file', 'MegaShop_0002-tights_03.jpg'),
(704, 62, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:27:"MegaShop_0002-tights_03.jpg";s:8:"filesize";i:1447182;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_03-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6685;}s:5:"large";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_03-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70156;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_03-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2994;}s:12:"medium_large";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_03-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:36277;}s:9:"1536x1536";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_03-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:169428;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"MegaShop_0002-tights_03-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9120;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_03-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21559;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_03-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2146;}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"11";s:6:"credit";s:0:"";s:6:"camera";s:20:"Canon EOS 5D Mark IV";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1596018889";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"57";s:3:"iso";s:3:"320";s:13:"shutter_speed";s:7:"0.00625";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(705, 63, '_wp_attached_file', 'MegaShop_0002-tights_04.jpg'),
(706, 63, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:27:"MegaShop_0002-tights_04.jpg";s:8:"filesize";i:597795;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_04-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7110;}s:5:"large";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_04-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:40352;}s:9:"thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_04-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3245;}s:12:"medium_large";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_04-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:25814;}s:9:"1536x1536";a:5:{s:4:"file";s:37:"MegaShop_0002-tights_04-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:79098;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:35:"MegaShop_0002-tights_04-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9594;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_04-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18072;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:35:"MegaShop_0002-tights_04-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2130;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1596018583";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(707, 63, '_wp_attachment_image_alt', 'tights'),
(708, 59, 'total_sales', '0'),
(709, 59, '_tax_status', 'taxable'),
(710, 59, '_tax_class', ''),
(711, 59, '_manage_stock', 'yes'),
(712, 59, '_backorders', 'no'),
(713, 59, '_sold_individually', 'no'),
(714, 59, '_virtual', 'no'),
(715, 59, '_downloadable', 'no'),
(716, 59, '_download_limit', '-1'),
(717, 59, '_download_expiry', '-1'),
(718, 59, '_stock', '10'),
(719, 59, '_stock_status', 'instock'),
(720, 59, '_wc_average_rating', '0'),
(721, 59, '_wc_review_count', '0'),
(722, 59, '_product_attributes', 'a:1:{s:7:"storlek";a:6:{s:4:"name";s:7:"Storlek";s:5:"value";s:19:"XS | S | M | L | XL";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(723, 59, '_product_version', '7.6.0'),
(724, 59, '_thumbnail_id', '63'),
(725, 59, '_sku', 'MegaShop - 0002'),
(727, 59, '_weight', '0.1'),
(728, 59, '_length', '5'),
(729, 59, '_width', '5'),
(730, 59, '_height', '10'),
(732, 59, '_product_image_gallery', '62,61,60'),
(733, 64, '_variation_description', ''),
(734, 64, 'total_sales', '0'),
(735, 64, '_tax_status', 'taxable'),
(736, 64, '_tax_class', 'parent'),
(737, 64, '_manage_stock', 'yes'),
(738, 64, '_backorders', 'no'),
(739, 64, '_sold_individually', 'no'),
(740, 64, '_virtual', 'no'),
(741, 64, '_downloadable', 'no'),
(742, 64, '_download_limit', '-1'),
(743, 64, '_download_expiry', '-1'),
(744, 64, '_stock', '10'),
(745, 64, '_stock_status', 'instock'),
(746, 64, '_wc_average_rating', '0'),
(747, 64, '_wc_review_count', '0'),
(748, 64, 'attribute_storlek', 'XS'),
(749, 64, '_product_version', '7.6.0'),
(750, 65, '_variation_description', ''),
(751, 65, 'total_sales', '0'),
(752, 65, '_tax_status', 'taxable'),
(753, 65, '_tax_class', 'parent'),
(754, 65, '_manage_stock', 'yes'),
(755, 65, '_backorders', 'no'),
(756, 65, '_sold_individually', 'no'),
(757, 65, '_virtual', 'no'),
(758, 65, '_downloadable', 'no'),
(759, 65, '_download_limit', '-1'),
(760, 65, '_download_expiry', '-1'),
(761, 65, '_stock', '10'),
(762, 65, '_stock_status', 'instock'),
(763, 65, '_wc_average_rating', '0'),
(764, 65, '_wc_review_count', '0'),
(765, 65, 'attribute_storlek', 'S'),
(766, 65, '_product_version', '7.6.0'),
(767, 66, '_variation_description', ''),
(768, 66, 'total_sales', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(769, 66, '_tax_status', 'taxable'),
(770, 66, '_tax_class', 'parent'),
(771, 66, '_manage_stock', 'yes'),
(772, 66, '_backorders', 'no'),
(773, 66, '_sold_individually', 'no'),
(774, 66, '_virtual', 'no'),
(775, 66, '_downloadable', 'no'),
(776, 66, '_download_limit', '-1'),
(777, 66, '_download_expiry', '-1'),
(778, 66, '_stock', '10'),
(779, 66, '_stock_status', 'instock'),
(780, 66, '_wc_average_rating', '0'),
(781, 66, '_wc_review_count', '0'),
(782, 66, 'attribute_storlek', 'M'),
(783, 66, '_product_version', '7.6.0'),
(784, 67, '_variation_description', ''),
(785, 67, 'total_sales', '0'),
(786, 67, '_tax_status', 'taxable'),
(787, 67, '_tax_class', 'parent'),
(788, 67, '_manage_stock', 'yes'),
(789, 67, '_backorders', 'no'),
(790, 67, '_sold_individually', 'no'),
(791, 67, '_virtual', 'no'),
(792, 67, '_downloadable', 'no'),
(793, 67, '_download_limit', '-1'),
(794, 67, '_download_expiry', '-1'),
(795, 67, '_stock', '10'),
(796, 67, '_stock_status', 'instock'),
(797, 67, '_wc_average_rating', '0'),
(798, 67, '_wc_review_count', '0'),
(799, 67, 'attribute_storlek', 'L'),
(800, 67, '_product_version', '7.6.0'),
(801, 68, '_variation_description', ''),
(802, 68, 'total_sales', '0'),
(803, 68, '_tax_status', 'taxable'),
(804, 68, '_tax_class', 'parent'),
(805, 68, '_manage_stock', 'yes'),
(806, 68, '_backorders', 'no'),
(807, 68, '_sold_individually', 'no'),
(808, 68, '_virtual', 'no'),
(809, 68, '_downloadable', 'no'),
(810, 68, '_download_limit', '-1'),
(811, 68, '_download_expiry', '-1'),
(812, 68, '_stock', '10'),
(813, 68, '_stock_status', 'instock'),
(814, 68, '_wc_average_rating', '0'),
(815, 68, '_wc_review_count', '0'),
(816, 68, 'attribute_storlek', 'XL'),
(817, 68, '_product_version', '7.6.0'),
(818, 64, '_thumbnail_id', '0'),
(819, 65, '_thumbnail_id', '0'),
(820, 66, '_thumbnail_id', '0'),
(821, 67, '_thumbnail_id', '0'),
(822, 68, '_thumbnail_id', '0'),
(823, 64, '_regular_price', '449'),
(824, 64, '_price', '449'),
(825, 65, '_regular_price', '449'),
(826, 65, '_price', '449'),
(827, 66, '_regular_price', '449'),
(828, 66, '_price', '449'),
(829, 67, '_regular_price', '449'),
(830, 67, '_price', '449'),
(831, 68, '_regular_price', '449'),
(832, 68, '_price', '449'),
(834, 59, '_price', '449'),
(835, 6, '_edit_lock', '1682074451:1'),
(836, 70, '_edit_last', '1'),
(837, 70, '_edit_lock', '1681991482:1'),
(838, 71, '_wp_attached_file', 'MegaShop_0003-tshirt_01_dawn.jpg'),
(839, 71, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:32:"MegaShop_0003-tshirt_01_dawn.jpg";s:8:"filesize";i:1166208;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8318;}s:5:"large";a:5:{s:4:"file";s:42:"MegaShop_0003-tshirt_01_dawn-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59526;}s:9:"thumbnail";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3609;}s:12:"medium_large";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34808;}s:9:"1536x1536";a:5:{s:4:"file";s:42:"MegaShop_0003-tshirt_01_dawn-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:136987;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11785;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23050;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_dawn-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2331;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1648739152";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(840, 72, '_wp_attached_file', 'MegaShop_0003-tshirt_01_dawn_model_01.jpg'),
(841, 72, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:41:"MegaShop_0003-tshirt_01_dawn_model_01.jpg";s:8:"filesize";i:1151503;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8031;}s:5:"large";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_dawn_model_01-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:49625;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3446;}s:12:"medium_large";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30842;}s:9:"1536x1536";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_dawn_model_01-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:102137;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11200;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21345;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_01-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2219;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(842, 73, '_wp_attached_file', 'MegaShop_0003-tshirt_01_dawn_model_02.jpg'),
(843, 73, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:41:"MegaShop_0003-tshirt_01_dawn_model_02.jpg";s:8:"filesize";i:1569094;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10758;}s:5:"large";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_dawn_model_02-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:79087;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4329;}s:12:"medium_large";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:46429;}s:9:"1536x1536";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_dawn_model_02-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:174903;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15686;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:30641;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_dawn_model_02-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2690;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(844, 74, '_wp_attached_file', 'MegaShop_0003-tshirt_01_pink.jpg'),
(845, 74, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:32:"MegaShop_0003-tshirt_01_pink.jpg";s:8:"filesize";i:1434795;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7772;}s:5:"large";a:5:{s:4:"file";s:42:"MegaShop_0003-tshirt_01_pink-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:65823;}s:9:"thumbnail";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3260;}s:12:"medium_large";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35372;}s:9:"1536x1536";a:5:{s:4:"file";s:42:"MegaShop_0003-tshirt_01_pink-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:165627;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11040;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22425;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:40:"MegaShop_0003-tshirt_01_pink-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2173;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1648738699";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(846, 75, '_wp_attached_file', 'MegaShop_0003-tshirt_01_pink_back.jpg'),
(847, 75, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:37:"MegaShop_0003-tshirt_01_pink_back.jpg";s:8:"filesize";i:1516071;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11018;}s:5:"large";a:5:{s:4:"file";s:47:"MegaShop_0003-tshirt_01_pink_back-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:80704;}s:9:"thumbnail";a:5:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4028;}s:12:"medium_large";a:5:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:49084;}s:9:"1536x1536";a:5:{s:4:"file";s:47:"MegaShop_0003-tshirt_01_pink_back-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:166542;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16673;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:32591;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:45:"MegaShop_0003-tshirt_01_pink_back-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2486;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(848, 76, '_wp_attached_file', 'MegaShop_0003-tshirt_01_pink_model_01.jpg'),
(849, 76, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:41:"MegaShop_0003-tshirt_01_pink_model_01.jpg";s:8:"filesize";i:2251471;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14435;}s:5:"large";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_pink_model_01-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:122146;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5087;}s:12:"medium_large";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70934;}s:9:"1536x1536";a:5:{s:4:"file";s:51:"MegaShop_0003-tshirt_01_pink_model_01-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:266047;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:22267;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:45633;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"MegaShop_0003-tshirt_01_pink_model_01-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3053;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"SS23 Trainingwear Women";}}}'),
(850, 77, '_wp_attached_file', 'MegaShop_0003-tshirt_01_svart.jpg'),
(851, 77, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:33:"MegaShop_0003-tshirt_01_svart.jpg";s:8:"filesize";i:1231770;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8549;}s:5:"large";a:5:{s:4:"file";s:43:"MegaShop_0003-tshirt_01_svart-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:60118;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3609;}s:12:"medium_large";a:5:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:35079;}s:9:"1536x1536";a:5:{s:4:"file";s:43:"MegaShop_0003-tshirt_01_svart-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:139108;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12145;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23116;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:41:"MegaShop_0003-tshirt_01_svart-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2449;}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"10";s:6:"credit";s:0:"";s:6:"camera";s:20:"Canon EOS 5D Mark IV";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1601290977";s:9:"copyright";s:0:"";s:12:"focal_length";s:2:"50";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:1:{i:0;s:23:"AW21 Trainingwear Women";}}}'),
(852, 77, '_wp_attachment_image_alt', 'tshirt'),
(853, 70, 'total_sales', '0'),
(854, 70, '_tax_status', 'taxable'),
(855, 70, '_tax_class', ''),
(856, 70, '_manage_stock', 'no'),
(857, 70, '_backorders', 'no'),
(858, 70, '_sold_individually', 'no'),
(859, 70, '_virtual', 'no'),
(860, 70, '_downloadable', 'no'),
(861, 70, '_download_limit', '-1'),
(862, 70, '_download_expiry', '-1'),
(863, 70, '_stock', NULL),
(864, 70, '_stock_status', 'instock'),
(865, 70, '_wc_average_rating', '0'),
(866, 70, '_wc_review_count', '0'),
(867, 70, '_product_attributes', 'a:2:{s:7:"storlek";a:6:{s:4:"name";s:7:"Storlek";s:5:"value";s:19:"XS | S | M | L | XL";s:8:"position";i:0;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}s:4:"farg";a:6:{s:4:"name";s:5:"Färg";s:5:"value";s:31:"Svart | Rosa | Dawn (Mörkblå)";s:8:"position";i:1;s:10:"is_visible";i:1;s:12:"is_variation";i:1;s:11:"is_taxonomy";i:0;}}'),
(868, 70, '_product_version', '7.6.0'),
(869, 78, '_variation_description', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(870, 78, 'total_sales', '0'),
(871, 78, '_tax_status', 'taxable'),
(872, 78, '_tax_class', 'parent'),
(873, 78, '_manage_stock', 'yes'),
(874, 78, '_backorders', 'no'),
(875, 78, '_sold_individually', 'no'),
(876, 78, '_virtual', 'no'),
(877, 78, '_downloadable', 'no'),
(878, 78, '_download_limit', '-1'),
(879, 78, '_download_expiry', '-1'),
(880, 78, '_stock', '10'),
(881, 78, '_stock_status', 'instock'),
(882, 78, '_wc_average_rating', '0'),
(883, 78, '_wc_review_count', '0'),
(884, 78, 'attribute_farg', 'Svart'),
(885, 78, 'attribute_storlek', 'XS'),
(886, 78, '_product_version', '7.6.0'),
(887, 79, '_variation_description', ''),
(888, 79, 'total_sales', '0'),
(889, 79, '_tax_status', 'taxable'),
(890, 79, '_tax_class', 'parent'),
(891, 79, '_manage_stock', 'yes'),
(892, 79, '_backorders', 'no'),
(893, 79, '_sold_individually', 'no'),
(894, 79, '_virtual', 'no'),
(895, 79, '_downloadable', 'no'),
(896, 79, '_download_limit', '-1'),
(897, 79, '_download_expiry', '-1'),
(898, 79, '_stock', '10'),
(899, 79, '_stock_status', 'instock'),
(900, 79, '_wc_average_rating', '0'),
(901, 79, '_wc_review_count', '0'),
(902, 79, 'attribute_farg', 'Rosa'),
(903, 79, 'attribute_storlek', 'XS'),
(904, 79, '_product_version', '7.6.0'),
(905, 80, '_variation_description', ''),
(906, 80, 'total_sales', '0'),
(907, 80, '_tax_status', 'taxable'),
(908, 80, '_tax_class', 'parent'),
(909, 80, '_manage_stock', 'yes'),
(910, 80, '_backorders', 'no'),
(911, 80, '_sold_individually', 'no'),
(912, 80, '_virtual', 'no'),
(913, 80, '_downloadable', 'no'),
(914, 80, '_download_limit', '-1'),
(915, 80, '_download_expiry', '-1'),
(916, 80, '_stock', '10'),
(917, 80, '_stock_status', 'instock'),
(918, 80, '_wc_average_rating', '0'),
(919, 80, '_wc_review_count', '0'),
(920, 80, 'attribute_farg', 'Dawn (Mörkblå)'),
(921, 80, 'attribute_storlek', 'XS'),
(922, 80, '_product_version', '7.6.0'),
(923, 81, '_variation_description', ''),
(924, 81, 'total_sales', '0'),
(925, 81, '_tax_status', 'taxable'),
(926, 81, '_tax_class', 'parent'),
(927, 81, '_manage_stock', 'yes'),
(928, 81, '_backorders', 'no'),
(929, 81, '_sold_individually', 'no'),
(930, 81, '_virtual', 'no'),
(931, 81, '_downloadable', 'no'),
(932, 81, '_download_limit', '-1'),
(933, 81, '_download_expiry', '-1'),
(934, 81, '_stock', '10'),
(935, 81, '_stock_status', 'instock'),
(936, 81, '_wc_average_rating', '0'),
(937, 81, '_wc_review_count', '0'),
(938, 81, 'attribute_farg', 'Svart'),
(939, 81, 'attribute_storlek', 'S'),
(940, 81, '_product_version', '7.6.0'),
(941, 82, '_variation_description', ''),
(942, 82, 'total_sales', '0'),
(943, 82, '_tax_status', 'taxable'),
(944, 82, '_tax_class', 'parent'),
(945, 82, '_manage_stock', 'yes'),
(946, 82, '_backorders', 'no'),
(947, 82, '_sold_individually', 'no'),
(948, 82, '_virtual', 'no'),
(949, 82, '_downloadable', 'no'),
(950, 82, '_download_limit', '-1'),
(951, 82, '_download_expiry', '-1'),
(952, 82, '_stock', '10'),
(953, 82, '_stock_status', 'instock'),
(954, 82, '_wc_average_rating', '0'),
(955, 82, '_wc_review_count', '0'),
(956, 82, 'attribute_farg', 'Rosa'),
(957, 82, 'attribute_storlek', 'S'),
(958, 82, '_product_version', '7.6.0'),
(959, 83, '_variation_description', ''),
(960, 83, 'total_sales', '0'),
(961, 83, '_tax_status', 'taxable'),
(962, 83, '_tax_class', 'parent'),
(963, 83, '_manage_stock', 'yes'),
(964, 83, '_backorders', 'no'),
(965, 83, '_sold_individually', 'no'),
(966, 83, '_virtual', 'no'),
(967, 83, '_downloadable', 'no'),
(968, 83, '_download_limit', '-1'),
(969, 83, '_download_expiry', '-1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(970, 83, '_stock', '10'),
(971, 83, '_stock_status', 'instock'),
(972, 83, '_wc_average_rating', '0'),
(973, 83, '_wc_review_count', '0'),
(974, 83, 'attribute_farg', 'Dawn (Mörkblå)'),
(975, 83, 'attribute_storlek', 'S'),
(976, 83, '_product_version', '7.6.0'),
(977, 84, '_variation_description', ''),
(978, 84, 'total_sales', '0'),
(979, 84, '_tax_status', 'taxable'),
(980, 84, '_tax_class', 'parent'),
(981, 84, '_manage_stock', 'yes'),
(982, 84, '_backorders', 'no'),
(983, 84, '_sold_individually', 'no'),
(984, 84, '_virtual', 'no'),
(985, 84, '_downloadable', 'no'),
(986, 84, '_download_limit', '-1'),
(987, 84, '_download_expiry', '-1'),
(988, 84, '_stock', '10'),
(989, 84, '_stock_status', 'instock'),
(990, 84, '_wc_average_rating', '0'),
(991, 84, '_wc_review_count', '0'),
(992, 84, 'attribute_farg', 'Svart'),
(993, 84, 'attribute_storlek', 'M'),
(994, 84, '_product_version', '7.6.0'),
(995, 85, '_variation_description', ''),
(996, 85, 'total_sales', '0'),
(997, 85, '_tax_status', 'taxable'),
(998, 85, '_tax_class', 'parent'),
(999, 85, '_manage_stock', 'yes'),
(1000, 85, '_backorders', 'no'),
(1001, 85, '_sold_individually', 'no'),
(1002, 85, '_virtual', 'no'),
(1003, 85, '_downloadable', 'no'),
(1004, 85, '_download_limit', '-1'),
(1005, 85, '_download_expiry', '-1'),
(1006, 85, '_stock', '10'),
(1007, 85, '_stock_status', 'instock'),
(1008, 85, '_wc_average_rating', '0'),
(1009, 85, '_wc_review_count', '0'),
(1010, 85, 'attribute_farg', 'Rosa'),
(1011, 85, 'attribute_storlek', 'M'),
(1012, 85, '_product_version', '7.6.0'),
(1013, 86, '_variation_description', ''),
(1014, 86, 'total_sales', '0'),
(1015, 86, '_tax_status', 'taxable'),
(1016, 86, '_tax_class', 'parent'),
(1017, 86, '_manage_stock', 'yes'),
(1018, 86, '_backorders', 'no'),
(1019, 86, '_sold_individually', 'no'),
(1020, 86, '_virtual', 'no'),
(1021, 86, '_downloadable', 'no'),
(1022, 86, '_download_limit', '-1'),
(1023, 86, '_download_expiry', '-1'),
(1024, 86, '_stock', '10'),
(1025, 86, '_stock_status', 'instock'),
(1026, 86, '_wc_average_rating', '0'),
(1027, 86, '_wc_review_count', '0'),
(1028, 86, 'attribute_farg', 'Dawn (Mörkblå)'),
(1029, 86, 'attribute_storlek', 'M'),
(1030, 86, '_product_version', '7.6.0'),
(1031, 87, '_variation_description', ''),
(1032, 87, 'total_sales', '0'),
(1033, 87, '_tax_status', 'taxable'),
(1034, 87, '_tax_class', 'parent'),
(1035, 87, '_manage_stock', 'yes'),
(1036, 87, '_backorders', 'no'),
(1037, 87, '_sold_individually', 'no'),
(1038, 87, '_virtual', 'no'),
(1039, 87, '_downloadable', 'no'),
(1040, 87, '_download_limit', '-1'),
(1041, 87, '_download_expiry', '-1'),
(1042, 87, '_stock', '10'),
(1043, 87, '_stock_status', 'instock'),
(1044, 87, '_wc_average_rating', '0'),
(1045, 87, '_wc_review_count', '0'),
(1046, 87, 'attribute_farg', 'Svart'),
(1047, 87, 'attribute_storlek', 'L'),
(1048, 87, '_product_version', '7.6.0'),
(1049, 88, '_variation_description', ''),
(1050, 88, 'total_sales', '0'),
(1051, 88, '_tax_status', 'taxable'),
(1052, 88, '_tax_class', 'parent'),
(1053, 88, '_manage_stock', 'yes'),
(1054, 88, '_backorders', 'no'),
(1055, 88, '_sold_individually', 'no'),
(1056, 88, '_virtual', 'no'),
(1057, 88, '_downloadable', 'no'),
(1058, 88, '_download_limit', '-1'),
(1059, 88, '_download_expiry', '-1'),
(1060, 88, '_stock', '10'),
(1061, 88, '_stock_status', 'instock'),
(1062, 88, '_wc_average_rating', '0'),
(1063, 88, '_wc_review_count', '0'),
(1064, 88, 'attribute_farg', 'Rosa'),
(1065, 88, 'attribute_storlek', 'L'),
(1066, 88, '_product_version', '7.6.0'),
(1067, 89, '_variation_description', ''),
(1068, 89, 'total_sales', '0'),
(1069, 89, '_tax_status', 'taxable') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1070, 89, '_tax_class', 'parent'),
(1071, 89, '_manage_stock', 'yes'),
(1072, 89, '_backorders', 'no'),
(1073, 89, '_sold_individually', 'no'),
(1074, 89, '_virtual', 'no'),
(1075, 89, '_downloadable', 'no'),
(1076, 89, '_download_limit', '-1'),
(1077, 89, '_download_expiry', '-1'),
(1078, 89, '_stock', '10'),
(1079, 89, '_stock_status', 'instock'),
(1080, 89, '_wc_average_rating', '0'),
(1081, 89, '_wc_review_count', '0'),
(1082, 89, 'attribute_farg', 'Dawn (Mörkblå)'),
(1083, 89, 'attribute_storlek', 'L'),
(1084, 89, '_product_version', '7.6.0'),
(1085, 90, '_variation_description', ''),
(1086, 90, 'total_sales', '0'),
(1087, 90, '_tax_status', 'taxable'),
(1088, 90, '_tax_class', 'parent'),
(1089, 90, '_manage_stock', 'yes'),
(1090, 90, '_backorders', 'no'),
(1091, 90, '_sold_individually', 'no'),
(1092, 90, '_virtual', 'no'),
(1093, 90, '_downloadable', 'no'),
(1094, 90, '_download_limit', '-1'),
(1095, 90, '_download_expiry', '-1'),
(1096, 90, '_stock', '10'),
(1097, 90, '_stock_status', 'instock'),
(1098, 90, '_wc_average_rating', '0'),
(1099, 90, '_wc_review_count', '0'),
(1100, 90, 'attribute_farg', 'Svart'),
(1101, 90, 'attribute_storlek', 'XL'),
(1102, 90, '_product_version', '7.6.0'),
(1103, 91, '_variation_description', ''),
(1104, 91, 'total_sales', '0'),
(1105, 91, '_tax_status', 'taxable'),
(1106, 91, '_tax_class', 'parent'),
(1107, 91, '_manage_stock', 'yes'),
(1108, 91, '_backorders', 'no'),
(1109, 91, '_sold_individually', 'no'),
(1110, 91, '_virtual', 'no'),
(1111, 91, '_downloadable', 'no'),
(1112, 91, '_download_limit', '-1'),
(1113, 91, '_download_expiry', '-1'),
(1114, 91, '_stock', '10'),
(1115, 91, '_stock_status', 'instock'),
(1116, 91, '_wc_average_rating', '0'),
(1117, 91, '_wc_review_count', '0'),
(1118, 91, 'attribute_farg', 'Rosa'),
(1119, 91, 'attribute_storlek', 'XL'),
(1120, 91, '_product_version', '7.6.0'),
(1121, 92, '_variation_description', ''),
(1122, 92, 'total_sales', '0'),
(1123, 92, '_tax_status', 'taxable'),
(1124, 92, '_tax_class', 'parent'),
(1125, 92, '_manage_stock', 'yes'),
(1126, 92, '_backorders', 'no'),
(1127, 92, '_sold_individually', 'no'),
(1128, 92, '_virtual', 'no'),
(1129, 92, '_downloadable', 'no'),
(1130, 92, '_download_limit', '-1'),
(1131, 92, '_download_expiry', '-1'),
(1132, 92, '_stock', '10'),
(1133, 92, '_stock_status', 'instock'),
(1134, 92, '_wc_average_rating', '0'),
(1135, 92, '_wc_review_count', '0'),
(1136, 92, 'attribute_farg', 'Dawn (Mörkblå)'),
(1137, 92, 'attribute_storlek', 'XL'),
(1138, 92, '_product_version', '7.6.0'),
(1139, 89, '_thumbnail_id', '71'),
(1140, 90, '_thumbnail_id', '77'),
(1141, 91, '_thumbnail_id', '74'),
(1142, 92, '_thumbnail_id', '71'),
(1143, 79, '_thumbnail_id', '74'),
(1144, 80, '_thumbnail_id', '71'),
(1145, 81, '_thumbnail_id', '77'),
(1146, 82, '_thumbnail_id', '74'),
(1147, 83, '_thumbnail_id', '71'),
(1148, 84, '_thumbnail_id', '77'),
(1149, 85, '_thumbnail_id', '74'),
(1150, 86, '_thumbnail_id', '71'),
(1151, 87, '_thumbnail_id', '77'),
(1152, 88, '_thumbnail_id', '74'),
(1153, 78, '_thumbnail_id', '77'),
(1154, 89, '_regular_price', '199'),
(1155, 89, '_price', '199'),
(1156, 90, '_regular_price', '199'),
(1157, 90, '_price', '199'),
(1158, 91, '_regular_price', '199'),
(1159, 91, '_price', '199'),
(1160, 92, '_regular_price', '199'),
(1161, 92, '_price', '199'),
(1162, 79, '_regular_price', '199'),
(1163, 79, '_price', '199'),
(1164, 80, '_regular_price', '199'),
(1165, 80, '_price', '199'),
(1166, 81, '_regular_price', '199'),
(1167, 81, '_price', '199'),
(1168, 82, '_regular_price', '199'),
(1169, 82, '_price', '199') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1170, 83, '_regular_price', '199'),
(1171, 83, '_price', '199'),
(1172, 84, '_regular_price', '199'),
(1173, 84, '_price', '199'),
(1174, 85, '_regular_price', '199'),
(1175, 85, '_price', '199'),
(1176, 86, '_regular_price', '199'),
(1177, 86, '_price', '199'),
(1178, 87, '_regular_price', '199'),
(1179, 87, '_price', '199'),
(1180, 88, '_regular_price', '199'),
(1181, 88, '_price', '199'),
(1182, 78, '_regular_price', '199'),
(1183, 78, '_price', '199'),
(1186, 78, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1187, 79, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1188, 80, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1189, 81, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1190, 82, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1191, 83, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1192, 84, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1193, 85, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1194, 86, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1195, 87, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1196, 88, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1197, 89, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1198, 90, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1199, 91, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1200, 92, 'blocksy_post_meta_options', 'a:2:{s:14:"gallery_source";s:7:"default";s:6:"images";a:0:{}}'),
(1201, 70, '_price', '199'),
(1202, 70, '_thumbnail_id', '77'),
(1203, 70, '_sku', 'MegaShop - 0003'),
(1204, 70, '_regular_price', '199'),
(1205, 70, '_product_image_gallery', '77,76,75,74,73,72,71'),
(1206, 93, '_edit_last', '1'),
(1207, 93, '_edit_lock', '1681994313:1'),
(1208, 94, '_wp_attached_file', 'woocommerce_uploads/inspiration-xdxngb.pdf'),
(1209, 94, '_wp_attachment_metadata', 'a:1:{s:8:"filesize";i:482592;}'),
(1210, 93, '_regular_price', '699'),
(1211, 93, '_sale_price', '599'),
(1212, 93, 'total_sales', '3'),
(1213, 93, '_tax_status', 'taxable'),
(1214, 93, '_tax_class', ''),
(1215, 93, '_manage_stock', 'no'),
(1216, 93, '_backorders', 'no'),
(1217, 93, '_sold_individually', 'no'),
(1218, 93, '_virtual', 'yes'),
(1219, 93, '_downloadable', 'yes'),
(1220, 93, '_download_limit', '-1'),
(1221, 93, '_download_expiry', '-1'),
(1222, 93, '_stock', NULL),
(1223, 93, '_stock_status', 'instock'),
(1224, 93, '_wc_average_rating', '0'),
(1225, 93, '_wc_review_count', '0'),
(1226, 93, '_downloadable_files', 'a:1:{s:36:"67ea6b5b-688a-4790-ba51-6d0c35b4532e";a:4:{s:2:"id";s:36:"67ea6b5b-688a-4790-ba51-6d0c35b4532e";s:4:"name";s:18:"Insrpiration - DLC";s:4:"file";s:86:"http://localhost/WP-Mega/wp-content/uploads/woocommerce_uploads/inspiration-xdxngb.pdf";s:7:"enabled";b:1;}}'),
(1227, 93, '_product_version', '7.6.0'),
(1228, 93, '_price', '599'),
(1229, 95, '_wp_attached_file', 'insp-dlc.png'),
(1230, 95, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:605;s:6:"height";i:907;s:4:"file";s:12:"insp-dlc.png";s:8:"filesize";i:811239;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:20:"insp-dlc-200x300.png";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:93016;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"insp-dlc-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:36974;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:20:"insp-dlc-300x400.png";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:173000;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:20:"insp-dlc-600x900.png";s:5:"width";i:600;s:6:"height";i:900;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:680602;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:20:"insp-dlc-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:18155;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1231, 93, '_thumbnail_id', '95'),
(1232, 96, '_edit_last', '1'),
(1233, 96, '_edit_lock', '1681988360:1'),
(1234, 96, 'discount_type', 'fixed_cart'),
(1235, 96, 'coupon_amount', '100'),
(1236, 96, 'individual_use', 'no'),
(1237, 96, 'usage_limit', '0'),
(1238, 96, 'usage_limit_per_user', '0'),
(1239, 96, 'limit_usage_to_x_items', '0'),
(1240, 96, 'usage_count', '0'),
(1241, 96, 'date_expires', '1695333600'),
(1242, 96, 'free_shipping', 'no'),
(1243, 96, 'exclude_sale_items', 'no'),
(1244, 93, '_sku', 'MegaShop - 0101'),
(1245, 97, '_wp_trash_meta_status', 'publish'),
(1246, 97, '_wp_trash_meta_time', '1681988919'),
(1247, 98, '_wp_trash_meta_status', 'publish'),
(1248, 98, '_wp_trash_meta_time', '1681988935'),
(1249, 99, '_order_key', 'wc_order_pr4We7C8sBbDO'),
(1250, 99, '_customer_user', '1'),
(1251, 99, '_payment_method', 'cod'),
(1252, 99, '_payment_method_title', 'Betala vid avhämtning'),
(1253, 99, '_customer_ip_address', '::1'),
(1254, 99, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'),
(1255, 99, '_created_via', 'checkout'),
(1256, 99, '_cart_hash', '51c7f5eb9786149c1f226d4127dfc2d6'),
(1257, 99, '_download_permissions_granted', 'yes'),
(1258, 99, '_recorded_sales', 'yes'),
(1259, 99, '_recorded_coupon_usage_counts', 'yes'),
(1260, 99, '_new_order_email_sent', 'true'),
(1261, 99, '_order_stock_reduced', 'yes'),
(1262, 99, '_billing_first_name', 'Martin'),
(1263, 99, '_billing_last_name', 'Johansson'),
(1264, 99, '_billing_address_1', 'Askvägen 7 lgh 1102'),
(1265, 99, '_billing_city', 'Romelanda'),
(1266, 99, '_billing_postcode', '44277'),
(1267, 99, '_billing_country', 'SE'),
(1268, 99, '_billing_email', 'mjohansson176@gmail.com'),
(1269, 99, '_billing_phone', '0761889887'),
(1270, 99, '_order_currency', 'SEK'),
(1271, 99, '_cart_discount', '0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1272, 99, '_cart_discount_tax', '0'),
(1273, 99, '_order_shipping', '0'),
(1274, 99, '_order_shipping_tax', '0'),
(1275, 99, '_order_tax', '120'),
(1276, 99, '_order_total', '599'),
(1277, 99, '_order_version', '7.6.0'),
(1278, 99, '_prices_include_tax', 'yes'),
(1279, 99, '_billing_address_index', 'Martin Johansson  Askvägen 7 lgh 1102  Romelanda  44277 SE mjohansson176@gmail.com 0761889887'),
(1280, 99, '_shipping_address_index', '         '),
(1281, 99, 'is_vat_exempt', 'no'),
(1282, 100, '_order_key', 'wc_order_QvdqqVJEO3AKJ'),
(1283, 100, '_customer_user', '1'),
(1284, 100, '_payment_method', 'cod'),
(1285, 100, '_payment_method_title', 'Betala vid avhämtning'),
(1286, 100, '_customer_ip_address', '::1'),
(1287, 100, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'),
(1288, 100, '_created_via', 'checkout'),
(1289, 100, '_cart_hash', '51c7f5eb9786149c1f226d4127dfc2d6'),
(1290, 100, '_download_permissions_granted', 'yes'),
(1291, 100, '_recorded_sales', 'yes'),
(1292, 100, '_recorded_coupon_usage_counts', 'yes'),
(1293, 100, '_new_order_email_sent', 'true'),
(1294, 100, '_order_stock_reduced', 'yes'),
(1295, 100, '_billing_first_name', 'Martin'),
(1296, 100, '_billing_last_name', 'Johansson'),
(1297, 100, '_billing_address_1', 'Askvägen 7 lgh 1102'),
(1298, 100, '_billing_city', 'Romelanda'),
(1299, 100, '_billing_postcode', '44277'),
(1300, 100, '_billing_country', 'SE'),
(1301, 100, '_billing_email', 'mjohansson176@gmail.com'),
(1302, 100, '_billing_phone', '0761889887'),
(1303, 100, '_order_currency', 'SEK'),
(1304, 100, '_cart_discount', '0'),
(1305, 100, '_cart_discount_tax', '0'),
(1306, 100, '_order_shipping', '0'),
(1307, 100, '_order_shipping_tax', '0'),
(1308, 100, '_order_tax', '120'),
(1309, 100, '_order_total', '599'),
(1310, 100, '_order_version', '7.6.0'),
(1311, 100, '_prices_include_tax', 'yes'),
(1312, 100, '_billing_address_index', 'Martin Johansson  Askvägen 7 lgh 1102  Romelanda  44277 SE mjohansson176@gmail.com 0761889887'),
(1313, 100, '_shipping_address_index', '         '),
(1314, 100, 'is_vat_exempt', 'no'),
(1315, 100, '_edit_lock', '1681994453:1'),
(1316, 100, '_edit_last', '1'),
(1317, 100, '_date_completed', '1681994559'),
(1318, 100, '_date_paid', '1681994559'),
(1319, 100, '_paid_date', '2023-04-20 14:42:39'),
(1320, 100, '_completed_date', '2023-04-20 14:42:39'),
(1321, 99, '_edit_lock', '1681995111:1'),
(1322, 99, '_edit_last', '1'),
(1323, 99, '_date_completed', '1681994872'),
(1324, 99, '_date_paid', '1681994872'),
(1325, 99, '_paid_date', '2023-04-20 14:47:52'),
(1326, 99, '_completed_date', '2023-04-20 14:47:52'),
(1327, 101, '_edit_last', '1'),
(1328, 101, '_edit_lock', '1682077640:1'),
(1338, 101, '_children', 'a:3:{i:0;i:105;i:1;i:106;i:2;i:108;}'),
(1339, 101, '_sku', 'MegaShop - 0004'),
(1340, 101, 'total_sales', '0'),
(1341, 101, '_tax_status', 'taxable'),
(1342, 101, '_tax_class', ''),
(1343, 101, '_manage_stock', 'no'),
(1344, 101, '_backorders', 'no'),
(1345, 101, '_sold_individually', 'no'),
(1346, 101, '_virtual', 'no'),
(1347, 101, '_downloadable', 'no'),
(1348, 101, '_download_limit', '-1'),
(1349, 101, '_download_expiry', '-1'),
(1350, 101, '_stock', NULL),
(1351, 101, '_stock_status', 'instock'),
(1352, 101, '_wc_average_rating', '0'),
(1353, 101, '_wc_review_count', '0'),
(1354, 101, '_product_version', '7.6.0'),
(1355, 101, '_product_image_gallery', '113,112'),
(1356, 105, '_edit_last', '1'),
(1357, 105, '_edit_lock', '1682077576:1'),
(1359, 105, 'total_sales', '0'),
(1360, 105, '_tax_status', 'taxable'),
(1361, 105, '_tax_class', ''),
(1362, 105, '_manage_stock', 'yes'),
(1363, 105, '_backorders', 'no'),
(1364, 105, '_sold_individually', 'no'),
(1365, 105, '_virtual', 'no'),
(1366, 105, '_downloadable', 'no'),
(1367, 105, '_download_limit', '-1'),
(1368, 105, '_download_expiry', '-1'),
(1369, 105, '_stock', '100.000000'),
(1370, 105, '_stock_status', 'instock'),
(1371, 105, '_wc_average_rating', '0'),
(1372, 105, '_wc_review_count', '0'),
(1373, 105, '_product_version', '7.6.0'),
(1374, 106, 'total_sales', '0'),
(1375, 106, '_tax_status', 'taxable'),
(1376, 106, '_tax_class', ''),
(1377, 106, '_manage_stock', 'yes'),
(1378, 106, '_backorders', 'no'),
(1379, 106, '_sold_individually', 'no'),
(1380, 106, '_virtual', 'no'),
(1381, 106, '_downloadable', 'no') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1382, 106, '_download_limit', '-1'),
(1383, 106, '_download_expiry', '-1'),
(1385, 106, '_stock', '100.000000'),
(1386, 106, '_stock_status', 'instock'),
(1387, 106, '_wc_average_rating', '0'),
(1388, 106, '_wc_review_count', '0'),
(1389, 106, '_product_version', '7.6.0'),
(1390, 106, '_edit_lock', '1682077557:1'),
(1392, 106, '_edit_last', '1'),
(1393, 108, '_edit_last', '1'),
(1394, 108, '_edit_lock', '1682077531:1'),
(1396, 108, 'total_sales', '0'),
(1397, 108, '_tax_status', 'taxable'),
(1398, 108, '_tax_class', ''),
(1399, 108, '_manage_stock', 'yes'),
(1400, 108, '_backorders', 'no'),
(1401, 108, '_sold_individually', 'no'),
(1402, 108, '_virtual', 'no'),
(1403, 108, '_downloadable', 'no'),
(1404, 108, '_download_limit', '-1'),
(1405, 108, '_download_expiry', '-1'),
(1406, 108, '_stock', '100.000000'),
(1407, 108, '_stock_status', 'instock'),
(1408, 108, '_wc_average_rating', '0'),
(1409, 108, '_wc_review_count', '0'),
(1410, 108, '_product_version', '7.6.0'),
(1411, 108, '_regular_price', '24'),
(1412, 108, '_weight', '0.1'),
(1413, 108, '_length', '8'),
(1414, 108, '_width', '1'),
(1415, 108, '_height', '2'),
(1416, 108, '_price', '24'),
(1417, 106, '_regular_price', '24'),
(1418, 106, '_weight', '0.1'),
(1419, 106, '_length', '8'),
(1420, 106, '_width', '1'),
(1421, 106, '_height', '2'),
(1422, 106, '_price', '24'),
(1423, 105, '_regular_price', '24'),
(1424, 105, '_weight', '0.1'),
(1425, 105, '_length', '8'),
(1426, 105, '_width', '1'),
(1427, 105, '_height', '2'),
(1428, 105, '_price', '24'),
(1429, 109, '_edit_last', '1'),
(1430, 109, '_edit_lock', '1682059313:1'),
(1431, 110, '_wp_attached_file', 'MegaShop_0005__Nike__H20.jpg'),
(1432, 110, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:2000;s:6:"height";i:2000;s:4:"file";s:28:"MegaShop_0005__Nike__H20.jpg";s:8:"filesize";i:694625;s:5:"sizes";a:8:{s:6:"medium";a:5:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6049;}s:5:"large";a:5:{s:4:"file";s:38:"MegaShop_0005__Nike__H20-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:48601;}s:9:"thumbnail";a:5:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:2554;}s:12:"medium_large";a:5:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:29286;}s:9:"1536x1536";a:5:{s:4:"file";s:38:"MegaShop_0005__Nike__H20-1536x1536.jpg";s:5:"width";i:1536;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:97834;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-300x400.jpg";s:5:"width";i:300;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8886;s:9:"uncropped";b:0;}s:18:"woocommerce_single";a:5:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19022;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:36:"MegaShop_0005__Nike__H20-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1712;}}s:10:"image_meta";a:12:{s:8:"aperture";s:2:"16";s:6:"credit";s:13:"Polara Studio";s:6:"camera";s:10:"NIKON D810";s:7:"caption";s:0:"";s:17:"created_timestamp";s:10:"1567123200";s:9:"copyright";s:45:"©2019 Polara Studio Inc. ALL RIGHTS RESERVED";s:12:"focal_length";s:2:"60";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:5:"0.008";s:5:"title";s:2:"46";s:11:"orientation";s:1:"1";s:8:"keywords";a:4:{i:0;s:4:"2019";i:1;s:4:"Nike";i:2;s:13:"Polara Studio";i:3;s:9:"hydration";}}}'),
(1433, 110, '_wp_attachment_image_alt', 'MegaShop_0005__Nike__H20'),
(1434, 109, '_thumbnail_id', '110'),
(1435, 109, '_sku', 'MegaShop - 0005'),
(1436, 109, '_regular_price', '139'),
(1437, 109, 'total_sales', '0'),
(1438, 109, '_tax_status', 'taxable'),
(1439, 109, '_tax_class', ''),
(1440, 109, '_manage_stock', 'yes'),
(1441, 109, '_backorders', 'no'),
(1442, 109, '_low_stock_amount', '4'),
(1443, 109, '_sold_individually', 'no'),
(1444, 109, '_weight', '0.1'),
(1445, 109, '_length', '7'),
(1446, 109, '_width', '7'),
(1447, 109, '_height', '15'),
(1448, 109, '_virtual', 'no'),
(1449, 109, '_downloadable', 'no'),
(1450, 109, '_download_limit', '-1'),
(1451, 109, '_download_expiry', '-1'),
(1452, 109, '_stock', '12'),
(1453, 109, '_stock_status', 'instock'),
(1454, 109, '_wc_average_rating', '0'),
(1455, 109, '_wc_review_count', '0'),
(1456, 109, '_product_version', '7.6.0'),
(1457, 109, '_price', '139'),
(1458, 111, '_wp_attached_file', 'dextro-energy-classic-sticks-3-pack-1.jpg'),
(1459, 111, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:280;s:6:"height";i:280;s:4:"file";s:41:"dextro-energy-classic-sticks-3-pack-1.jpg";s:8:"filesize";i:33769;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:49:"dextro-energy-classic-sticks-3-pack-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9792;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:49:"dextro-energy-classic-sticks-3-pack-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5456;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1460, 112, '_wp_attached_file', 'dextro-energy-cola-sticks-3-pack-0.jpg'),
(1461, 112, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:280;s:6:"height";i:280;s:4:"file";s:38:"dextro-energy-cola-sticks-3-pack-0.jpg";s:8:"filesize";i:27675;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:46:"dextro-energy-cola-sticks-3-pack-0-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8215;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:46:"dextro-energy-cola-sticks-3-pack-0-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4681;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1462, 113, '_wp_attached_file', 'dextro-energy-lemon-sticks-3-pack-1.jpg'),
(1463, 113, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:280;s:6:"height";i:280;s:4:"file";s:39:"dextro-energy-lemon-sticks-3-pack-1.jpg";s:8:"filesize";i:31188;s:5:"sizes";a:2:{s:9:"thumbnail";a:5:{s:4:"file";s:47:"dextro-energy-lemon-sticks-3-pack-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8503;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:47:"dextro-energy-lemon-sticks-3-pack-1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4743;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1464, 111, '_wp_attachment_image_alt', 'dextro-energy-classic'),
(1465, 108, '_thumbnail_id', '111'),
(1466, 112, '_wp_attachment_image_alt', 'dextro-energy-cola'),
(1467, 106, '_thumbnail_id', '112'),
(1468, 113, '_wp_attachment_image_alt', 'dextro-energy-lemon'),
(1469, 105, '_thumbnail_id', '113'),
(1470, 101, '_thumbnail_id', '111'),
(1471, 114, '_order_key', 'wc_order_xgdQ5oAyltfJM'),
(1472, 114, '_customer_user', '1'),
(1473, 114, '_payment_method', 'cod'),
(1474, 114, '_payment_method_title', 'Betala vid avhämtning'),
(1475, 114, '_customer_ip_address', '::1'),
(1476, 114, '_customer_user_agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36'),
(1477, 114, '_created_via', 'checkout'),
(1478, 114, '_cart_hash', '51c7f5eb9786149c1f226d4127dfc2d6'),
(1479, 114, '_download_permissions_granted', 'yes'),
(1480, 114, '_recorded_sales', 'yes'),
(1481, 114, '_recorded_coupon_usage_counts', 'yes'),
(1482, 114, '_new_order_email_sent', 'true'),
(1483, 114, '_order_stock_reduced', 'yes'),
(1484, 114, '_billing_first_name', 'Martin') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1485, 114, '_billing_last_name', 'Johansson'),
(1486, 114, '_billing_address_1', 'Askvägen 7 lgh 1102'),
(1487, 114, '_billing_city', 'Romelanda'),
(1488, 114, '_billing_postcode', '44277'),
(1489, 114, '_billing_country', 'SE'),
(1490, 114, '_billing_email', 'mjohansson176@gmail.com'),
(1491, 114, '_billing_phone', '0761889887'),
(1492, 114, '_order_currency', 'SEK'),
(1493, 114, '_cart_discount', '0'),
(1494, 114, '_cart_discount_tax', '0'),
(1495, 114, '_order_shipping', '0'),
(1496, 114, '_order_shipping_tax', '0'),
(1497, 114, '_order_tax', '120'),
(1498, 114, '_order_total', '599'),
(1499, 114, '_order_version', '7.6.0'),
(1500, 114, '_prices_include_tax', 'yes'),
(1501, 114, '_billing_address_index', 'Martin Johansson  Askvägen 7 lgh 1102  Romelanda  44277 SE mjohansson176@gmail.com 0761889887'),
(1502, 114, '_shipping_address_index', '         '),
(1503, 114, 'is_vat_exempt', 'no'),
(1504, 114, '_edit_lock', '1682061513:1'),
(1505, 114, '_edit_last', '1'),
(1506, 114, '_date_completed', '1682060745'),
(1507, 114, '_date_paid', '1682060745'),
(1508, 114, '_paid_date', '2023-04-21 09:05:45'),
(1509, 114, '_completed_date', '2023-04-21 09:05:45'),
(1520, 123, '_edit_last', '1'),
(1521, 123, '_edit_lock', '1682073592:1'),
(1522, 124, '_edit_last', '1'),
(1523, 124, '_edit_lock', '1682073600:1'),
(1524, 125, '_edit_last', '1'),
(1525, 125, '_edit_lock', '1682073644:1'),
(1530, 127, '_edit_last', '1'),
(1531, 127, '_edit_lock', '1682074241:1'),
(1532, 129, '_edit_last', '1'),
(1533, 129, '_edit_lock', '1682075395:1'),
(1534, 130, '_wp_trash_meta_status', 'publish'),
(1535, 130, '_wp_trash_meta_time', '1682075300'),
(1536, 131, '_wp_trash_meta_status', 'publish'),
(1537, 131, '_wp_trash_meta_time', '1682075311'),
(1538, 132, '_edit_lock', '1682075415:1'),
(1539, 132, '_wp_trash_meta_status', 'publish'),
(1540, 132, '_wp_trash_meta_time', '1682075424'),
(1541, 133, '_edit_lock', '1682075535:1'),
(1542, 133, '_customize_restore_dismissed', '1'),
(1543, 134, '_wp_trash_meta_status', 'publish'),
(1544, 134, '_wp_trash_meta_time', '1682075589'),
(1545, 135, '_wp_trash_meta_status', 'publish'),
(1546, 135, '_wp_trash_meta_time', '1682075609'),
(1547, 136, '_wp_trash_meta_status', 'publish'),
(1548, 136, '_wp_trash_meta_time', '1682075666'),
(1549, 137, '_wp_trash_meta_status', 'publish'),
(1550, 137, '_wp_trash_meta_time', '1682075672'),
(1551, 138, '_wp_trash_meta_status', 'publish'),
(1552, 138, '_wp_trash_meta_time', '1682075686'),
(1553, 139, '_wp_trash_meta_status', 'publish'),
(1554, 139, '_wp_trash_meta_time', '1682075692'),
(1555, 140, '_wp_trash_meta_status', 'publish'),
(1556, 140, '_wp_trash_meta_time', '1682075697'),
(1557, 141, '_edit_lock', '1682075783:1'),
(1558, 141, '_wp_trash_meta_status', 'publish'),
(1559, 141, '_wp_trash_meta_time', '1682075800'),
(1560, 142, '_wp_trash_meta_status', 'publish'),
(1561, 142, '_wp_trash_meta_time', '1682075877'),
(1562, 143, '_edit_lock', '1682076050:1'),
(1563, 143, '_wp_trash_meta_status', 'publish'),
(1564, 143, '_wp_trash_meta_time', '1682076069'),
(1565, 144, '_edit_lock', '1682076143:1'),
(1566, 144, '_wp_trash_meta_status', 'publish'),
(1567, 144, '_wp_trash_meta_time', '1682076153'),
(1568, 145, '_wp_trash_meta_status', 'publish'),
(1569, 145, '_wp_trash_meta_time', '1682076193'),
(1570, 146, '_edit_lock', '1682076389:1'),
(1571, 146, '_wp_trash_meta_status', 'publish'),
(1572, 146, '_wp_trash_meta_time', '1682076408'),
(1573, 147, '_wp_attached_file', 'logo.png'),
(1574, 147, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:150;s:4:"file";s:8:"logo.png";s:8:"filesize";i:14599;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:15:"logo-300x90.png";s:5:"width";i:300;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:9024;}s:9:"thumbnail";a:5:{s:4:"file";s:16:"logo-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2137;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:16:"logo-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:5145;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:16:"logo-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2121;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1575, 147, '_wp_attachment_image_alt', 'logo'),
(1576, 148, '_wp_trash_meta_status', 'publish'),
(1577, 148, '_wp_trash_meta_time', '1682076680'),
(1578, 149, '_edit_lock', '1682076694:1'),
(1579, 149, '_wp_trash_meta_status', 'publish'),
(1580, 149, '_wp_trash_meta_time', '1682076709'),
(1581, 150, '_wp_attached_file', 'logo2.png'),
(1582, 150, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:150;s:4:"file";s:9:"logo2.png";s:8:"filesize";i:8392;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:16:"logo2-300x90.png";s:5:"width";i:300;s:6:"height";i:90;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:3471;}s:9:"thumbnail";a:5:{s:4:"file";s:17:"logo2-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1742;}s:21:"woocommerce_thumbnail";a:6:{s:4:"file";s:17:"logo2-300x150.png";s:5:"width";i:300;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2364;s:9:"uncropped";b:0;}s:29:"woocommerce_gallery_thumbnail";a:5:{s:4:"file";s:17:"logo2-100x100.png";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1732;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(1583, 151, '_wp_trash_meta_status', 'publish'),
(1584, 151, '_wp_trash_meta_time', '1682076779'),
(1588, 108, '_sale_price', ''),
(1589, 106, '_sale_price', ''),
(1590, 105, '_sale_price', ''),
(1591, 152, '_edit_last', '1'),
(1592, 152, '_edit_lock', '1682077821:1') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2023-04-20 11:41:33', '2023-04-20 09:41:33', '<!-- wp:paragraph -->\n<p>Välkommen till WordPress. Detta är ditt första inlägg. Du kan redigera det eller ta bort det. Sedan är det bara att börja skriva!</p>\n<!-- /wp:paragraph -->', 'Hej världen!', '', 'trash', 'open', 'open', '', 'hej-varlden__trashed', '', '', '2023-04-20 11:51:45', '2023-04-20 09:51:45', '', 0, 'http://localhost/WP-Mega/?p=1', 0, 'post', '', 1),
(2, 1, '2023-04-20 11:41:33', '2023-04-20 09:41:33', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/WP-Mega/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'trash', 'closed', 'open', '', 'exempelsida__trashed', '', '', '2023-04-20 11:51:33', '2023-04-20 09:51:33', '', 0, 'http://localhost/WP-Mega/?page_id=2', 0, 'page', '', 0),
(3, 1, '2023-04-20 11:41:33', '2023-04-20 09:41:33', '<!-- wp:heading --><h2>Vilka vi är</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Vår webbplatsadress är: http://localhost/WP-Mega.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Kommentarer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>När besökare lämnar kommentarer på webbplatsen samlar vi in de uppgifter som visas i kommentarsformuläret samt besökarens IP-adress och webbläsarens användaragent-sträng som hjälp för detektering av skräppost.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>En anonymiserad sträng som skapats utifrån din e-postadress (även kallat hash-värde) kan komma att sändas till tjänsten Gravatar för att avgöra om du finns registrerad där. Integritetspolicyn för tjänsten Gravatar finns på https://automattic.com/privacy/. När din kommentar har godkänts visas din profilbild offentligt tillsammans med din kommentar.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Media</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du laddar upp bilder till webbplatsen bör du undvika att ladda upp bilder där EXIF-data inkluderar data från GPS-lokalisering. Besökare till webbplatsen kan ladda ned och ta fram alla positioneringsuppgifter från bilder på webbplatsen.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookie-filer</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du lämnar en kommentar på vår webbplats kan du välja att spara ditt namn, din e-postadress och webbplatsadress i cookie-filer. Detta är för din bekvämlighet för att du inte ska behöva fylla i dessa uppgifter igen nästa gång du skriver en kommentar. Dessa cookie-filer gäller i ett år.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du besöker vår inloggningssida kommer vi att sätta en tillfällig cookie för att undersöka om din webbläsare accepterar dem. Denna cookie innehåller inga personuppgifter och den försvinner när du stänger din webbläsare.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>När du loggar in kommer vi dessutom att skapa flera cookie-filer för att spara information om din inloggning och dina val för utformning av skärmlayouten. Cookie-filer för inloggning gäller i två dagar och cookie-filer för layoutval gäller i ett år. Om du kryssar i ”Kom ihåg mig” kommer din cookie att finnas kvar i två veckor. Om du loggar ut från ditt konto kommer cookie-filerna för inloggning att tas bort.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Om du redigerar eller publicerar en artikel kommer en extra cookie-fil att sparas i din webbläsare. Denna cookie-fil innehåller inga personuppgifter utan anger endast inläggs-ID för den artikel du just redigerade och löper ut efter ett dygn.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Inbäddad innehåll från andra webbplatser</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Artiklar på denna webbplats kan innehålla inbäddat innehåll (exempelvis videoklipp, bilder, artiklar o.s.v.). Inbäddat innehåll från andra webbplatser beter sig precis på samma sätt som om besökaren har besökt den andra webbplatsen.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Dessa webbplatser kan samla in uppgifter om dig, använda cookie-filer, bädda in ytterligare spårning från tredje part och övervaka din interaktion med sagda inbäddade innehåll, inklusive spårning av din interaktion med detta inbäddade innehåll om du har ett konto och är inloggad på webbplatsen i fråga.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka vi delar dina data med</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du begär återställning av lösenordet kommer din IP-adress att ingå i e-postmeddelandet om återställning.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Hur länge vi behåller era uppgifter</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du skriver en kommentar kommer kommentaren och dess metadata att sparas utan tidsgräns. Anledningen till detta är att vi behöver kunna hitta och godkänna uppföljningskommentarer automatiskt och inte lägga dem i kö för granskning.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>För användare som registrerar sig på er webbplats (om sådana finns) sparar vi även de personuppgifter de anger i sin användarprofil. Alla användare kan se, redigera eller radera sina personuppgifter när som helst (med undantaget att de inte kan ändra sitt användarnamn). Även webbplatsens administratörer kan se och redigera denna information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vilka rättigheter du har över dina data</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Om du har ett konto eller har skrivit några kommentarer på denna webbplats kan du begära en exportfil med de personuppgifter vi har om dig, inklusive alla uppgifter du har gett oss. Du kan också begära att vi tar bort alla personuppgifter vi har om dig. Detta omfattar inte eventuella uppgifter som vi är tvungna att spara av administrativa, legala eller säkerhetsändamål.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Vart dina uppgifter skickas</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Föreslagen text: </strong>Kommentarer från besökare kanske kontrolleras via en automatiserad tjänst för detektering av skräppost.</p><!-- /wp:paragraph -->', 'Integritetspolicy', '', 'draft', 'closed', 'open', '', 'integritetspolicy', '', '', '2023-04-20 11:41:33', '2023-04-20 09:41:33', '', 0, 'http://localhost/WP-Mega/?page_id=3', 0, 'page', '', 0),
(4, 1, '2023-04-20 11:41:41', '0000-00-00 00:00:00', '', 'Automatiskt utkast', '', 'auto-draft', 'open', 'open', '', '', '', '', '2023-04-20 11:41:41', '0000-00-00 00:00:00', '', 0, 'http://localhost/WP-Mega/?p=4', 0, 'post', '', 0),
(5, 1, '2023-04-20 11:44:05', '2023-04-20 09:44:05', '', 'woocommerce-placeholder', '', 'inherit', 'open', 'closed', '', 'woocommerce-placeholder', '', '', '2023-04-20 11:44:05', '2023-04-20 09:44:05', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/2023/04/woocommerce-placeholder.png', 0, 'attachment', 'image/png', 0),
(6, 1, '2023-04-20 11:44:06', '2023-04-20 09:44:06', '', 'Shop', '', 'publish', 'closed', 'closed', '', 'shop', '', '', '2023-04-21 11:13:52', '2023-04-21 09:13:52', '', 0, 'http://localhost/WP-Mega/shop/', 0, 'page', '', 0),
(7, 1, '2023-04-20 11:44:06', '2023-04-20 09:44:06', '<!-- wp:shortcode -->[woocommerce_cart]<!-- /wp:shortcode -->', 'Cart', '', 'publish', 'closed', 'closed', '', 'cart', '', '', '2023-04-20 11:44:06', '2023-04-20 09:44:06', '', 0, 'http://localhost/WP-Mega/cart/', 0, 'page', '', 0),
(8, 1, '2023-04-20 11:44:06', '2023-04-20 09:44:06', '<!-- wp:shortcode -->[woocommerce_checkout]<!-- /wp:shortcode -->', 'Checkout', '', 'publish', 'closed', 'closed', '', 'checkout', '', '', '2023-04-20 11:44:06', '2023-04-20 09:44:06', '', 0, 'http://localhost/WP-Mega/checkout/', 0, 'page', '', 0),
(9, 1, '2023-04-20 11:44:06', '2023-04-20 09:44:06', '<!-- wp:shortcode -->[woocommerce_my_account]<!-- /wp:shortcode -->', 'My account', '', 'publish', 'closed', 'closed', '', 'my-account', '', '', '2023-04-20 11:44:06', '2023-04-20 09:44:06', '', 0, 'http://localhost/WP-Mega/my-account/', 0, 'page', '', 0),
(10, 1, '2023-04-20 11:44:06', '0000-00-00 00:00:00', '<!-- wp:paragraph -->\n<p><b>This is a sample page.</b></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h3>Overview</h3>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Our refund and returns policy lasts 30 days. If 30 days have passed since your purchase, we can’t offer you a full refund or exchange.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To be eligible for a return, your item must be unused and in the same condition that you received it. It must also be in the original packaging.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Several types of goods are exempt from being returned. Perishable goods such as food, flowers, newspapers or magazines cannot be returned. We also do not accept products that are intimate or sanitary goods, hazardous materials, or flammable liquids or gases.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Additional non-returnable items:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Gift cards</li>\n<li>Downloadable software products</li>\n<li>Some health and personal care items</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<p>To complete your return, we require a receipt or proof of purchase.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Please do not send your purchase back to the manufacturer.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>There are certain situations where only partial refunds are granted:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:list -->\n<ul>\n<li>Book with obvious signs of use</li>\n<li>CD, DVD, VHS tape, software, video game, cassette tape, or vinyl record that has been opened.</li>\n<li>Any item not in its original condition, is damaged or missing parts for reasons not due to our error.</li>\n<li>Any item that is returned more than 30 days after delivery</li>\n</ul>\n<!-- /wp:list -->\n\n<!-- wp:paragraph -->\n<h2>Refunds</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Once your return is received and inspected, we will send you an email to notify you that we have received your returned item. We will also notify you of the approval or rejection of your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are approved, then your refund will be processed, and a credit will automatically be applied to your credit card or original method of payment, within a certain amount of days.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Late or missing refunds</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you haven’t received a refund yet, first check your bank account again.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Then contact your credit card company, it may take some time before your refund is officially posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Next contact your bank. There is often some processing time before a refund is posted.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you’ve done all of this and you still have not received your refund yet, please contact us at {email address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<b>Sale items</b>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Only regular priced items may be refunded. Sale items cannot be refunded.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Exchanges</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>We only replace items if they are defective or damaged. If you need to exchange it for the same item, send us an email at {email address} and send your item to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Gifts</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item was marked as a gift when purchased and shipped directly to you, you’ll receive a gift credit for the value of your return. Once the returned item is received, a gift certificate will be mailed to you.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If the item wasn’t marked as a gift when purchased, or the gift giver had the order shipped to themselves to give to you later, we will send a refund to the gift giver and they will find out about your return.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Shipping returns</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>To return your product, you should mail your product to: {physical address}.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>You will be responsible for paying for your own shipping costs for returning your item. Shipping costs are non-refundable. If you receive a refund, the cost of return shipping will be deducted from your refund.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Depending on where you live, the time it may take for your exchanged product to reach you may vary.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>If you are returning more expensive items, you may consider using a trackable shipping service or purchasing shipping insurance. We don’t guarantee that we will receive your returned item.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<h2>Need help?</h2>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Contact us at {email} for questions related to refunds and returns.</p>\n<!-- /wp:paragraph -->', 'Refund and Returns Policy', '', 'draft', 'closed', 'closed', '', 'refund_returns', '', '', '2023-04-20 11:44:06', '0000-00-00 00:00:00', '', 0, 'http://localhost/WP-Mega/?page_id=10', 0, 'page', '', 0),
(11, 1, '2023-04-20 11:51:33', '2023-04-20 09:51:33', '<!-- wp:paragraph -->\n<p>Detta är en exempelsida. Den skiljer sig från ett blogginlägg genom att den finns kvar på samma plats och kommer att visas i din webbplatsnavigering (i de flesta teman). De flesta börjar med en Om-sida som presenterar dem för potentiella besökare. Den skulle t.ex kunna ha följande innehåll:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Hej där! Jag är cykelbud på dagen, blivande skådespelare på natten och detta är min blogg. Jag bor i Örebro, har en katt som heter Lurv och jag gillar Pina Coladas. (och att simma i Göta kanal).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>... eller något liknande detta:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Företaget AB grundades 1971 och har sedan dess varit den största leverantören av grunk-manicker på den svenska marknaden. FAB finns i utkanten av Grönköping, har drygt 20&nbsp;000 anställda och läser veckobladet varje år.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Som ny WordPress-användare bör du gå till <a href="http://localhost/WP-Mega/wp-admin/">din adminpanel</a> för att ta bort denna sida och skapa nya sidor för ditt innehåll. Lycka till!</p>\n<!-- /wp:paragraph -->', 'Exempelsida', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2023-04-20 11:51:33', '2023-04-20 09:51:33', '', 2, 'http://localhost/WP-Mega/?p=11', 0, 'revision', '', 0),
(12, 1, '2023-04-20 11:51:45', '2023-04-20 09:51:45', '<!-- wp:paragraph -->\n<p>Välkommen till WordPress. Detta är ditt första inlägg. Du kan redigera det eller ta bort det. Sedan är det bara att börja skriva!</p>\n<!-- /wp:paragraph -->', 'Hej världen!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2023-04-20 11:51:45', '2023-04-20 09:51:45', '', 1, 'http://localhost/WP-Mega/?p=12', 0, 'revision', '', 0),
(13, 1, '2023-04-20 12:00:33', '2023-04-20 10:00:33', '<ul class="sales-arguments">\r\n 	<li>Träningstights</li>\r\n 	<li>Damstorlekar</li>\r\n 	<li>Fyrvägsstretch för bra rörlighet</li>\r\n 	<li>Effektiv andasfunktion</li>\r\n 	<li>Hög midja</li>\r\n 	<li>57% nylon, 35% polyester och 8% elastan</li>\r\n</ul>', 'ICANIWILL - Tights', '<pre class="pdp__product-information xsmall-12 medium-auto cell"><span class="pdp__product-name">W Define Seamless Tights</span></pre>', 'trash', 'open', 'closed', '', 'icaniwill-tights__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=13', 0, 'product', '', 0),
(15, 1, '2023-04-20 12:05:18', '2023-04-20 10:05:18', '', 'ICANIWILL - Tights - Svart, S', 'Färg: Svart, Storlek: S', 'trash', 'closed', 'closed', '', 'icaniwill-tights-s-svart__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=15', 1, 'product_variation', '', 0),
(16, 1, '2023-04-20 12:05:18', '2023-04-20 10:05:18', '', 'ICANIWILL - Tights - Svart, M', 'Färg: Svart, Storlek: M', 'trash', 'closed', 'closed', '', 'icaniwill-tights-m-svart__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=16', 2, 'product_variation', '', 0),
(17, 1, '2023-04-20 12:05:18', '2023-04-20 10:05:18', '', 'ICANIWILL - Tights - Svart, L', 'Färg: Svart, Storlek: L', 'trash', 'closed', 'closed', '', 'icaniwill-tights-l-svart__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=17', 3, 'product_variation', '', 0),
(18, 1, '2023-04-20 12:05:18', '2023-04-20 10:05:18', '', 'ICANIWILL - Tights - Svart, XL', 'Färg: Svart, Storlek: XL', 'trash', 'closed', 'closed', '', 'icaniwill-tights-xl-svart__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=18', 4, 'product_variation', '', 0),
(19, 1, '2023-04-20 12:05:18', '2023-04-20 10:05:18', '', 'ICANIWILL - Tights - Grafit, S', 'Färg: Grafit, Storlek: S', 'trash', 'closed', 'closed', '', 'icaniwill-tights-s-grafit__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=19', 5, 'product_variation', '', 0),
(20, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grafit, M', 'Färg: Grafit, Storlek: M', 'trash', 'closed', 'closed', '', 'icaniwill-tights-m-grafit__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=20', 6, 'product_variation', '', 0),
(21, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grafit, L', 'Färg: Grafit, Storlek: L', 'trash', 'closed', 'closed', '', 'icaniwill-tights-l-grafit__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=21', 7, 'product_variation', '', 0),
(22, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grafit, XL', 'Färg: Grafit, Storlek: XL', 'trash', 'closed', 'closed', '', 'icaniwill-tights-xl-grafit__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=22', 8, 'product_variation', '', 0),
(23, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grön, S', 'Färg: Grön, Storlek: S', 'trash', 'closed', 'closed', '', 'icaniwill-tights-s-gron__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=23', 9, 'product_variation', '', 0),
(24, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grön, M', 'Färg: Grön, Storlek: M', 'trash', 'closed', 'closed', '', 'icaniwill-tights-m-gron__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=24', 10, 'product_variation', '', 0),
(25, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grön, L', 'Färg: Grön, Storlek: L', 'trash', 'closed', 'closed', '', 'icaniwill-tights-l-gron__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=25', 11, 'product_variation', '', 0),
(26, 1, '2023-04-20 12:05:19', '2023-04-20 10:05:19', '', 'ICANIWILL - Tights - Grön, XL', 'Färg: Grön, Storlek: XL', 'trash', 'closed', 'closed', '', 'icaniwill-tights-xl-gron__trashed', '', '', '2023-04-20 12:27:44', '2023-04-20 10:27:44', '', 13, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=26', 12, 'product_variation', '', 0),
(39, 1, '2023-04-20 12:17:46', '2023-04-20 10:17:46', '{"show_on_front":{"value":"page","type":"option","user_id":1,"date_modified_gmt":"2023-04-20 10:17:46"},"page_on_front":{"value":"6","type":"option","user_id":1,"date_modified_gmt":"2023-04-20 10:17:46"}}', '', '', 'trash', 'closed', 'closed', '', 'e0422016-0d9f-4eb7-822c-342d1538ea20', '', '', '2023-04-20 12:17:46', '2023-04-20 10:17:46', '', 0, 'http://localhost/WP-Mega/2023/04/20/e0422016-0d9f-4eb7-822c-342d1538ea20/', 0, 'customize_changeset', '', 0),
(40, 1, '2023-04-20 12:18:28', '2023-04-20 10:18:28', '{"blocksy::single_page_structure":{"value":"type-3","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:18:28"}}', '', '', 'trash', 'closed', 'closed', '', 'cc9dfc5e-31bf-4730-b6f7-eb7cae87c71d', '', '', '2023-04-20 12:18:28', '2023-04-20 10:18:28', '', 0, 'http://localhost/WP-Mega/2023/04/20/cc9dfc5e-31bf-4730-b6f7-eb7cae87c71d/', 0, 'customize_changeset', '', 0),
(41, 1, '2023-04-20 12:18:34', '2023-04-20 10:18:34', '{"blocksy::single_page_hero_enabled":{"value":"no","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:18:34"}}', '', '', 'trash', 'closed', 'closed', '', '87833ce9-17d2-45b4-8388-4bcbc6bb53bc', '', '', '2023-04-20 12:18:34', '2023-04-20 10:18:34', '', 0, 'http://localhost/WP-Mega/2023/04/20/87833ce9-17d2-45b4-8388-4bcbc6bb53bc/', 0, 'customize_changeset', '', 0),
(42, 1, '2023-04-20 12:18:44', '2023-04-20 10:18:44', '{"blocksy::single_page_hero_enabled":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:18:44"}}', '', '', 'trash', 'closed', 'closed', '', '08311836-ec37-472d-b98c-f83622bbeccc', '', '', '2023-04-20 12:18:44', '2023-04-20 10:18:44', '', 0, 'http://localhost/WP-Mega/2023/04/20/08311836-ec37-472d-b98c-f83622bbeccc/', 0, 'customize_changeset', '', 0),
(43, 1, '2023-04-20 12:19:22', '2023-04-20 10:19:22', '{"blocksy::single_blog_post_has_featured_image":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:19:22"},"blocksy::single_blog_post_has_post_tags":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:19:22"},"blocksy::single_blog_post_has_share_box":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:19:22"},"blocksy::single_blog_post_has_related_posts":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 10:19:22"}}', '', '', 'trash', 'closed', 'closed', '', '2f7674b6-01ef-4575-b305-fc1a2868605f', '', '', '2023-04-20 12:19:22', '2023-04-20 10:19:22', '', 0, 'http://localhost/WP-Mega/2023/04/20/2f7674b6-01ef-4575-b305-fc1a2868605f/', 0, 'customize_changeset', '', 0),
(44, 1, '2023-04-20 12:23:42', '2023-04-20 10:23:42', 'sdfasdfasf', 'TestProdukt', 'asdfas', 'draft', 'open', 'closed', '', 'testprodukt', '', '', '2023-04-20 12:55:38', '2023-04-20 10:55:38', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=44', 0, 'product', '', 0),
(46, 1, '2023-04-20 12:27:47', '2023-04-20 10:27:47', 'Laila W Tracksuit Set passar såväl träning utomhus som inomhus. Den ger ett bra skydd mot kyliga vindar och den goda andningsbarheten gör att du slipper bli för varm eller svettig. Träningströjan har hög krage och hellång dragkedja. Byxorna justeras i midjan och har öppna sidofickor. Muddarna på såväl jacka som byxor är elastiska. Setet har flera reflexdetaljer som ger ökad synlighet och säkerhet ute i trafiken.\r\n\r\nEGENSKAPER\r\n– Vindtät\r\n– Bra andningsförmåga\r\n– Hög krage\r\n– Hellång dragkedja\r\n– Öppna sidofickor\r\n– Justerbar midja\r\n– Elastiska muddar\r\n\r\nSPECIFIKATION\r\n– Huvudmaterial: 100% polyester\r\n– Material foder: 100% polyester mesh', 'Laila W Tracksuit Set', 'Vindtät och andningsbar träningsoverall för damer.', 'publish', 'open', 'closed', '', 'laila-w-tracksuit-set', '', '', '2023-04-20 12:31:23', '2023-04-20 10:31:23', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=46', 0, 'product', '', 0),
(47, 1, '2023-04-20 12:28:56', '2023-04-20 10:28:56', 'overall_001', 'overall_001', 'overall_001', 'inherit', 'open', 'closed', '', 'overall_001', '', '', '2023-04-20 12:29:04', '2023-04-20 10:29:04', '', 46, 'http://localhost/WP-Mega/wp-content/uploads/overall_001.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2023-04-20 12:29:42', '2023-04-20 10:29:42', '', 'Laila W Tracksuit Set - XS', 'Storlek: XS', 'publish', 'closed', 'closed', '', 'laila-w-tracksuit-set-xs', '', '', '2023-04-20 12:31:10', '2023-04-20 10:31:10', '', 46, 'http://localhost/WP-Mega/?post_type=product_variation&p=48', 1, 'product_variation', '', 0),
(49, 1, '2023-04-20 12:29:43', '2023-04-20 10:29:43', '', 'Laila W Tracksuit Set - S', 'Storlek: S', 'publish', 'closed', 'closed', '', 'laila-w-tracksuit-set-s', '', '', '2023-04-20 12:31:10', '2023-04-20 10:31:10', '', 46, 'http://localhost/WP-Mega/?post_type=product_variation&p=49', 2, 'product_variation', '', 0),
(50, 1, '2023-04-20 12:29:43', '2023-04-20 10:29:43', '', 'Laila W Tracksuit Set - M', 'Storlek: M', 'publish', 'closed', 'closed', '', 'laila-w-tracksuit-set-m', '', '', '2023-04-20 12:31:10', '2023-04-20 10:31:10', '', 46, 'http://localhost/WP-Mega/?post_type=product_variation&p=50', 3, 'product_variation', '', 0),
(51, 1, '2023-04-20 12:29:43', '2023-04-20 10:29:43', '', 'Laila W Tracksuit Set - L', 'Storlek: L', 'publish', 'closed', 'closed', '', 'laila-w-tracksuit-set-l', '', '', '2023-04-20 12:31:10', '2023-04-20 10:31:10', '', 46, 'http://localhost/WP-Mega/?post_type=product_variation&p=51', 4, 'product_variation', '', 0),
(52, 1, '2023-04-20 12:29:43', '2023-04-20 10:29:43', '', 'Laila W Tracksuit Set - XL', 'Storlek: XL', 'publish', 'closed', 'closed', '', 'laila-w-tracksuit-set-xl', '', '', '2023-04-20 12:31:10', '2023-04-20 10:31:10', '', 46, 'http://localhost/WP-Mega/?post_type=product_variation&p=52', 5, 'product_variation', '', 0),
(53, 1, '2023-04-20 12:33:35', '2023-04-20 10:33:35', 'Laila W Tracksuit Set passar såväl träning utomhus som inomhus. Den ger ett bra skydd mot kyliga vindar och den goda andningsbarheten gör att du slipper bli för varm eller svettig. Träningströjan har hög krage och hellång dragkedja. Byxorna justeras i midjan och har öppna sidofickor. Muddarna på såväl jacka som byxor är elastiska. Setet har flera reflexdetaljer som ger ökad synlighet och säkerhet ute i trafiken.\r\n\r\nEGENSKAPER\r\n– Vindtät\r\n– Bra andningsförmåga\r\n– Hög krage\r\n– Hellång dragkedja\r\n– Öppna sidofickor\r\n– Justerbar midja\r\n– Elastiska muddar\r\n\r\nSPECIFIKATION\r\n– Huvudmaterial: 100% polyester\r\n– Material foder: 100% polyester mesh', 'Laila W Tracksuit Set (Copy)', 'Vindtät och andningsbar träningsoverall för damer.', 'trash', 'open', 'closed', '', '__trashed', '', '', '2023-04-20 12:33:53', '2023-04-20 10:33:53', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=53', 0, 'product', '', 0),
(54, 1, '2023-04-20 12:33:35', '2023-04-20 10:33:35', '', 'Laila W Tracksuit Set (Copy) - XS', 'Storlek: XS', 'trash', 'closed', 'closed', '', 'laila-w-tracksuit-set-xs-2__trashed', '', '', '2023-04-20 12:33:52', '2023-04-20 10:33:52', '', 53, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=54', 1, 'product_variation', '', 0),
(55, 1, '2023-04-20 12:33:36', '2023-04-20 10:33:36', '', 'Laila W Tracksuit Set (Copy) - S', 'Storlek: S', 'trash', 'closed', 'closed', '', 'laila-w-tracksuit-set-s-2__trashed', '', '', '2023-04-20 12:33:52', '2023-04-20 10:33:52', '', 53, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=55', 2, 'product_variation', '', 0),
(56, 1, '2023-04-20 12:33:36', '2023-04-20 10:33:36', '', 'Laila W Tracksuit Set (Copy) - M', 'Storlek: M', 'trash', 'closed', 'closed', '', 'laila-w-tracksuit-set-m-2__trashed', '', '', '2023-04-20 12:33:52', '2023-04-20 10:33:52', '', 53, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=56', 3, 'product_variation', '', 0),
(57, 1, '2023-04-20 12:33:36', '2023-04-20 10:33:36', '', 'Laila W Tracksuit Set (Copy) - L', 'Storlek: L', 'trash', 'closed', 'closed', '', 'laila-w-tracksuit-set-l-2__trashed', '', '', '2023-04-20 12:33:52', '2023-04-20 10:33:52', '', 53, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=57', 4, 'product_variation', '', 0),
(58, 1, '2023-04-20 12:33:36', '2023-04-20 10:33:36', '', 'Laila W Tracksuit Set (Copy) - XL', 'Storlek: XL', 'trash', 'closed', 'closed', '', 'laila-w-tracksuit-set-xl-2__trashed', '', '', '2023-04-20 12:33:52', '2023-04-20 10:33:52', '', 53, 'http://localhost/WP-Mega/?post_type=product_variation&#038;p=58', 5, 'product_variation', '', 0),
(59, 1, '2023-04-20 12:35:38', '2023-04-20 10:35:38', 'Dessa tights är utformade i ett mjukt stretchtyg som är utrustat med utmärkta fuktavvisande egenskaper. En dragsko i midjan ger en justerbar passform medan den dolda fickan är funktionell för förvaring av mindre saker. Med en platt sömkonstruktion för att minska skav har dessa tights också en reflekterande ASICS-logo på framsidan för ökad synlighet i mörker.\r\n\r\nEGENSKAPER\r\n– Snabbtorkande\r\n– Platta sömmar\r\n– Innerficka\r\n– Justerbar midjedragsko\r\n– Reflekterande detaljer\r\n\r\nSPECIFIKATION\r\n– Material: 79% Polyester, 21% Spandex', 'Core Tight - Asics', 'Löpartights i ett mjukt stretchtyg med god fukttransport för bästa funktion och komfort. Tightsen har även en platt sömkonstruktion som minimerar risken för skav.', 'publish', 'open', 'closed', '', 'core-tight-asics', '', '', '2023-04-20 12:40:31', '2023-04-20 10:40:31', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=59', 0, 'product', '', 0),
(60, 1, '2023-04-20 12:36:27', '2023-04-20 10:36:27', '', 'MegaShop_0002 - tights_01', '', 'inherit', 'open', 'closed', '', 'megashop_0002-tights_01', '', '', '2023-04-20 12:36:27', '2023-04-20 10:36:27', '', 59, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0002-tights_01.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2023-04-20 12:36:28', '2023-04-20 10:36:28', '', 'MegaShop_0002 - tights_02', '', 'inherit', 'open', 'closed', '', 'megashop_0002-tights_02', '', '', '2023-04-20 12:36:28', '2023-04-20 10:36:28', '', 59, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0002-tights_02.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2023-04-20 12:36:30', '2023-04-20 10:36:30', '', 'MegaShop_0002 - tights_03', '', 'inherit', 'open', 'closed', '', 'megashop_0002-tights_03', '', '', '2023-04-20 12:36:30', '2023-04-20 10:36:30', '', 59, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0002-tights_03.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2023-04-20 12:36:32', '2023-04-20 10:36:32', 'tights', 'MegaShop_0002 - tights_04', 'tights', 'inherit', 'open', 'closed', '', 'megashop_0002-tights_04', '', '', '2023-04-20 12:36:53', '2023-04-20 10:36:53', '', 59, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0002-tights_04.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2023-04-20 12:39:43', '2023-04-20 10:39:43', '', 'Core Tight - Asics - XS', 'Storlek: XS', 'publish', 'closed', 'closed', '', 'core-tight-asics-xs', '', '', '2023-04-20 12:40:23', '2023-04-20 10:40:23', '', 59, 'http://localhost/WP-Mega/?post_type=product_variation&p=64', 1, 'product_variation', '', 0),
(65, 1, '2023-04-20 12:39:43', '2023-04-20 10:39:43', '', 'Core Tight - Asics - S', 'Storlek: S', 'publish', 'closed', 'closed', '', 'core-tight-asics-s', '', '', '2023-04-20 12:40:24', '2023-04-20 10:40:24', '', 59, 'http://localhost/WP-Mega/?post_type=product_variation&p=65', 2, 'product_variation', '', 0),
(66, 1, '2023-04-20 12:39:43', '2023-04-20 10:39:43', '', 'Core Tight - Asics - M', 'Storlek: M', 'publish', 'closed', 'closed', '', 'core-tight-asics-m', '', '', '2023-04-20 12:40:24', '2023-04-20 10:40:24', '', 59, 'http://localhost/WP-Mega/?post_type=product_variation&p=66', 3, 'product_variation', '', 0),
(67, 1, '2023-04-20 12:39:43', '2023-04-20 10:39:43', '', 'Core Tight - Asics - L', 'Storlek: L', 'publish', 'closed', 'closed', '', 'core-tight-asics-l', '', '', '2023-04-20 12:40:24', '2023-04-20 10:40:24', '', 59, 'http://localhost/WP-Mega/?post_type=product_variation&p=67', 4, 'product_variation', '', 0),
(68, 1, '2023-04-20 12:39:43', '2023-04-20 10:39:43', '', 'Core Tight - Asics - XL', 'Storlek: XL', 'publish', 'closed', 'closed', '', 'core-tight-asics-xl', '', '', '2023-04-20 12:40:24', '2023-04-20 10:40:24', '', 59, 'http://localhost/WP-Mega/?post_type=product_variation&p=68', 5, 'product_variation', '', 0),
(69, 1, '2023-04-20 12:41:14', '2023-04-20 10:41:14', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-blocksy', '', '', '2023-04-20 12:41:14', '2023-04-20 10:41:14', '', 0, 'http://localhost/WP-Mega/2023/04/20/wp-global-styles-blocksy/', 0, 'wp_global_styles', '', 0),
(70, 1, '2023-04-20 12:45:34', '2023-04-20 10:45:34', 'CORE Unify Logo Tee är en mångsidig t-shirt som passar till de flesta aktiviteter. Tröjan är tillverkad av återvunnen, mjuk och funktionell polyester. Den har en utmärkt fukttransport som leder bort svett från kroppen så du hålls torr, sval och fräsch. T-shirten har framflyttade sidsömmar för god passform.\r\n\r\nEGENSKAPER\r\n– Återvunnen polyester\r\n– Framflyttade sidsömmar\r\n– Fukttransporterande\r\n\r\nSPECIFIKATION\r\n– Material: 100% återvunnen polyester', 'Core Essence Logo Tee W', 'CORE Unify Logo Tee är en tränings t-shirt av återvunnen och funktionell polyester med bekväm passform för en aktiv livsstil.', 'publish', 'open', 'closed', '', 'core-essence-logo-tee-w', '', '', '2023-04-20 12:51:29', '2023-04-20 10:51:29', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=70', 0, 'product', '', 0),
(71, 1, '2023-04-20 12:46:23', '2023-04-20 10:46:23', '', 'MegaShop_0003 - tshirt_01_dawn', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_dawn', '', '', '2023-04-20 12:46:23', '2023-04-20 10:46:23', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_dawn.jpg', 0, 'attachment', 'image/jpeg', 0),
(72, 1, '2023-04-20 12:46:24', '2023-04-20 10:46:24', '', 'MegaShop_0003 - tshirt_01_dawn_model_01', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_dawn_model_01', '', '', '2023-04-20 12:46:24', '2023-04-20 10:46:24', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_dawn_model_01.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2023-04-20 12:46:26', '2023-04-20 10:46:26', '', 'MegaShop_0003 - tshirt_01_dawn_model_02', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_dawn_model_02', '', '', '2023-04-20 12:46:26', '2023-04-20 10:46:26', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_dawn_model_02.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2023-04-20 12:46:28', '2023-04-20 10:46:28', '', 'MegaShop_0003 - tshirt_01_pink', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_pink', '', '', '2023-04-20 12:46:28', '2023-04-20 10:46:28', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_pink.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2023-04-20 12:46:29', '2023-04-20 10:46:29', '', 'MegaShop_0003 - tshirt_01_pink_back', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_pink_back', '', '', '2023-04-20 12:46:29', '2023-04-20 10:46:29', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_pink_back.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2023-04-20 12:46:31', '2023-04-20 10:46:31', '', 'MegaShop_0003 - tshirt_01_pink_model_01', '', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_pink_model_01', '', '', '2023-04-20 12:46:31', '2023-04-20 10:46:31', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_pink_model_01.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2023-04-20 12:46:33', '2023-04-20 10:46:33', 'tshirt', 'tshirt', 'tshirt', 'inherit', 'open', 'closed', '', 'megashop_0003-tshirt_01_svart', '', '', '2023-04-20 12:46:49', '2023-04-20 10:46:49', '', 70, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0003-tshirt_01_svart.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2023-04-20 12:47:42', '2023-04-20 10:47:42', '', 'Core Essence Logo Tee W - XS, Svart', 'Storlek: XS, Färg: Svart', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-svart-xs', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=78', 1, 'product_variation', '', 0),
(79, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - XS, Rosa', 'Storlek: XS, Färg: Rosa', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-rosa-xs', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=79', 2, 'product_variation', '', 0),
(80, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - XS, Dawn (Mörkblå)', 'Storlek: XS, Färg: Dawn (Mörkblå)', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-dawn-morkbla-xs', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=80', 3, 'product_variation', '', 0),
(81, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - S, Svart', 'Storlek: S, Färg: Svart', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-svart-s', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=81', 4, 'product_variation', '', 0),
(82, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - S, Rosa', 'Storlek: S, Färg: Rosa', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-rosa-s', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=82', 5, 'product_variation', '', 0),
(83, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - S, Dawn (Mörkblå)', 'Storlek: S, Färg: Dawn (Mörkblå)', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-dawn-morkbla-s', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=83', 6, 'product_variation', '', 0),
(84, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - M, Svart', 'Storlek: M, Färg: Svart', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-svart-m', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=84', 7, 'product_variation', '', 0),
(85, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - M, Rosa', 'Storlek: M, Färg: Rosa', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-rosa-m', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=85', 8, 'product_variation', '', 0),
(86, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - M, Dawn (Mörkblå)', 'Storlek: M, Färg: Dawn (Mörkblå)', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-dawn-morkbla-m', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=86', 9, 'product_variation', '', 0),
(87, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - L, Svart', 'Storlek: L, Färg: Svart', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-svart-l', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=87', 10, 'product_variation', '', 0),
(88, 1, '2023-04-20 12:47:43', '2023-04-20 10:47:43', '', 'Core Essence Logo Tee W - L, Rosa', 'Storlek: L, Färg: Rosa', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-rosa-l', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=88', 11, 'product_variation', '', 0),
(89, 1, '2023-04-20 12:47:44', '2023-04-20 10:47:44', '', 'Core Essence Logo Tee W - L, Dawn (Mörkblå)', 'Storlek: L, Färg: Dawn (Mörkblå)', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-dawn-morkbla-l', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=89', 12, 'product_variation', '', 0),
(90, 1, '2023-04-20 12:47:44', '2023-04-20 10:47:44', '', 'Core Essence Logo Tee W - XL, Svart', 'Storlek: XL, Färg: Svart', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-svart-xl', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=90', 13, 'product_variation', '', 0),
(91, 1, '2023-04-20 12:47:44', '2023-04-20 10:47:44', '', 'Core Essence Logo Tee W - XL, Rosa', 'Storlek: XL, Färg: Rosa', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-rosa-xl', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=91', 14, 'product_variation', '', 0),
(92, 1, '2023-04-20 12:47:44', '2023-04-20 10:47:44', '', 'Core Essence Logo Tee W - XL, Dawn (Mörkblå)', 'Storlek: XL, Färg: Dawn (Mörkblå)', 'publish', 'closed', 'closed', '', 'core-essence-logo-tee-w-dawn-morkbla-xl', '', '', '2023-04-20 12:49:31', '2023-04-20 10:49:31', '', 70, 'http://localhost/WP-Mega/?post_type=product_variation&p=92', 15, 'product_variation', '', 0),
(93, 1, '2023-04-20 12:51:46', '2023-04-20 10:51:46', 'Har du svårt att hitta motivation för att träna. Köp detta material, så är du ute och springer innan du vet ordet av.', 'Träningsinspiration - DLC', 'Har du svårt att hitta motivation för att träna. Köp detta material, så är du ute och springer innan du vet ordet av.', 'publish', 'open', 'closed', '', 'traningsinspiration-dlc', '', '', '2023-04-20 14:40:23', '2023-04-20 12:40:23', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=93', 0, 'product', '', 0),
(94, 1, '2023-04-20 12:54:12', '2023-04-20 10:54:12', 'inspiration', 'inspiration', 'inspiration', 'inherit', 'open', 'closed', '', 'inspiration', '', '', '2023-04-20 12:54:18', '2023-04-20 10:54:18', '', 93, 'http://localhost/WP-Mega/wp-content/uploads/woocommerce_uploads/inspiration-xdxngb.pdf', 0, 'attachment', 'application/pdf', 0),
(95, 1, '2023-04-20 12:54:57', '2023-04-20 10:54:57', '', 'insp-dlc', '', 'inherit', 'open', 'closed', '', 'insp-dlc', '', '', '2023-04-20 12:54:57', '2023-04-20 10:54:57', '', 93, 'http://localhost/WP-Mega/wp-content/uploads/insp-dlc.png', 0, 'attachment', 'image/png', 0),
(96, 1, '2023-04-20 13:01:12', '2023-04-20 11:01:12', '', 'GeMigRabatt', '', 'publish', 'closed', 'closed', '', 'gemigrabatt', '', '', '2023-04-20 13:01:33', '2023-04-20 11:01:33', '', 0, 'http://localhost/WP-Mega/?post_type=shop_coupon&#038;p=96', 0, 'shop_coupon', '', 0),
(97, 1, '2023-04-20 13:08:38', '2023-04-20 11:08:38', '{"blocksy::single_page_hero_enabled":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 11:08:38"},"blocksy::single_page_structure":{"value":"type-4","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 11:08:38"}}', '', '', 'trash', 'closed', 'closed', '', '3ca27c8d-a435-417f-aa4a-9e424e45640d', '', '', '2023-04-20 13:08:38', '2023-04-20 11:08:38', '', 0, 'http://localhost/WP-Mega/2023/04/20/3ca27c8d-a435-417f-aa4a-9e424e45640d/', 0, 'customize_changeset', '', 0),
(98, 1, '2023-04-20 13:08:54', '2023-04-20 11:08:54', '{"blocksy::single_page_content_style":{"value":{"desktop":"boxed","tablet":"boxed","mobile":"boxed","__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 11:08:54"},"blocksy::single_page_content_area_spacing":{"value":"top","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-20 11:08:54"}}', '', '', 'trash', 'closed', 'closed', '', '31620352-49e1-44fd-88e4-ade3bf800178', '', '', '2023-04-20 13:08:54', '2023-04-20 11:08:54', '', 0, 'http://localhost/WP-Mega/2023/04/20/31620352-49e1-44fd-88e4-ade3bf800178/', 0, 'customize_changeset', '', 0),
(99, 1, '2023-04-20 14:33:16', '2023-04-20 12:33:16', '', 'Order &ndash; april 20, 2023 @ 02:33 e m', '', 'wc-completed', 'closed', 'closed', 'wc_order_pr4We7C8sBbDO', 'order-apr-20-2023-1233-pm', '', '', '2023-04-20 14:48:02', '2023-04-20 12:48:02', '', 0, 'http://localhost/WP-Mega/?post_type=shop_order&#038;p=99', 0, 'shop_order', '', 2),
(100, 1, '2023-04-20 14:36:35', '2023-04-20 12:36:35', '', 'Order &ndash; april 20, 2023 @ 02:36 e m', '', 'wc-completed', 'closed', 'closed', 'wc_order_QvdqqVJEO3AKJ', 'order-apr-20-2023-1236-pm', '', '', '2023-04-20 14:42:39', '2023-04-20 12:42:39', '', 0, 'http://localhost/WP-Mega/?post_type=shop_order&#038;p=100', 0, 'shop_order', '', 2),
(101, 1, '2023-04-21 08:25:59', '2023-04-21 06:25:59', 'Dextro Energy är ett druvsocker som höjer blodsockernivån i kroppen och ger ett snabbt tillskott av energi. 3-pack.', 'Druvsockertabletter', 'Dextro Energy är ett druvsocker som höjer blodsockernivån i kroppen och ger ett snabbt tillskott av energi. 3-pack.', 'publish', 'open', 'closed', '', 'druvsockertabletter', '', '', '2023-04-21 13:49:06', '2023-04-21 11:49:06', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=101', 0, 'product', '', 0),
(105, 1, '2023-04-21 08:30:37', '2023-04-21 06:30:37', '', 'Dextro Energy Lemon', '', 'publish', 'open', 'closed', '', 'dextro-energy-lemon', '', '', '2023-04-21 13:50:49', '2023-04-21 11:50:49', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=105', 0, 'product', '', 0),
(106, 1, '2023-04-21 08:33:05', '2023-04-21 06:33:05', '', 'Dextro Energy Cola', '', 'publish', 'open', 'closed', '', 'dextro-energy-cola', '', '', '2023-04-21 13:50:49', '2023-04-21 11:50:49', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=106', 0, 'product', '', 0),
(107, 1, '2023-04-21 08:33:54', '2023-04-21 06:33:54', '', 'AUTO-DRAFT', '', 'auto-draft', 'open', 'closed', '', '', '', '', '2023-04-21 08:33:54', '2023-04-21 06:33:54', '', 0, 'http://localhost/WP-Mega/?post_type=product&p=107', 0, 'product', '', 0),
(108, 1, '2023-04-21 08:34:27', '2023-04-21 06:34:27', '', 'Dextro Energy Classic', '', 'publish', 'open', 'closed', '', 'dextro-energy-classic', '', '', '2023-04-21 13:50:49', '2023-04-21 11:50:49', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=108', 0, 'product', '', 0),
(109, 1, '2023-04-21 08:41:13', '2023-04-21 06:41:13', '', 'Hypersport Bottle 20 Oz', 'BPA Free.600ml kapacitet. Lätt o fylla på pga av flaskans utformning. Flaskan har ett munstycke som gör att det räcker med att suga eller trycka för att få vatten. Klarar diskmaskin', 'publish', 'open', 'closed', '', 'hypersport-bottle-20-oz', '', '', '2023-04-21 13:24:06', '2023-04-21 11:24:06', '', 0, 'http://localhost/WP-Mega/?post_type=product&#038;p=109', 0, 'product', '', 0),
(110, 1, '2023-04-21 08:42:33', '2023-04-21 06:42:33', 'MegaShop_0005__Nike__H20', 'MegaShop_0005__Nike__H20', 'MegaShop_0005__Nike__H20', 'inherit', 'open', 'closed', '', 'megashop_0005__nike__h20', '', '', '2023-04-21 08:42:42', '2023-04-21 06:42:42', '', 109, 'http://localhost/WP-Mega/wp-content/uploads/MegaShop_0005__Nike__H20.jpg', 0, 'attachment', 'image/jpeg', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(111, 1, '2023-04-21 08:56:35', '2023-04-21 06:56:35', 'dextro-energy-classic', 'dextro-energy-classic', 'dextro-energy-classic', 'inherit', 'open', 'closed', '', 'dextro-energy-classic-sticks-3-pack-1', '', '', '2023-04-21 08:57:13', '2023-04-21 06:57:13', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/dextro-energy-classic-sticks-3-pack-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(112, 1, '2023-04-21 08:56:36', '2023-04-21 06:56:36', 'dextro-energy', 'dextro-energy', 'dextro-energy', 'inherit', 'open', 'closed', '', 'dextro-energy-cola-sticks-3-pack-0', '', '', '2023-04-21 08:59:03', '2023-04-21 06:59:03', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/dextro-energy-cola-sticks-3-pack-0.jpg', 0, 'attachment', 'image/jpeg', 0),
(113, 1, '2023-04-21 08:56:36', '2023-04-21 06:56:36', 'dextro-energy-lemon', 'dextro-energy-lemon', 'dextro-energy-lemon', 'inherit', 'open', 'closed', '', 'dextro-energy-lemon-sticks-3-pack-1', '', '', '2023-04-21 08:58:04', '2023-04-21 06:58:04', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/dextro-energy-lemon-sticks-3-pack-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(114, 1, '2023-04-21 09:04:41', '2023-04-21 07:04:41', '', 'Order &ndash; april 21, 2023 @ 09:04 f m', '', 'wc-completed', 'closed', 'closed', 'wc_order_xgdQ5oAyltfJM', 'order-apr-21-2023-0704-am', '', '', '2023-04-21 09:05:45', '2023-04-21 07:05:45', '', 0, 'http://localhost/WP-Mega/?post_type=shop_order&#038;p=114', 0, 'shop_order', '', 2),
(115, 1, '2023-04-21 11:08:58', '2023-04-21 09:08:58', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-blocksy-child', '', '', '2023-04-21 11:08:58', '2023-04-21 09:08:58', '', 0, 'http://localhost/WP-Mega/2023/04/21/wp-global-styles-blocksy-child/', 0, 'wp_global_styles', '', 0),
(116, 1, '2023-04-21 11:09:06', '2023-04-21 09:09:06', '<!-- wp:paragraph -->\n<p>sdfsafsdafa</p>\n<!-- /wp:paragraph -->', 'Shop', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2023-04-21 11:09:06', '2023-04-21 09:09:06', '', 6, 'http://localhost/WP-Mega/?p=116', 0, 'revision', '', 0),
(117, 1, '2023-04-21 11:12:23', '2023-04-21 09:12:23', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2023-04-21 11:12:23', '2023-04-21 09:12:23', '', 6, 'http://localhost/WP-Mega/?p=117', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(118, 1, '2023-04-21 11:13:42', '2023-04-21 09:13:42', '<!-- wp:paragraph -->\n<p>sadfs</p>\n<!-- /wp:paragraph -->', 'Shop', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2023-04-21 11:13:42', '2023-04-21 09:13:42', '', 6, 'http://localhost/WP-Mega/?p=118', 0, 'revision', '', 0),
(119, 1, '2023-04-21 11:13:52', '2023-04-21 09:13:52', '', 'Shop', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2023-04-21 11:13:52', '2023-04-21 09:13:52', '', 6, 'http://localhost/WP-Mega/?p=119', 0, 'revision', '', 0),
(123, 1, '2023-04-21 12:36:02', '2023-04-21 10:36:02', '', 'Påsk hos Mega Shop! 15% rabatt på alla gula produkter!', '', 'publish', 'closed', 'closed', '', 'pask-hos-mega-shop-15-rabatt-pa-alla-gula-produkter', '', '', '2023-04-21 12:36:24', '2023-04-21 10:36:24', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=123', 0, 'greet', '', 0),
(124, 1, '2023-04-21 12:42:16', '2023-04-21 10:42:16', '', 'hejhej', '', 'publish', 'closed', 'closed', '', 'hejhej', '', '', '2023-04-21 12:42:22', '2023-04-21 10:42:22', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=124', 0, 'greet', '', 0),
(125, 1, '2023-04-21 12:42:59', '2023-04-21 10:42:59', '', 'Ja, nu jävlar!', '', 'publish', 'closed', 'closed', '', 'ja-nu-javlar', '', '', '2023-04-21 12:43:05', '2023-04-21 10:43:05', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=125', 0, 'greet', '', 0),
(126, 1, '2023-04-21 12:44:17', '2023-04-21 10:44:17', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-21 12:44:17', '2023-04-21 10:44:17', '', 0, 'http://localhost/WP-Mega/?post_type=greet&p=126', 0, 'greet', '', 0),
(127, 1, '2023-04-21 12:51:01', '2023-04-21 10:51:01', '', 'Idag är det fredag!', '', 'publish', 'closed', 'closed', '', 'idag-ar-det-fredag', '', '', '2023-04-21 12:51:13', '2023-04-21 10:51:13', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=127', 0, 'greet', '', 0),
(128, 1, '2023-04-21 12:56:05', '2023-04-21 10:56:05', '', 'Automatiskt utkast', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2023-04-21 12:56:05', '2023-04-21 10:56:05', '', 0, 'http://localhost/WP-Mega/?post_type=greet&p=128', 0, 'greet', '', 0),
(129, 1, '2023-04-21 12:57:30', '2023-04-21 10:57:30', '', 'Denna veckan: 10% rabatt på Dextrosol', '', 'publish', 'closed', 'closed', '', 'denna-veckan-10-rabatt-pa-dextrosol', '', '', '2023-04-21 13:04:33', '2023-04-21 11:04:33', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=129', 0, 'greet', '', 0),
(130, 1, '2023-04-21 13:08:19', '2023-04-21 11:08:19', '{"blocksy-child::selectionColor":{"value":{"default":{"color":"#ffffff"},"hover":{"color":"#28befa"}},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:08:19"}}', '', '', 'trash', 'closed', 'closed', '', 'd5add534-7015-490c-aca8-4467608947b0', '', '', '2023-04-21 13:08:19', '2023-04-21 11:08:19', '', 0, 'http://localhost/WP-Mega/2023/04/21/d5add534-7015-490c-aca8-4467608947b0/', 0, 'customize_changeset', '', 0),
(131, 1, '2023-04-21 13:08:30', '2023-04-21 11:08:30', '{"blocksy-child::colorPalette":{"value":{"color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"},"current_palette":"palette-1","palettes":[{"id":"palette-2","color1":{"color":"#2872fa"},"color2":{"color":"#1559ed"},"color3":{"color":"#3A4F66"},"color4":{"color":"#192a3d"},"color5":{"color":"#e1e8ed"},"color6":{"color":"#f2f5f7"},"color7":{"color":"#FAFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-1","color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"}},{"id":"palette-3","color1":{"color":"#FB7258"},"color2":{"color":"#F74D67"},"color3":{"color":"#6e6d76"},"color4":{"color":"#0e0c1b"},"color5":{"color":"#DFDFE2"},"color6":{"color":"#F4F4F5"},"color7":{"color":"#FBFBFB"},"color8":{"color":"#ffffff"}},{"id":"palette-4","color1":{"color":"#98c1d9"},"color2":{"color":"#E84855"},"color3":{"color":"#475671"},"color4":{"color":"#293241"},"color5":{"color":"#E7E9EF"},"color6":{"color":"#f3f4f7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-5","color1":{"color":"#006466"},"color2":{"color":"#065A60"},"color3":{"color":"#7F8C9A"},"color4":{"color":"#ffffff"},"color5":{"color":"#1e2933"},"color6":{"color":"#0F141A"},"color7":{"color":"#141b22"},"color8":{"color":"#1B242C"}},{"id":"palette-6","color1":{"color":"#007f5f"},"color2":{"color":"#55a630"},"color3":{"color":"#365951"},"color4":{"color":"#192c27"},"color5":{"color":"#E6F0EE"},"color6":{"color":"#F2F7F6"},"color7":{"color":"#FBFCFC"},"color8":{"color":"#ffffff"}},{"id":"palette-7","color1":{"color":"#7456f1"},"color2":{"color":"#5e3fde"},"color3":{"color":"#4d5d6d"},"color4":{"color":"#102136"},"color5":{"color":"#E7EBEE"},"color6":{"color":"#F3F5F7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-8","color1":{"color":"#00509d"},"color2":{"color":"#003f88"},"color3":{"color":"#828487"},"color4":{"color":"#28292a"},"color5":{"color":"#e8ebed"},"color6":{"color":"#f4f5f6"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-9","color1":{"color":"#84a98c"},"color2":{"color":"#52796f"},"color3":{"color":"#cad2c5"},"color4":{"color":"#84a98c"},"color5":{"color":"#384b56"},"color6":{"color":"#212b31"},"color7":{"color":"#29363d"},"color8":{"color":"#314149"}},{"id":"palette-10","color1":{"color":"#ff6d00"},"color2":{"color":"#ff8500"},"color3":{"color":"#cfa9ef"},"color4":{"color":"#e3cbf6"},"color5":{"color":"#5a189a"},"color6":{"color":"#240046"},"color7":{"color":"#3c096c"},"color8":{"color":"#410a75"}},{"id":"palette-11","color1":{"color":"#ffcd05"},"color2":{"color":"#fcb424"},"color3":{"color":"#504e4a"},"color4":{"color":"#0a0500"},"color5":{"color":"#edeff2"},"color6":{"color":"#f9fafb"},"color7":{"color":"#FDFDFD"},"color8":{"color":"#ffffff"}},{"id":"palette-12","color1":{"color":"#a8977b"},"color2":{"color":"#7f715c"},"color3":{"color":"#3f4245"},"color4":{"color":"#111518"},"color5":{"color":"#eaeaec"},"color6":{"color":"#f4f4f5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-13","color1":{"color":"#48bca2"},"color2":{"color":"#25ad99"},"color3":{"color":"#4f4f4f"},"color4":{"color":"#0a0500"},"color5":{"color":"#EBEBEB"},"color6":{"color":"#F5F5F5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-14","color1":{"color":"#ff6310"},"color2":{"color":"#fd7c47"},"color3":{"color":"#687279"},"color4":{"color":"#111518"},"color5":{"color":"#E9EBEC"},"color6":{"color":"#F4F5F6"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-15","color1":{"color":"#fca311"},"color2":{"color":"#23396c"},"color3":{"color":"#707070"},"color4":{"color":"#000000"},"color5":{"color":"#e0e0e0"},"color6":{"color":"#f1f1f1"},"color7":{"color":"#fafafa"},"color8":{"color":"#ffffff"}}]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:08:30"}}', '', '', 'trash', 'closed', 'closed', '', 'c8424c16-9b8e-47c1-9a00-446341be4272', '', '', '2023-04-21 13:08:30', '2023-04-21 11:08:30', '', 0, 'http://localhost/WP-Mega/2023/04/21/c8424c16-9b8e-47c1-9a00-446341be4272/', 0, 'customize_changeset', '', 0),
(132, 1, '2023-04-21 13:10:23', '2023-04-21 11:10:23', '{"blocksy-child::colorPalette":{"value":{"color1":{"color":"#84a98c"},"color2":{"color":"#52796f"},"color3":{"color":"#cad2c5"},"color4":{"color":"#84a98c"},"color5":{"color":"#384b56"},"color6":{"color":"#212b31"},"color7":{"color":"#29363d"},"color8":{"color":"#314149"},"current_palette":"palette-9","palettes":[{"id":"palette-2","color1":{"color":"#2872fa"},"color2":{"color":"#1559ed"},"color3":{"color":"#3A4F66"},"color4":{"color":"#192a3d"},"color5":{"color":"#e1e8ed"},"color6":{"color":"#f2f5f7"},"color7":{"color":"#FAFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-1","color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"}},{"id":"palette-3","color1":{"color":"#FB7258"},"color2":{"color":"#F74D67"},"color3":{"color":"#6e6d76"},"color4":{"color":"#0e0c1b"},"color5":{"color":"#DFDFE2"},"color6":{"color":"#F4F4F5"},"color7":{"color":"#FBFBFB"},"color8":{"color":"#ffffff"}},{"id":"palette-4","color1":{"color":"#98c1d9"},"color2":{"color":"#E84855"},"color3":{"color":"#475671"},"color4":{"color":"#293241"},"color5":{"color":"#E7E9EF"},"color6":{"color":"#f3f4f7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-5","color1":{"color":"#006466"},"color2":{"color":"#065A60"},"color3":{"color":"#7F8C9A"},"color4":{"color":"#ffffff"},"color5":{"color":"#1e2933"},"color6":{"color":"#0F141A"},"color7":{"color":"#141b22"},"color8":{"color":"#1B242C"}},{"id":"palette-6","color1":{"color":"#007f5f"},"color2":{"color":"#55a630"},"color3":{"color":"#365951"},"color4":{"color":"#192c27"},"color5":{"color":"#E6F0EE"},"color6":{"color":"#F2F7F6"},"color7":{"color":"#FBFCFC"},"color8":{"color":"#ffffff"}},{"id":"palette-7","color1":{"color":"#7456f1"},"color2":{"color":"#5e3fde"},"color3":{"color":"#4d5d6d"},"color4":{"color":"#102136"},"color5":{"color":"#E7EBEE"},"color6":{"color":"#F3F5F7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-8","color1":{"color":"#00509d"},"color2":{"color":"#003f88"},"color3":{"color":"#828487"},"color4":{"color":"#28292a"},"color5":{"color":"#e8ebed"},"color6":{"color":"#f4f5f6"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-9","color1":{"color":"#84a98c"},"color2":{"color":"#52796f"},"color3":{"color":"#cad2c5"},"color4":{"color":"#84a98c"},"color5":{"color":"#384b56"},"color6":{"color":"#212b31"},"color7":{"color":"#29363d"},"color8":{"color":"#314149"}},{"id":"palette-10","color1":{"color":"#ff6d00"},"color2":{"color":"#ff8500"},"color3":{"color":"#cfa9ef"},"color4":{"color":"#e3cbf6"},"color5":{"color":"#5a189a"},"color6":{"color":"#240046"},"color7":{"color":"#3c096c"},"color8":{"color":"#410a75"}},{"id":"palette-11","color1":{"color":"#ffcd05"},"color2":{"color":"#fcb424"},"color3":{"color":"#504e4a"},"color4":{"color":"#0a0500"},"color5":{"color":"#edeff2"},"color6":{"color":"#f9fafb"},"color7":{"color":"#FDFDFD"},"color8":{"color":"#ffffff"}},{"id":"palette-12","color1":{"color":"#a8977b"},"color2":{"color":"#7f715c"},"color3":{"color":"#3f4245"},"color4":{"color":"#111518"},"color5":{"color":"#eaeaec"},"color6":{"color":"#f4f4f5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-13","color1":{"color":"#48bca2"},"color2":{"color":"#25ad99"},"color3":{"color":"#4f4f4f"},"color4":{"color":"#0a0500"},"color5":{"color":"#EBEBEB"},"color6":{"color":"#F5F5F5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-14","color1":{"color":"#ff6310"},"color2":{"color":"#fd7c47"},"color3":{"color":"#687279"},"color4":{"color":"#111518"},"color5":{"color":"#E9EBEC"},"color6":{"color":"#F4F5F6"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-15","color1":{"color":"#fca311"},"color2":{"color":"#23396c"},"color3":{"color":"#707070"},"color4":{"color":"#000000"},"color5":{"color":"#e0e0e0"},"color6":{"color":"#f1f1f1"},"color7":{"color":"#fafafa"},"color8":{"color":"#ffffff"}}]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:10:15"},"blocksy-child::border_color":{"value":{"default":{"color":"#ffffff"}},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:10:23"}}', '', '', 'trash', 'closed', 'closed', '', 'c83872f4-0d85-4eb9-afa5-83f73ad362d2', '', '', '2023-04-21 13:10:23', '2023-04-21 11:10:23', '', 0, 'http://localhost/WP-Mega/?p=132', 0, 'customize_changeset', '', 0),
(133, 1, '2023-04-21 13:12:15', '2023-04-21 11:12:15', '{"blocksy-child::site_background":{"value":{"desktop":{"background_type":"color","background_pattern":"type-1","background_image":{"attachment_id":null,"x":0,"y":0},"gradient":"linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%)","background_repeat":"repeat","background_size":"auto","background_attachment":"scroll","patternColor":{"default":{"color":"#e5e7ea"}},"overlayColor":{"default":{"color":"CT_CSS_SKIP_RULE"}},"backgroundColor":{"default":{"color":"#f2f2f2"}}},"tablet":{"background_type":"color","background_pattern":"type-1","background_image":{"attachment_id":null,"x":0,"y":0},"gradient":"linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%)","background_repeat":"repeat","background_size":"auto","background_attachment":"scroll","patternColor":{"default":{"color":"#e5e7ea"}},"overlayColor":{"default":{"color":"CT_CSS_SKIP_RULE"}},"backgroundColor":{"default":{"color":"#f2f2f2"}}},"mobile":{"background_type":"color","background_pattern":"type-1","background_image":{"attachment_id":null,"x":0,"y":0},"gradient":"linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%)","background_repeat":"repeat","background_size":"auto","background_attachment":"scroll","patternColor":{"default":{"color":"#e5e7ea"}},"overlayColor":{"default":{"color":"CT_CSS_SKIP_RULE"}},"backgroundColor":{"default":{"color":"#f2f2f2"}}},"__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:12:15"},"blocksy-child::colorPalette":{"value":{"color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"},"current_palette":"palette-1","palettes":[{"id":"palette-2","color1":{"color":"#2872fa"},"color2":{"color":"#1559ed"},"color3":{"color":"#3A4F66"},"color4":{"color":"#192a3d"},"color5":{"color":"#e1e8ed"},"color6":{"color":"#f2f5f7"},"color7":{"color":"#FAFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-1","color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"}},{"id":"palette-3","color1":{"color":"#FB7258"},"color2":{"color":"#F74D67"},"color3":{"color":"#6e6d76"},"color4":{"color":"#0e0c1b"},"color5":{"color":"#DFDFE2"},"color6":{"color":"#F4F4F5"},"color7":{"color":"#FBFBFB"},"color8":{"color":"#ffffff"}},{"id":"palette-4","color1":{"color":"#98c1d9"},"color2":{"color":"#E84855"},"color3":{"color":"#475671"},"color4":{"color":"#293241"},"color5":{"color":"#E7E9EF"},"color6":{"color":"#f3f4f7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-5","color1":{"color":"#006466"},"color2":{"color":"#065A60"},"color3":{"color":"#7F8C9A"},"color4":{"color":"#ffffff"},"color5":{"color":"#1e2933"},"color6":{"color":"#0F141A"},"color7":{"color":"#141b22"},"color8":{"color":"#1B242C"}},{"id":"palette-6","color1":{"color":"#007f5f"},"color2":{"color":"#55a630"},"color3":{"color":"#365951"},"color4":{"color":"#192c27"},"color5":{"color":"#E6F0EE"},"color6":{"color":"#F2F7F6"},"color7":{"color":"#FBFCFC"},"color8":{"color":"#ffffff"}},{"id":"palette-7","color1":{"color":"#7456f1"},"color2":{"color":"#5e3fde"},"color3":{"color":"#4d5d6d"},"color4":{"color":"#102136"},"color5":{"color":"#E7EBEE"},"color6":{"color":"#F3F5F7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-8","color1":{"color":"#00509d"},"color2":{"color":"#003f88"},"color3":{"color":"#828487"},"color4":{"color":"#28292a"},"color5":{"color":"#e8ebed"},"color6":{"color":"#f4f5f6"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-9","color1":{"color":"#84a98c"},"color2":{"color":"#52796f"},"color3":{"color":"#cad2c5"},"color4":{"color":"#84a98c"},"color5":{"color":"#384b56"},"color6":{"color":"#212b31"},"color7":{"color":"#29363d"},"color8":{"color":"#314149"}},{"id":"palette-10","color1":{"color":"#ff6d00"},"color2":{"color":"#ff8500"},"color3":{"color":"#cfa9ef"},"color4":{"color":"#e3cbf6"},"color5":{"color":"#5a189a"},"color6":{"color":"#240046"},"color7":{"color":"#3c096c"},"color8":{"color":"#410a75"}},{"id":"palette-11","color1":{"color":"#ffcd05"},"color2":{"color":"#fcb424"},"color3":{"color":"#504e4a"},"color4":{"color":"#0a0500"},"color5":{"color":"#edeff2"},"color6":{"color":"#f9fafb"},"color7":{"color":"#FDFDFD"},"color8":{"color":"#ffffff"}},{"id":"palette-12","color1":{"color":"#a8977b"},"color2":{"color":"#7f715c"},"color3":{"color":"#3f4245"},"color4":{"color":"#111518"},"color5":{"color":"#eaeaec"},"color6":{"color":"#f4f4f5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-13","color1":{"color":"#48bca2"},"color2":{"color":"#25ad99"},"color3":{"color":"#4f4f4f"},"color4":{"color":"#0a0500"},"color5":{"color":"#EBEBEB"},"color6":{"color":"#F5F5F5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-14","color1":{"color":"#ff6310"},"color2":{"color":"#fd7c47"},"color3":{"color":"#687279"},"color4":{"color":"#111518"},"color5":{"color":"#E9EBEC"},"color6":{"color":"#F4F5F6"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-15","color1":{"color":"#fca311"},"color2":{"color":"#23396c"},"color3":{"color":"#707070"},"color4":{"color":"#000000"},"color5":{"color":"#e0e0e0"},"color6":{"color":"#f1f1f1"},"color7":{"color":"#fafafa"},"color8":{"color":"#ffffff"}}]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:12:15"}}', '', '', 'auto-draft', 'closed', 'closed', '', '5be2e141-85a9-43e5-826a-06ba38fe967b', '', '', '2023-04-21 13:12:15', '2023-04-21 11:12:15', '', 0, 'http://localhost/WP-Mega/?p=133', 0, 'customize_changeset', '', 0),
(134, 1, '2023-04-21 13:13:09', '2023-04-21 11:13:09', '{"blocksy-child::colorPalette":{"value":{"color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"},"current_palette":"palette-1","palettes":[{"id":"palette-2","color1":{"color":"#2872fa"},"color2":{"color":"#1559ed"},"color3":{"color":"#3A4F66"},"color4":{"color":"#192a3d"},"color5":{"color":"#e1e8ed"},"color6":{"color":"#f2f5f7"},"color7":{"color":"#FAFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-1","color1":{"color":"#3eaf7c"},"color2":{"color":"#33a370"},"color3":{"color":"#415161"},"color4":{"color":"#2c3e50"},"color5":{"color":"#E2E7ED"},"color6":{"color":"#edeff2"},"color7":{"color":"#f8f9fb"},"color8":{"color":"#ffffff"}},{"id":"palette-3","color1":{"color":"#FB7258"},"color2":{"color":"#F74D67"},"color3":{"color":"#6e6d76"},"color4":{"color":"#0e0c1b"},"color5":{"color":"#DFDFE2"},"color6":{"color":"#F4F4F5"},"color7":{"color":"#FBFBFB"},"color8":{"color":"#ffffff"}},{"id":"palette-4","color1":{"color":"#98c1d9"},"color2":{"color":"#E84855"},"color3":{"color":"#475671"},"color4":{"color":"#293241"},"color5":{"color":"#E7E9EF"},"color6":{"color":"#f3f4f7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-5","color1":{"color":"#006466"},"color2":{"color":"#065A60"},"color3":{"color":"#7F8C9A"},"color4":{"color":"#ffffff"},"color5":{"color":"#1e2933"},"color6":{"color":"#0F141A"},"color7":{"color":"#141b22"},"color8":{"color":"#1B242C"}},{"id":"palette-6","color1":{"color":"#007f5f"},"color2":{"color":"#55a630"},"color3":{"color":"#365951"},"color4":{"color":"#192c27"},"color5":{"color":"#E6F0EE"},"color6":{"color":"#F2F7F6"},"color7":{"color":"#FBFCFC"},"color8":{"color":"#ffffff"}},{"id":"palette-7","color1":{"color":"#7456f1"},"color2":{"color":"#5e3fde"},"color3":{"color":"#4d5d6d"},"color4":{"color":"#102136"},"color5":{"color":"#E7EBEE"},"color6":{"color":"#F3F5F7"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-8","color1":{"color":"#00509d"},"color2":{"color":"#003f88"},"color3":{"color":"#828487"},"color4":{"color":"#28292a"},"color5":{"color":"#e8ebed"},"color6":{"color":"#f4f5f6"},"color7":{"color":"#FBFBFC"},"color8":{"color":"#ffffff"}},{"id":"palette-9","color1":{"color":"#84a98c"},"color2":{"color":"#52796f"},"color3":{"color":"#cad2c5"},"color4":{"color":"#84a98c"},"color5":{"color":"#384b56"},"color6":{"color":"#212b31"},"color7":{"color":"#29363d"},"color8":{"color":"#314149"}},{"id":"palette-10","color1":{"color":"#ff6d00"},"color2":{"color":"#ff8500"},"color3":{"color":"#cfa9ef"},"color4":{"color":"#e3cbf6"},"color5":{"color":"#5a189a"},"color6":{"color":"#240046"},"color7":{"color":"#3c096c"},"color8":{"color":"#410a75"}},{"id":"palette-11","color1":{"color":"#ffcd05"},"color2":{"color":"#fcb424"},"color3":{"color":"#504e4a"},"color4":{"color":"#0a0500"},"color5":{"color":"#edeff2"},"color6":{"color":"#f9fafb"},"color7":{"color":"#FDFDFD"},"color8":{"color":"#ffffff"}},{"id":"palette-12","color1":{"color":"#a8977b"},"color2":{"color":"#7f715c"},"color3":{"color":"#3f4245"},"color4":{"color":"#111518"},"color5":{"color":"#eaeaec"},"color6":{"color":"#f4f4f5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-13","color1":{"color":"#48bca2"},"color2":{"color":"#25ad99"},"color3":{"color":"#4f4f4f"},"color4":{"color":"#0a0500"},"color5":{"color":"#EBEBEB"},"color6":{"color":"#F5F5F5"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-14","color1":{"color":"#ff6310"},"color2":{"color":"#fd7c47"},"color3":{"color":"#687279"},"color4":{"color":"#111518"},"color5":{"color":"#E9EBEC"},"color6":{"color":"#F4F5F6"},"color7":{"color":"#ffffff"},"color8":{"color":"#ffffff"}},{"id":"palette-15","color1":{"color":"#fca311"},"color2":{"color":"#23396c"},"color3":{"color":"#707070"},"color4":{"color":"#000000"},"color5":{"color":"#e0e0e0"},"color6":{"color":"#f1f1f1"},"color7":{"color":"#fafafa"},"color8":{"color":"#ffffff"}}]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:13:09"},"blocksy-child::border_color":{"value":{"default":{"color":"#d10a0a"}},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:13:09"}}', '', '', 'trash', 'closed', 'closed', '', 'fdc91860-e7e0-400f-8430-16667572f212', '', '', '2023-04-21 13:13:09', '2023-04-21 11:13:09', '', 0, 'http://localhost/WP-Mega/2023/04/21/fdc91860-e7e0-400f-8430-16667572f212/', 0, 'customize_changeset', '', 0),
(135, 1, '2023-04-21 13:13:28', '2023-04-21 11:13:28', '{"blocksy-child::border_color":{"value":{"default":{"color":"#7a7a7a"}},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:13:28"}}', '', '', 'trash', 'closed', 'closed', '', 'f49701fa-d108-4a58-ad33-5b90873b3f09', '', '', '2023-04-21 13:13:28', '2023-04-21 11:13:28', '', 0, 'http://localhost/WP-Mega/2023/04/21/f49701fa-d108-4a58-ad33-5b90873b3f09/', 0, 'customize_changeset', '', 0),
(136, 1, '2023-04-21 13:14:25', '2023-04-21 11:14:25', '{"blocksy-child::blog_structure":{"value":"simple","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:14:25"}}', '', '', 'trash', 'closed', 'closed', '', 'dd4ce6b7-d3a8-45c1-9b65-55343e86f2c2', '', '', '2023-04-21 13:14:25', '2023-04-21 11:14:25', '', 0, 'http://localhost/WP-Mega/2023/04/21/dd4ce6b7-d3a8-45c1-9b65-55343e86f2c2/', 0, 'customize_changeset', '', 0),
(137, 1, '2023-04-21 13:14:32', '2023-04-21 11:14:32', '{"blocksy-child::blog_structure":{"value":"grid","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:14:32"}}', '', '', 'trash', 'closed', 'closed', '', 'e67d924a-c1ca-4dd5-b2aa-c6222c330ff1', '', '', '2023-04-21 13:14:32', '2023-04-21 11:14:32', '', 0, 'http://localhost/WP-Mega/2023/04/21/e67d924a-c1ca-4dd5-b2aa-c6222c330ff1/', 0, 'customize_changeset', '', 0),
(138, 1, '2023-04-21 13:14:45', '2023-04-21 11:14:45', '{"blocksy-child::single_page_structure":{"value":"type-3","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:14:45"}}', '', '', 'trash', 'closed', 'closed', '', '4aaea4d1-a853-4062-96b3-c4f7d78e93a6', '', '', '2023-04-21 13:14:45', '2023-04-21 11:14:45', '', 0, 'http://localhost/WP-Mega/2023/04/21/4aaea4d1-a853-4062-96b3-c4f7d78e93a6/', 0, 'customize_changeset', '', 0),
(139, 1, '2023-04-21 13:14:51', '2023-04-21 11:14:51', '{"blocksy-child::single_page_structure":{"value":"type-4","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:14:51"}}', '', '', 'trash', 'closed', 'closed', '', 'b4d696a5-c99b-4cd8-8fa5-320cf7b20044', '', '', '2023-04-21 13:14:51', '2023-04-21 11:14:51', '', 0, 'http://localhost/WP-Mega/2023/04/21/b4d696a5-c99b-4cd8-8fa5-320cf7b20044/', 0, 'customize_changeset', '', 0),
(140, 1, '2023-04-21 13:14:56', '2023-04-21 11:14:56', '{"blocksy-child::single_page_content_style":{"value":{"desktop":"boxed","tablet":"boxed","mobile":"boxed","__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:14:56"}}', '', '', 'trash', 'closed', 'closed', '', 'e02405a6-7cd2-4bb7-b84e-6517ebc0a02b', '', '', '2023-04-21 13:14:56', '2023-04-21 11:14:56', '', 0, 'http://localhost/WP-Mega/2023/04/21/e02405a6-7cd2-4bb7-b84e-6517ebc0a02b/', 0, 'customize_changeset', '', 0),
(141, 1, '2023-04-21 13:16:39', '2023-04-21 11:16:39', '{"blocksy-child::shop_cards_type":{"value":"type-1","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:15:23"},"blocksy-child::product_image_hover":{"value":"zoom-in","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:16:23"},"blocksy-child::has_product_categories":{"value":"no","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:16:39"}}', '', '', 'trash', 'closed', 'closed', '', 'c9c5a93b-254a-4c56-a372-d87cfda60ef7', '', '', '2023-04-21 13:16:39', '2023-04-21 11:16:39', '', 0, 'http://localhost/WP-Mega/?p=141', 0, 'customize_changeset', '', 0),
(142, 1, '2023-04-21 13:17:56', '2023-04-21 11:17:56', '{"woocommerce_shop_page_display":{"value":"","type":"option","user_id":1,"date_modified_gmt":"2023-04-21 11:17:56"}}', '', '', 'trash', 'closed', 'closed', '', 'bedd9528-98c1-4892-be09-9551b1f4d73d', '', '', '2023-04-21 13:17:56', '2023-04-21 11:17:56', '', 0, 'http://localhost/WP-Mega/2023/04/21/bedd9528-98c1-4892-be09-9551b1f4d73d/', 0, 'customize_changeset', '', 0),
(143, 1, '2023-04-21 13:21:08', '2023-04-21 11:21:08', '{"blocksy-child::cardProductRadius":{"value":{"desktop":{"top":"5px","bottom":"5px","left":"5px","right":"5px","linked":true},"tablet":{"top":"5px","bottom":"5px","left":"5px","right":"5px","linked":true},"mobile":{"top":"5px","bottom":"5px","left":"5px","right":"5px","linked":true},"__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:21:08"},"blocksy-child::woo_categories_has_sidebar":{"value":"no","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:19:24"}}', '', '', 'trash', 'closed', 'closed', '', 'aafa2bbc-d47c-434a-96ff-d64a88228f9b', '', '', '2023-04-21 13:21:08', '2023-04-21 11:21:08', '', 0, 'http://localhost/WP-Mega/?p=143', 0, 'customize_changeset', '', 0),
(144, 1, '2023-04-21 13:22:32', '2023-04-21 11:22:32', '{"blocksy-child::has_ajax_add_to_cart":{"value":"yes","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:22:32"}}', '', '', 'trash', 'closed', 'closed', '', '27b9b181-2699-4200-b031-03d34fa2516c', '', '', '2023-04-21 13:22:32', '2023-04-21 11:22:32', '', 0, 'http://localhost/WP-Mega/?p=144', 0, 'customize_changeset', '', 0),
(145, 1, '2023-04-21 13:23:12', '2023-04-21 11:23:12', '{"blocksy-child::has_ajax_add_to_cart":{"value":"no","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:23:12"}}', '', '', 'trash', 'closed', 'closed', '', '49ddc223-581e-4993-8f94-62daa2fbb5c9', '', '', '2023-04-21 13:23:12', '2023-04-21 11:23:12', '', 0, 'http://localhost/WP-Mega/2023/04/21/49ddc223-581e-4993-8f94-62daa2fbb5c9/', 0, 'customize_changeset', '', 0),
(146, 1, '2023-04-21 13:26:47', '2023-04-21 11:26:47', '{"blocksy-child::woo_categories_hero_section":{"value":"type-1","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:26:29"},"blocksy-child::woo_categories_hero_alignment2":{"value":{"desktop":"center","tablet":"center","mobile":"center","__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:26:29"},"blocksy-child::woo_categories_hero_vertical_alignment":{"value":{"desktop":"center","tablet":"center","mobile":"center","__changed":[]},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:26:29"},"blocksy-child::woo_categories_hero_structure":{"value":"narrow","type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:26:29"}}', '', '', 'trash', 'closed', 'closed', '', '0c806b3a-efe7-4864-8783-7b63930eefd5', '', '', '2023-04-21 13:26:47', '2023-04-21 11:26:47', '', 0, 'http://localhost/WP-Mega/?p=146', 0, 'customize_changeset', '', 0),
(147, 1, '2023-04-21 13:30:49', '2023-04-21 11:30:49', 'logo', 'logo', 'logo', 'inherit', 'open', 'closed', '', 'logo', '', '', '2023-04-21 13:30:56', '2023-04-21 11:30:56', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/logo.png', 0, 'attachment', 'image/png', 0),
(148, 1, '2023-04-21 13:31:19', '2023-04-21 11:31:19', '{"blocksy-child::custom_logo":{"value":147,"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:31:19"},"blocksy-child::header_placements":{"value":{"current_section":"type-1","sections":[{"id":"type-1","mode":"placements","items":[{"id":"logo","values":{"custom_logo":{"desktop":147,"tablet":147,"mobile":147,"__changed":[]},"has_site_title":"no","logoMaxHeight":{"desktop":"102","tablet":"102","mobile":"102","__changed":[]}}}],"settings":[],"desktop":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["menu","search"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":[]}]}],"mobile":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["trigger"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":["mobile-menu"]}]}]}],"__forced_static_header__":"type-1","__should_refresh__":false,"__should_refresh_item__":"logo:logoMaxHeight"},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:31:19"}}', '', '', 'trash', 'closed', 'closed', '', '7aac5841-68db-420b-aeb8-d11ba9b687e9', '', '', '2023-04-21 13:31:19', '2023-04-21 11:31:19', '', 0, 'http://localhost/WP-Mega/2023/04/21/7aac5841-68db-420b-aeb8-d11ba9b687e9/', 0, 'customize_changeset', '', 0),
(149, 1, '2023-04-21 13:31:48', '2023-04-21 11:31:48', '{"blocksy-child::header_placements":{"value":{"current_section":"type-1","sections":[{"id":"type-1","mode":"placements","items":[{"id":"logo","values":{"custom_logo":{"desktop":147,"tablet":147,"mobile":147,"__changed":[]},"has_site_title":"no","logoMaxHeight":{"desktop":"60","tablet":"60","mobile":"60","__changed":[]}}}],"settings":[],"desktop":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["menu","search"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":[]}]}],"mobile":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["trigger"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":["mobile-menu"]}]}]}],"__forced_static_header__":"type-1","__should_refresh__":false,"__should_refresh_item__":"logo:logoMaxHeight"},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:31:48"}}', '', '', 'trash', 'closed', 'closed', '', '062b2fcb-22ca-4677-ac52-9640f5ab481b', '', '', '2023-04-21 13:31:48', '2023-04-21 11:31:48', '', 0, 'http://localhost/WP-Mega/?p=149', 0, 'customize_changeset', '', 0),
(150, 1, '2023-04-21 13:32:52', '2023-04-21 11:32:52', '', 'logo2', '', 'inherit', 'open', 'closed', '', 'logo2', '', '', '2023-04-21 13:32:52', '2023-04-21 11:32:52', '', 0, 'http://localhost/WP-Mega/wp-content/uploads/logo2.png', 0, 'attachment', 'image/png', 0),
(151, 1, '2023-04-21 13:32:58', '2023-04-21 11:32:58', '{"blocksy-child::custom_logo":{"value":150,"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:32:58"},"blocksy-child::header_placements":{"value":{"current_section":"type-1","sections":[{"id":"type-1","mode":"placements","items":[{"id":"logo","values":{"custom_logo":{"0":150,"1":150,"2":150,"desktop":150,"tablet":150,"mobile":150,"__changed":[]},"has_site_title":"no","logoMaxHeight":{"desktop":"60","tablet":"60","mobile":"60","__changed":[]}}}],"settings":[],"desktop":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["menu","search"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":[]}]}],"mobile":[{"id":"top-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"middle-row","placements":[{"id":"start","items":["logo"]},{"id":"middle","items":[]},{"id":"end","items":["trigger"]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"bottom-row","placements":[{"id":"start","items":[]},{"id":"middle","items":[]},{"id":"end","items":[]},{"id":"start-middle","items":[]},{"id":"end-middle","items":[]}]},{"id":"offcanvas","placements":[{"id":"start","items":["mobile-menu"]}]}]}],"__should_refresh__":false,"__should_refresh_item__":"logo:custom_logo","__forced_static_header__":"type-1"},"type":"theme_mod","user_id":1,"date_modified_gmt":"2023-04-21 11:32:58"}}', '', '', 'trash', 'closed', 'closed', '', '1760184a-5294-4dee-a05b-52f760fa1399', '', '', '2023-04-21 13:32:58', '2023-04-21 11:32:58', '', 0, 'http://localhost/WP-Mega/2023/04/21/1760184a-5294-4dee-a05b-52f760fa1399/', 0, 'customize_changeset', '', 0),
(152, 1, '2023-04-21 13:51:02', '2023-04-21 11:51:02', '', 'Trevlig helg!', '', 'publish', 'closed', 'closed', '', 'trevlig-helg', '', '', '2023-04-21 13:51:12', '2023-04-21 11:51:12', '', 0, 'http://localhost/WP-Mega/?post_type=greet&#038;p=152', 0, 'greet', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(13, 4, 0),
(13, 16, 0),
(13, 17, 0),
(13, 18, 0),
(44, 2, 0),
(44, 15, 0),
(46, 4, 0),
(46, 17, 0),
(46, 19, 0),
(53, 4, 0),
(53, 17, 0),
(53, 19, 0),
(59, 4, 0),
(59, 16, 0),
(59, 17, 0),
(59, 20, 0),
(69, 21, 0),
(70, 4, 0),
(70, 22, 0),
(70, 23, 0),
(70, 24, 0),
(93, 2, 0),
(93, 24, 0),
(101, 3, 0),
(101, 24, 0),
(101, 26, 0),
(101, 27, 0),
(101, 28, 0),
(105, 2, 0),
(105, 6, 0),
(105, 7, 0),
(105, 24, 0),
(105, 26, 0),
(105, 27, 0),
(105, 28, 0),
(105, 29, 0),
(106, 2, 0),
(106, 6, 0),
(106, 7, 0),
(106, 24, 0),
(106, 26, 0),
(106, 27, 0),
(106, 28, 0),
(108, 2, 0),
(108, 6, 0),
(108, 7, 0),
(108, 24, 0),
(108, 26, 0),
(108, 27, 0),
(108, 28, 0),
(109, 2, 0),
(109, 24, 0),
(109, 29, 0),
(109, 30, 0),
(109, 31, 0),
(109, 32, 0),
(115, 33, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'product_type', '', 0, 5),
(3, 3, 'product_type', '', 0, 1),
(4, 4, 'product_type', '', 0, 3),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'product_visibility', '', 0, 3),
(7, 7, 'product_visibility', '', 0, 3),
(8, 8, 'product_visibility', '', 0, 0),
(9, 9, 'product_visibility', '', 0, 0),
(10, 10, 'product_visibility', '', 0, 0),
(11, 11, 'product_visibility', '', 0, 0),
(12, 12, 'product_visibility', '', 0, 0),
(13, 13, 'product_visibility', '', 0, 0),
(14, 14, 'product_visibility', '', 0, 0),
(15, 15, 'product_cat', '', 0, 0),
(16, 16, 'product_cat', '', 0, 1),
(17, 17, 'product_cat', '', 0, 2),
(18, 18, 'product_tag', '', 0, 0),
(19, 19, 'product_tag', '', 0, 1),
(20, 20, 'product_tag', '', 0, 1),
(21, 21, 'wp_theme', '', 0, 1),
(22, 22, 'product_cat', '', 0, 1),
(23, 23, 'product_tag', '', 0, 1),
(24, 24, 'product_cat', '', 0, 7),
(25, 25, 'product_shipping_class', '', 0, 0),
(26, 26, 'product_cat', '', 0, 4),
(27, 27, 'product_tag', '', 0, 4),
(28, 28, 'product_tag', '', 0, 4),
(29, 29, 'product_cat', '', 0, 2),
(30, 30, 'product_tag', '', 0, 1),
(31, 31, 'product_tag', '', 0, 1),
(32, 32, 'product_tag', '', 0, 1),
(33, 33, 'wp_theme', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#
INSERT INTO `wp_termmeta` ( `meta_id`, `term_id`, `meta_key`, `meta_value`) VALUES
(1, 15, 'product_count_product_cat', '0'),
(2, 16, 'order', '0'),
(3, 17, 'order', '0'),
(4, 17, 'product_count_product_cat', '2'),
(5, 16, 'product_count_product_cat', '1'),
(6, 18, 'product_count_product_tag', '0'),
(7, 19, 'product_count_product_tag', '1'),
(8, 20, 'product_count_product_tag', '1'),
(9, 22, 'order', '0'),
(10, 22, 'product_count_product_cat', '1'),
(11, 23, 'product_count_product_tag', '1'),
(12, 24, 'order', '0'),
(13, 24, 'product_count_product_cat', '4'),
(14, 26, 'order', '0'),
(15, 26, 'product_count_product_cat', '1'),
(16, 27, 'product_count_product_tag', '1'),
(17, 28, 'product_count_product_tag', '1'),
(18, 29, 'order', '0'),
(19, 29, 'product_count_product_cat', '1'),
(20, 30, 'product_count_product_tag', '1'),
(21, 31, 'product_count_product_tag', '1'),
(22, 32, 'product_count_product_tag', '1') ;

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Okategoriserade', 'okategoriserade', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'exclude-from-search', 'exclude-from-search', 0),
(7, 'exclude-from-catalog', 'exclude-from-catalog', 0),
(8, 'featured', 'featured', 0),
(9, 'outofstock', 'outofstock', 0),
(10, 'rated-1', 'rated-1', 0),
(11, 'rated-2', 'rated-2', 0),
(12, 'rated-3', 'rated-3', 0),
(13, 'rated-4', 'rated-4', 0),
(14, 'rated-5', 'rated-5', 0),
(15, 'Uncategorized', 'uncategorized', 0),
(16, 'Tights', 'tights', 0),
(17, 'Löpning', 'lopning', 0),
(18, 'ICANIWILL', 'icaniwill', 0),
(19, 'Laila W', 'laila-w', 0),
(20, 'Asics', 'asics', 0),
(21, 'blocksy', 'blocksy', 0),
(22, 'T-Shirt', 't-shirt', 0),
(23, 'Craft', 'craft', 0),
(24, 'Träning', 'traning', 0),
(25, 'Ömtåligt', 'omtaligt', 0),
(26, 'Kosttillskott', 'kosttillskott', 0),
(27, 'Dextro Energy', 'dextro-energy', 0),
(28, 'Kosttillskott', 'kosttillskott', 0),
(29, 'Tillbehör', 'tillbehor', 0),
(30, 'Nike', 'nike', 0),
(31, 'Bottle', 'bottle', 0),
(32, 'Vattenflaska', 'vattenflaska', 0),
(33, 'blocksy-child', 'blocksy-child', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'medie-admin'),
(2, 1, 'first_name', 'Martin'),
(3, 1, 'last_name', 'Johansson'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:2:{s:64:"6c9ca6da45655dfa850982f4ed92f4c071bb4e5372f3e3c8ac9a96ccd9cd51d8";a:4:{s:10:"expiration";i:1682156498;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1681983698;}s:64:"f1524dc3dbab96d33c7d9cd575e9ba43aaecaf604985a918e34afce9b442fe63";a:4:{s:10:"expiration";i:1682231139;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36";s:5:"login";i:1682058339;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'closedpostboxes_dashboard', 'a:5:{i:0;s:21:"dashboard_site_health";i:1;s:19:"dashboard_right_now";i:2;s:18:"dashboard_activity";i:3;s:21:"dashboard_quick_press";i:4;s:17:"dashboard_primary";}'),
(19, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(20, 1, '_woocommerce_tracks_anon_id', 'woo:v93fwTmFK9OGKWC2nU79jzN0'),
(21, 1, 'wc_last_active', '1682035200'),
(22, 1, 'meta-box-order_product', 'a:3:{s:4:"side";s:84:"submitdiv,postimagediv,woocommerce-product-images,product_catdiv,tagsdiv-product_tag";s:6:"normal";s:55:"woocommerce-product-data,postcustom,slugdiv,postexcerpt";s:8:"advanced";s:0:"";}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1681985247'),
(26, 1, 'last_update', '1682060681'),
(27, 1, 'woocommerce_admin_task_list_tracked_started_tasks', '{"tax":2}'),
(28, 1, 'woocommerce_admin_help_panel_highlight_shown', '"yes"'),
(29, 1, 'billing_first_name', 'Martin'),
(30, 1, 'billing_last_name', 'Johansson'),
(31, 1, 'billing_address_1', 'Askvägen 7 lgh 1102'),
(32, 1, 'billing_city', 'Romelanda'),
(33, 1, 'billing_postcode', '44277'),
(34, 1, 'billing_country', 'SE'),
(35, 1, 'billing_email', 'mjohansson176@gmail.com'),
(36, 1, 'billing_phone', '0761889887'),
(37, 1, 'shipping_method', ''),
(39, 1, 'woocommerce_admin_homepage_stats', '{"installJetpackDismissed":true}'),
(40, 1, 'paying_customer', '1'),
(43, 1, 'closedpostboxes_product', 'a:0:{}'),
(44, 1, 'metaboxhidden_product', 'a:2:{i:1;s:10:"postcustom";i:2;s:7:"slugdiv";}'),
(45, 1, '_woocommerce_persistent_cart_1', 'a:1:{s:4:"cart";a:3:{s:32:"f0935e4cd5920aa6c7c996a5ee53a70f";a:11:{s:3:"key";s:32:"f0935e4cd5920aa6c7c996a5ee53a70f";s:10:"product_id";i:106;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}s:5:"total";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}}s:13:"line_subtotal";d:57.60000000000000142108547152020037174224853515625;s:17:"line_subtotal_tax";d:14;s:10:"line_total";d:57.60000000000000142108547152020037174224853515625;s:8:"line_tax";d:14;}s:32:"5ccf25552359d5cde3288696eba65bd5";a:11:{s:3:"key";s:32:"5ccf25552359d5cde3288696eba65bd5";s:10:"product_id";i:70;s:12:"variation_id";i:78;s:9:"variation";a:2:{s:17:"attribute_storlek";s:2:"XS";s:14:"attribute_farg";s:5:"Svart";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"a404624d03e6fc9c5f20d84c6e18543d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:39.7999999999999971578290569595992565155029296875;}s:5:"total";a:1:{i:1;d:39.7999999999999971578290569595992565155029296875;}}s:13:"line_subtotal";d:159.19999999999998863131622783839702606201171875;s:17:"line_subtotal_tax";d:40;s:10:"line_total";d:159.19999999999998863131622783839702606201171875;s:8:"line_tax";d:40;}s:32:"2723d092b63885e0d7c260cc007e8b9d";a:6:{s:3:"key";s:32:"2723d092b63885e0d7c260cc007e8b9d";s:10:"product_id";i:109;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";}}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'medie-admin', '$P$BFZ3ms6kU59PBrvtmjk4ambgDa9col.', 'medie-admin', 'henrikutbildare@gmail.com', 'http://localhost/WP-Mega', '2023-04-20 09:41:33', '', 0, 'medie-admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_note_actions`
#

DROP TABLE IF EXISTS `wp_wc_admin_note_actions`;


#
# Table structure of table `wp_wc_admin_note_actions`
#

CREATE TABLE `wp_wc_admin_note_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `note_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `label` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `query` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `actioned_text` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonce_action` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `nonce_name` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `note_id` (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=362 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_note_actions`
#
INSERT INTO `wp_wc_admin_note_actions` ( `action_id`, `note_id`, `name`, `label`, `query`, `status`, `actioned_text`, `nonce_action`, `nonce_name`) VALUES
(25, 22, 'notify-refund-returns-page', 'Edit page', 'http://localhost/WP-Mega/wp-admin/post.php?post=10&action=edit', 'actioned', '', NULL, NULL),
(61, 51, 'connect', 'Connect', '?page=wc-addons&section=helper', 'unactioned', '', NULL, NULL),
(121, 52, 'customize-store-with-storefront', 'Let\'s go!', 'http://localhost/WP-Mega/wp-admin/themes.php?page=storefront-welcome', 'actioned', '', NULL, NULL),
(122, 53, 'remove-legacy-coupon-menu', 'Remove legacy coupon menu', 'http://localhost/WP-Mega/wp-admin/admin.php?page=wc-admin&action=remove-coupon-menu', 'actioned', '', NULL, NULL),
(123, 54, 'learn-more', 'Learn more', 'https://woocommerce.com/document/managing-orders/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(183, 55, 'visit-the-theme-marketplace', 'Visit the theme marketplace', 'https://woocommerce.com/product-category/themes/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(184, 56, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/pre-launch-checklist-the-essentials/?utm_source=inbox&utm_medium=product', 'actioned', '', NULL, NULL),
(303, 1, 'browse_extensions', 'Browse extensions', 'http://localhost/WP-Mega/wp-admin/admin.php?page=wc-addons', 'unactioned', '', NULL, NULL),
(304, 2, 'wayflyer_bnpl_q4_2021', 'Level up with funding', 'https://woocommerce.com/products/wayflyer/?utm_source=inbox_note&utm_medium=product&utm_campaign=wayflyer_bnpl_q4_2021', 'actioned', '', NULL, NULL),
(305, 3, 'wc_shipping_mobile_app_usps_q4_2021', 'Get WooCommerce Shipping', 'https://woocommerce.com/woocommerce-shipping/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc_shipping_mobile_app_usps_q4_2021', 'actioned', '', NULL, NULL),
(306, 4, 'learn-more', 'Learn more', 'https://docs.woocommerce.com/document/woocommerce-shipping-and-tax/?utm_source=inbox', 'unactioned', '', NULL, NULL),
(307, 5, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/ecommerce-shipping-solutions-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'actioned', '', NULL, NULL),
(308, 6, 'optimizing-the-checkout-flow', 'Learn more', 'https://woocommerce.com/posts/optimizing-woocommerce-checkout?utm_source=inbox_note&utm_medium=product&utm_campaign=optimizing-the-checkout-flow', 'actioned', '', NULL, NULL),
(309, 7, 'qualitative-feedback-from-new-users', 'Share feedback', 'https://automattic.survey.fm/wc-pay-new', 'actioned', '', NULL, NULL),
(310, 8, 'share-feedback', 'Share feedback', 'http://automattic.survey.fm/paypal-feedback', 'unactioned', '', NULL, NULL),
(311, 9, 'get-started', 'Get started', 'https://woocommerce.com/products/google-listings-and-ads?utm_source=inbox_note&utm_medium=product&utm_campaign=get-started', 'actioned', '', NULL, NULL),
(312, 10, 'update-wc-subscriptions-3-0-15', 'View latest version', 'http://localhost/WP-Mega/wp-admin/&page=wc-addons&section=helper', 'actioned', '', NULL, NULL),
(313, 11, 'update-wc-core-5-4-0', 'How to update WooCommerce', 'https://docs.woocommerce.com/document/how-to-update-woocommerce/', 'actioned', '', NULL, NULL),
(314, 14, 'ppxo-pps-install-paypal-payments-1', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(315, 15, 'ppxo-pps-install-paypal-payments-2', 'View upgrade guide', 'https://docs.woocommerce.com/document/woocommerce-paypal-payments/paypal-payments-upgrade-guide/', 'actioned', '', NULL, NULL),
(316, 16, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(317, 16, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(318, 17, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(319, 17, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(320, 18, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(321, 18, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(322, 19, 'learn-more', 'Learn more', 'https://woocommerce.com/posts/critical-vulnerability-detected-july-2021/?utm_source=inbox_note&utm_medium=product&utm_campaign=learn-more', 'unactioned', '', NULL, NULL),
(323, 19, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(324, 20, 'share-feedback', 'Share feedback', 'https://automattic.survey.fm/store-management', 'unactioned', '', NULL, NULL),
(325, 21, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(326, 21, 'woocommerce-core-paypal-march-2022-dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(327, 23, 'learn-more', 'Learn more', 'https://developer.woocommerce.com/2022/03/10/woocommerce-3-5-10-6-3-1-security-releases/', 'unactioned', '', NULL, NULL),
(328, 23, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(329, 24, 'pinterest_03_2022_update', 'Update Instructions', 'https://woocommerce.com/document/pinterest-for-woocommerce/?utm_source=inbox_note&utm_medium=product&utm_campaign=pinterest_03_2022_update#section-3', 'actioned', '', NULL, NULL),
(330, 25, 'store_setup_survey_survey_q2_2022_share_your_thoughts', 'Tell us how it’s going', 'https://automattic.survey.fm/store-setup-survey-2022', 'actioned', '', NULL, NULL),
(331, 26, 'wc-admin-wisepad3', 'Grow my business offline', 'https://woocommerce.com/products/wisepad3-card-reader/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wisepad3', 'actioned', '', NULL, NULL),
(332, 27, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(333, 27, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(334, 28, 'learn-more', 'Find out more', 'https://developer.woocommerce.com/2022/08/09/woocommerce-payments-3-9-4-4-5-1-security-releases/', 'unactioned', '', NULL, NULL),
(335, 28, 'dismiss', 'Dismiss', '', 'actioned', '', NULL, NULL),
(336, 29, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'Learn more', 'https://woocommerce.com/document/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_custom_attribute_mapping_q4_2022#attribute-mapping', 'actioned', '', NULL, NULL),
(337, 30, 'needs-update-eway-payment-gateway-rin-action-button-2022-12-20', 'See available updates', 'http://localhost/WP-Mega/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(338, 30, 'needs-update-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(339, 31, 'updated-eway-payment-gateway-rin-action-button-2022-12-20', 'See all updates', 'http://localhost/WP-Mega/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(340, 31, 'updated-eway-payment-gateway-rin-dismiss-button-2022-12-20', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(341, 32, 'share-navigation-survey-feedback', 'Share feedback', 'https://automattic.survey.fm/new-ecommerce-plan-navigation', 'actioned', '', NULL, NULL),
(342, 33, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'Boost my business with Google', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_no_gla', 'actioned', '', NULL, NULL),
(343, 34, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'Create a new ad', 'https://woocommerce.com/products/google-listings-and-ads/?utm_source=inbox_note&utm_medium=product&utm_campaign=google_listings_ads_pmax_i1_q1_2023_with_gla', 'actioned', '', NULL, NULL),
(344, 35, 'woocommerce-wcpay-march-2023-update-needed-button', 'See Blog Post', 'https://developer.woocommerce.com/2023/03/23/critical-vulnerability-detected-in-woocommerce-payments-what-you-need-to-know', 'unactioned', '', NULL, NULL),
(345, 35, 'woocommerce-wcpay-march-2023-update-needed-dismiss-button', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(346, 36, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'Simplify my payments', 'https://woocommerce.com/products/woocommerce-payments/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_no_wcpay', 'actioned', '', NULL, NULL),
(347, 37, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'Set up Tap to Pay on iPhone', 'https://woocommerce.com/document/woocommerce-payments/in-person-payments/woocommerce-in-person-payments-tap-to-pay-on-iphone-quick-start-guide/?utm_source=inbox_note&utm_medium=product&utm_campaign=tap_to_pay_iphone_q2_2023_with_wcpay', 'actioned', '', NULL, NULL),
(348, 38, 'extension-settings', 'See available updates', 'http://localhost/WP-Mega/wp-admin/update-core.php', 'unactioned', '', NULL, NULL),
(349, 38, 'dismiss', 'Dismiss', '#', 'actioned', '', NULL, NULL),
(350, 39, 'wc-admin-wcpay-denmark-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/denmark/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-denmark-Q2-2023', 'actioned', '', NULL, NULL),
(351, 40, 'wc-admin-wcpay-greece-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/greece/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-greece-Q2-2023', 'actioned', '', NULL, NULL),
(352, 41, 'wc-admin-wcpay-norway-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/norway/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-norway-Q2-2023', 'actioned', '', NULL, NULL),
(353, 42, 'wc-admin-wcpay-slovakia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovakia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovakia-Q2-2023', 'actioned', '', NULL, NULL),
(354, 43, 'wc-admin-wcpay-finland-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/finland/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-finland-Q2-2023', 'actioned', '', NULL, NULL),
(355, 44, 'wc-admin-wcpay-estonia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/estonia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-estonia-Q2-2023', 'actioned', '', NULL, NULL),
(356, 45, 'wc-admin-wcpay-lithuania-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/lithuania/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-lithuania-Q2-2023', 'actioned', '', NULL, NULL),
(357, 46, 'wc-admin-wcpay-slovenia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/slovenia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-slovenia-Q2-2023', 'actioned', '', NULL, NULL),
(358, 47, 'wc-admin-wcpay-latvia-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/latvia/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-latvia-Q2-2023', 'actioned', '', NULL, NULL),
(359, 48, 'wc-admin-wcpay-cyprus-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/cyprus/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-cyprus-Q2-2023', 'actioned', '', NULL, NULL),
(360, 49, 'wc-admin-wcpay-malta-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/malta/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-malta-Q2-2023', 'actioned', '', NULL, NULL),
(361, 50, 'wc-admin-wcpay-luxembourg-Q2-2023', 'Simplify my payments', 'https://woocommerce.com/payments/luxembourg/?utm_source=inbox_note&utm_medium=product&utm_campaign=wc-admin-wcpay-luxembourg-Q2-2023', 'actioned', '', NULL, NULL) ;

#
# End of data contents of table `wp_wc_admin_note_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_admin_notes`
#

DROP TABLE IF EXISTS `wp_wc_admin_notes`;


#
# Table structure of table `wp_wc_admin_notes`
#

CREATE TABLE `wp_wc_admin_notes` (
  `note_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `locale` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `title` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `content_data` longtext COLLATE utf8mb4_unicode_520_ci,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_reminder` datetime DEFAULT NULL,
  `is_snoozable` tinyint(1) NOT NULL DEFAULT '0',
  `layout` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `image` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `icon` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'info',
  PRIMARY KEY (`note_id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_admin_notes`
#
INSERT INTO `wp_wc_admin_notes` ( `note_id`, `name`, `type`, `locale`, `title`, `content`, `content_data`, `status`, `source`, `date_created`, `date_reminder`, `is_snoozable`, `layout`, `image`, `is_deleted`, `is_read`, `icon`) VALUES
(1, 'new_in_app_marketplace_2021', 'info', 'en_US', 'Customize your store with extensions', 'Check out our NEW Extensions tab to see our favorite extensions for customizing your store, and discover the most popular extensions in the WooCommerce Marketplace.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 09:44:07', NULL, 0, 'plain', '', 0, 1, 'info'),
(2, 'wayflyer_bnpl_q4_2021', 'marketing', 'en_US', 'Grow your business with funding through Wayflyer', 'Fast, flexible financing to boost cash flow and help your business grow – one fee, no interest rates, penalties, equity, or personal guarantees. Based on your store’s performance, Wayflyer provides funding and analytical insights to invest in your business.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:07', NULL, 0, 'plain', '', 0, 0, 'info'),
(3, 'wc_shipping_mobile_app_usps_q4_2021', 'marketing', 'en_US', 'Print and manage your shipping labels with WooCommerce Shipping and the WooCommerce Mobile App', 'Save time by printing, purchasing, refunding, and tracking shipping labels generated by <a href="https://woocommerce.com/woocommerce-shipping/">WooCommerce Shipping</a> – all directly from your mobile device!', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(4, 'woocommerce-services', 'info', 'en_US', 'WooCommerce Shipping & Tax', 'WooCommerce Shipping &amp; Tax helps get your store "ready to sell" as quickly as possible. You create your products. We take care of tax calculation, payment processing, and shipping label printing! Learn more about the extension that you just installed.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 12:54:19', NULL, 0, 'plain', '', 0, 0, 'info'),
(5, 'your-first-product', 'info', 'en_US', 'Your first product', 'That’s huge! You’re well on your way to building a successful online store — now it’s time to think about how you’ll fulfill your orders.<br /><br />Read our shipping guide to learn best practices and options for putting together your shipping strategy. And for WooCommerce stores in the United States, you can print discounted shipping labels via USPS with <a href="https://href.li/?https://woocommerce.com/shipping" target="_blank">WooCommerce Shipping</a>.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 12:54:19', NULL, 0, 'plain', '', 0, 0, 'info'),
(6, 'wc-admin-optimizing-the-checkout-flow', 'info', 'en_US', 'Optimizing the checkout flow', 'It’s crucial to get your store’s checkout as smooth as possible to avoid losing sales. Let’s take a look at how you can optimize the checkout experience for your shoppers.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(7, 'wc-payments-qualitative-feedback', 'info', 'en_US', 'WooCommerce Payments setup - let us know what you think', 'Congrats on enabling WooCommerce Payments for your store. Please share your feedback in this 2 minute survey to help us improve the setup process.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(8, 'share-your-feedback-on-paypal', 'info', 'en_US', 'Share your feedback on PayPal', 'Share your feedback in this 2 minute survey about how we can make the process of accepting payments more useful for your store.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(9, 'google_listings_and_ads_install', 'marketing', 'en_US', 'Drive traffic and sales with Google', 'Reach online shoppers to drive traffic and sales for your store by showcasing products across Google, for free or with ads.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(10, 'wc-subscriptions-security-update-3-0-15', 'info', 'en_US', 'WooCommerce Subscriptions security update!', 'We recently released an important security update to WooCommerce Subscriptions. To ensure your site’s data is protected, please upgrade <strong>WooCommerce Subscriptions to version 3.0.15</strong> or later.<br /><br />Click the button below to view and update to the latest Subscriptions version, or log in to <a href="https://woocommerce.com/my-dashboard">WooCommerce.com Dashboard</a> and navigate to your <strong>Downloads</strong> page.<br /><br />We recommend always using the latest version of WooCommerce Subscriptions, and other software running on your site, to ensure maximum security.<br /><br />If you have any questions we are here to help — just <a href="https://woocommerce.com/my-account/create-a-ticket/">open a ticket</a>.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(11, 'woocommerce-core-update-5-4-0', 'info', 'en_US', 'Update to WooCommerce 5.4.1 now', 'WooCommerce 5.4.1 addresses a checkout issue discovered in WooCommerce 5.4. We recommend upgrading to WooCommerce 5.4.1 as soon as possible.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(12, 'wcpay-promo-2020-11', 'marketing', 'en_US', 'wcpay-promo-2020-11', 'wcpay-promo-2020-11', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(13, 'wcpay-promo-2020-12', 'marketing', 'en_US', 'wcpay-promo-2020-12', 'wcpay-promo-2020-12', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(14, 'ppxo-pps-upgrade-paypal-payments-1', 'info', 'en_US', 'Get the latest PayPal extension for WooCommerce', 'Heads up! There’s a new PayPal on the block!<br /><br />Now is a great time to upgrade to our latest <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal extension</a> to continue to receive support and updates with PayPal.<br /><br />Get access to a full suite of PayPal payment methods, extensive currency and country coverage, and pay later options with the all-new PayPal extension for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(15, 'ppxo-pps-upgrade-paypal-payments-2', 'info', 'en_US', 'Upgrade your PayPal experience!', 'Get access to a full suite of PayPal payment methods, extensive currency and country coverage, offer subscription and recurring payments, and the new PayPal pay later options.<br /><br />Start using our <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">latest PayPal today</a> to continue to receive support and updates.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(16, 'woocommerce-core-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(17, 'woocommerce-blocks-sqli-july-2021-need-to-update', 'update', 'en_US', 'Action required: Critical vulnerabilities in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we are working with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br />Our investigation into this vulnerability is ongoing, but <strong>we wanted to let you know now about the importance of updating immediately</strong>.<br /><br />For more information on which actions you should take, as well as answers to FAQs, please urgently review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(18, 'woocommerce-core-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(19, 'woocommerce-blocks-sqli-july-2021-store-patched', 'update', 'en_US', 'Solved: Critical vulnerabilities patched in WooCommerce Blocks', 'In response to a critical vulnerability identified on July 13, 2021, we worked with the WordPress Plugins Team to deploy software updates to stores running WooCommerce (versions 3.3 to 5.5) and the WooCommerce Blocks feature plugin (versions 2.5 to 5.5).<br /><br /><strong>Your store has been updated to the latest secure version(s)</strong>. For more information and answers to FAQs, please review our blog post detailing this issue.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(20, 'habit-moment-survey', 'marketing', 'en_US', 'We’re all ears! Share your experience so far with WooCommerce', 'We’d love your input to shape the future of WooCommerce together. Feel free to share any feedback, ideas or suggestions that you have.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(21, 'woocommerce-core-paypal-march-2022-updated', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy PayPal Standard security updates for stores running WooCommerce (version 3.5 to 6.3). It’s recommended to disable PayPal Standard, and use <a href="https://woocommerce.com/products/woocommerce-paypal-payments/" target="_blank">PayPal Payments</a> to accept PayPal.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(22, 'wc-refund-returns-page', 'info', 'en_US', 'Setup a Refund and Returns Policy page to boost your store\'s credibility.', 'We have created a sample draft Refund and Returns Policy page for you. Please have a look and update it to fit your store.', '[]', 'unactioned', 'woocommerce-core', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 1, 'info'),
(23, 'woocommerce-core-paypal-march-2022-updated-nopp', 'update', 'en_US', 'Security auto-update of WooCommerce', '<strong>Your store has been updated to the latest secure version of WooCommerce</strong>. We worked with WordPress to deploy security updates related to PayPal Standard payment gateway for stores running WooCommerce (version 3.5 to 6.3).', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(24, 'pinterest_03_2022_update', 'marketing', 'en_US', 'Your Pinterest for WooCommerce plugin is out of date!', 'Update to the latest version of Pinterest for WooCommerce to continue using this plugin and keep your store connected with Pinterest. To update, visit <strong>Plugins &gt; Installed Plugins</strong>, and click on “update now” under Pinterest for WooCommerce.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(25, 'store_setup_survey_survey_q2_2022', 'survey', 'en_US', 'How is your store setup going?', 'Our goal is to make sure you have all the right tools to start setting up your store in the smoothest way possible.\r\nWe’d love to know if we hit our mark and how we can improve. To collect your thoughts, we made a 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(26, 'wc-admin-wisepad3', 'marketing', 'en_US', 'Take your business on the go in Canada with WooCommerce In-Person Payments', 'Quickly create new orders, accept payment in person for orders placed online, and automatically sync your inventory – no matter where your business takes you. With WooCommerce In-Person Payments and the WisePad 3 card reader, you can bring the power of your store anywhere.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(27, 'woocommerce-payments-august-2022-need-to-update', 'update', 'en_US', 'Action required: Please update WooCommerce Payments', 'An updated secure version of WooCommerce Payments is available – please ensure that you’re using the latest patch version. For more information on what action you need to take, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(28, 'woocommerce-payments-august-2022-store-patched', 'update', 'en_US', 'WooCommerce Payments has been automatically updated', 'You’re now running the latest secure version of WooCommerce Payments. We’ve worked with the WordPress Plugins team to deploy a security update to stores running WooCommerce Payments (version 3.9 to 4.5). For further information, please review the article below.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(29, 'google_listings_ads_custom_attribute_mapping_q4_2022', 'marketing', 'en_US', 'Our latest improvement to the Google Listings & Ads extension: Attribute Mapping', 'You spoke, we listened. This new feature enables you to easily upload your products, customize your product attributes in one place, and target shoppers with more relevant ads. Extend how far your ad dollars go with each campaign.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(30, 'needs-update-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'Security vulnerability patched in WooCommerce Eway Gateway', 'In response to a potential vulnerability identified in WooCommerce Eway Gateway versions 3.1.0 to 3.5.0, we’ve worked to deploy security fixes and have released an updated version.\r\nNo external exploits have been detected, but we recommend you update to your latest supported version 3.1.26, 3.2.3, 3.3.1, 3.4.6, or 3.5.1', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(31, 'updated-eway-payment-gateway-rin-2022-12-20', 'update', 'en_US', 'WooCommerce Eway Gateway has been automatically updated', 'Your store is now running the latest secure version of WooCommerce Eway Gateway. We worked with the WordPress Plugins team to deploy a software update to stores running WooCommerce Eway Gateway (versions 3.1.0 to 3.5.0) in response to a security vulnerability that was discovered.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(32, 'ecomm-wc-navigation-survey-2023', 'info', 'en_US', 'Navigating WooCommerce on WordPress.com', 'We are improving the WooCommerce navigation on WordPress.com and would love your help to make it better! Please share your experience with us in this 2-minute survey.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(33, 'google_listings_ads_pmax_i1_q1_2023_no_gla', 'marketing', 'en_US', 'Create more engaging ads – without the hard work', 'Get in front of millions of shoppers searching for products like yours with Google Listings &amp; Ads. With new customization features, Google automatically tests multiple combinations of text and images to create the most engaging ad to boost your business. Plus, get up to $500 in ad credit – terms and conditions apply.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 1, 'info'),
(34, 'google_listings_ads_pmax_i1_q1_2023_with_gla', 'marketing', 'en_US', 'New customization features to boost your business', 'You can now add custom images, messaging, and URLs to campaigns in Google Listings &amp; Ads. Google then automatically tests multiple combinations to create the most engaging version to help boost your business. Get more sales with dynamic content – edit an existing campaign or create a new ad now.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(35, 'woocommerce-wcpay-march-2023-update-needed', 'update', 'en_US', 'Action required: Security update for WooCommerce Payments', '<strong>Your store requires a security update for WooCommerce Payments</strong>. Please update to the latest version of WooCommerce Payments immediately to address a potential vulnerability discovered on March 22. For more information on how to update, visit this WooCommerce Developer Blog Post.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(36, 'tap_to_pay_iphone_q2_2023_no_wcpay', 'marketing', 'en_US', 'Accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone and WooCommerce Payments is quick, secure, and simple to set up — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person.', '[]', 'unactioned', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 1, 'info'),
(37, 'tap_to_pay_iphone_q2_2023_with_wcpay', 'marketing', 'en_US', 'New: accept in-person contactless payments on your iPhone', 'Tap to Pay on iPhone is quick, secure, and simple to set up in WooCommerce Payments — no extra terminals or card readers are needed. Accept contactless debit and credit cards, Apple Pay, and other NFC digital wallets in person in a few short steps!', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(38, 'woocommerce-WCPreOrders-april-2023-update-needed', 'update', 'en_US', 'Action required: Security update of WooCommerce Pre-Orders extension', '<strong>Your store requires a security update for the WooCommerce Pre-Orders extension</strong>. Please update the WooCommerce Pre-Orders extension immediately to address a potential vulnerability discovered on April 11.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(39, 'wc-admin-wcpay-denmark-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Denmark!', 'We’ve recently released WooCommerce Payments in Denmark. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(40, 'wc-admin-wcpay-greece-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Greece!', 'We’ve recently released WooCommerce Payments in Greece. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(41, 'wc-admin-wcpay-norway-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Norway!', 'We’ve recently released WooCommerce Payments in Norway. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(42, 'wc-admin-wcpay-slovakia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovakia!', 'We’ve recently released WooCommerce Payments in Slovakia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(43, 'wc-admin-wcpay-finland-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Finland!', 'We’ve recently released WooCommerce Payments in Finland. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(44, 'wc-admin-wcpay-estonia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Estonia!', 'We’ve recently released WooCommerce Payments in Estonia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(45, 'wc-admin-wcpay-lithuania-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Lithuania!', 'We’ve recently released WooCommerce Payments in Lithuania. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(46, 'wc-admin-wcpay-slovenia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Slovenia!', 'We’ve recently released WooCommerce Payments in Slovenia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(47, 'wc-admin-wcpay-latvia-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Latvia!', 'We’ve recently released WooCommerce Payments in Latvia. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(48, 'wc-admin-wcpay-cyprus-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Cyprus!', 'We’ve recently released WooCommerce Payments in Cyprus. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(49, 'wc-admin-wcpay-malta-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Malta!', 'We’ve recently released WooCommerce Payments in Malta. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(50, 'wc-admin-wcpay-luxembourg-Q2-2023', 'marketing', 'en_US', 'WooCommerce Payments is now available in Luxembourg!', 'We’ve recently released WooCommerce Payments in Luxembourg. You can view and manage transactions right in your WordPress dashboard while securely accepting major cards, Apple Pay, and payments in over 100 currencies.', '[]', 'pending', 'woocommerce.com', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(51, 'wc-admin-wc-helper-connection', 'info', 'en_US', 'Connect to WooCommerce.com', 'Connect to get important product notifications and updates.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 09:44:08', NULL, 0, 'plain', '', 0, 1, 'info'),
(52, 'storefront-customize', 'info', 'en_US', 'Design your store with Storefront 🎨', 'Visit the Storefront settings page to start setup and customization of your shop.', '[]', 'unactioned', 'storefront', '2023-04-20 09:45:48', NULL, 0, 'plain', '', 0, 1, 'info'),
(53, 'wc-admin-coupon-page-moved', 'update', 'en_US', 'Coupon management has moved!', 'Coupons can now be managed from Marketing &gt; Coupons. Click the button below to remove the legacy WooCommerce &gt; Coupons menu item.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-20 11:01:08', NULL, 0, 'plain', '', 0, 0, 'info'),
(54, 'wc-admin-orders-milestone', 'info', 'en_US', 'First order received', 'Congratulations on getting your first order! Now is a great time to learn how to manage your orders.', '{"current_milestone":1}', 'unactioned', 'woocommerce-admin', '2023-04-20 12:44:48', NULL, 0, 'plain', '', 0, 0, 'info'),
(55, 'wc-admin-choosing-a-theme', 'marketing', 'en_US', 'Choosing a theme?', 'Check out the themes that are compatible with WooCommerce and choose one aligned with your brand and business needs.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-21 09:58:13', NULL, 0, 'plain', '', 0, 0, 'info'),
(56, 'wc-admin-launch-checklist', 'info', 'en_US', 'Ready to launch your store?', 'To make sure you never get that sinking "what did I forget" feeling, we\'ve put together the essential pre-launch checklist.', '[]', 'unactioned', 'woocommerce-admin', '2023-04-21 09:58:13', NULL, 0, 'plain', '', 0, 0, 'info') ;

#
# End of data contents of table `wp_wc_admin_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_category_lookup`
#

DROP TABLE IF EXISTS `wp_wc_category_lookup`;


#
# Table structure of table `wp_wc_category_lookup`
#

CREATE TABLE `wp_wc_category_lookup` (
  `category_tree_id` bigint(20) unsigned NOT NULL,
  `category_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`category_tree_id`,`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_category_lookup`
#
INSERT INTO `wp_wc_category_lookup` ( `category_tree_id`, `category_id`) VALUES
(15, 15),
(16, 16),
(17, 17),
(22, 22),
(24, 24),
(26, 26),
(29, 29) ;

#
# End of data contents of table `wp_wc_category_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_customer_lookup`
#

DROP TABLE IF EXISTS `wp_wc_customer_lookup`;


#
# Table structure of table `wp_wc_customer_lookup`
#

CREATE TABLE `wp_wc_customer_lookup` (
  `customer_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `username` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `first_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `date_last_active` timestamp NULL DEFAULT NULL,
  `date_registered` timestamp NULL DEFAULT NULL,
  `country` char(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `postcode` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `city` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `state` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_customer_lookup`
#
INSERT INTO `wp_wc_customer_lookup` ( `customer_id`, `user_id`, `username`, `first_name`, `last_name`, `email`, `date_last_active`, `date_registered`, `country`, `postcode`, `city`, `state`) VALUES
(1, 1, 'medie-admin', 'Martin', 'Johansson', 'mjohansson176@gmail.com', '2023-04-21 07:04:41', '2023-04-20 09:41:33', 'SE', '44277', 'Romelanda', '') ;

#
# End of data contents of table `wp_wc_customer_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_download_log`
#

DROP TABLE IF EXISTS `wp_wc_download_log`;


#
# Table structure of table `wp_wc_download_log`
#

CREATE TABLE `wp_wc_download_log` (
  `download_log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `user_ip_address` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`download_log_id`),
  KEY `permission_id` (`permission_id`),
  KEY `timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_download_log`
#

#
# End of data contents of table `wp_wc_download_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_coupon_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_coupon_lookup`;


#
# Table structure of table `wp_wc_order_coupon_lookup`
#

CREATE TABLE `wp_wc_order_coupon_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `discount_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`coupon_id`),
  KEY `coupon_id` (`coupon_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_coupon_lookup`
#

#
# End of data contents of table `wp_wc_order_coupon_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_product_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_product_lookup`;


#
# Table structure of table `wp_wc_order_product_lookup`
#

CREATE TABLE `wp_wc_order_product_lookup` (
  `order_item_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `variation_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product_qty` int(11) NOT NULL,
  `product_net_revenue` double NOT NULL DEFAULT '0',
  `product_gross_revenue` double NOT NULL DEFAULT '0',
  `coupon_amount` double NOT NULL DEFAULT '0',
  `tax_amount` double NOT NULL DEFAULT '0',
  `shipping_amount` double NOT NULL DEFAULT '0',
  `shipping_tax_amount` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  KEY `customer_id` (`customer_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_product_lookup`
#
INSERT INTO `wp_wc_order_product_lookup` ( `order_item_id`, `order_id`, `product_id`, `variation_id`, `customer_id`, `date_created`, `product_qty`, `product_net_revenue`, `product_gross_revenue`, `coupon_amount`, `tax_amount`, `shipping_amount`, `shipping_tax_amount`) VALUES
(1, 99, 93, 0, 1, '2023-04-20 14:33:16', 1, '479', '599', '0', '120', '0', '0'),
(3, 100, 93, 0, 1, '2023-04-20 14:36:35', 1, '479', '599', '0', '120', '0', '0'),
(5, 114, 93, 0, 1, '2023-04-21 09:04:41', 1, '479', '599', '0', '120', '0', '0') ;

#
# End of data contents of table `wp_wc_order_product_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_stats`
#

DROP TABLE IF EXISTS `wp_wc_order_stats`;


#
# Table structure of table `wp_wc_order_stats`
#

CREATE TABLE `wp_wc_order_stats` (
  `order_id` bigint(20) unsigned NOT NULL,
  `parent_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_paid` datetime DEFAULT '0000-00-00 00:00:00',
  `date_completed` datetime DEFAULT '0000-00-00 00:00:00',
  `num_items_sold` int(11) NOT NULL DEFAULT '0',
  `total_sales` double NOT NULL DEFAULT '0',
  `tax_total` double NOT NULL DEFAULT '0',
  `shipping_total` double NOT NULL DEFAULT '0',
  `net_total` double NOT NULL DEFAULT '0',
  `returning_customer` tinyint(1) DEFAULT NULL,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `date_created` (`date_created`),
  KEY `customer_id` (`customer_id`),
  KEY `status` (`status`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_stats`
#
INSERT INTO `wp_wc_order_stats` ( `order_id`, `parent_id`, `date_created`, `date_created_gmt`, `date_paid`, `date_completed`, `num_items_sold`, `total_sales`, `tax_total`, `shipping_total`, `net_total`, `returning_customer`, `status`, `customer_id`) VALUES
(99, 0, '2023-04-20 14:33:16', '2023-04-20 12:33:16', '2023-04-20 14:47:52', '2023-04-20 14:47:52', 1, '599', '120', '0', '479', 0, 'wc-completed', 1),
(100, 0, '2023-04-20 14:36:35', '2023-04-20 12:36:35', '2023-04-20 14:42:39', '2023-04-20 14:42:39', 1, '599', '120', '0', '479', 1, 'wc-completed', 1),
(114, 0, '2023-04-21 09:04:41', '2023-04-21 07:04:41', '2023-04-21 09:05:45', '2023-04-21 09:05:45', 1, '599', '120', '0', '479', 1, 'wc-completed', 1) ;

#
# End of data contents of table `wp_wc_order_stats`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_order_tax_lookup`
#

DROP TABLE IF EXISTS `wp_wc_order_tax_lookup`;


#
# Table structure of table `wp_wc_order_tax_lookup`
#

CREATE TABLE `wp_wc_order_tax_lookup` (
  `order_id` bigint(20) unsigned NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `shipping_tax` double NOT NULL DEFAULT '0',
  `order_tax` double NOT NULL DEFAULT '0',
  `total_tax` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`order_id`,`tax_rate_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `date_created` (`date_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_order_tax_lookup`
#
INSERT INTO `wp_wc_order_tax_lookup` ( `order_id`, `tax_rate_id`, `date_created`, `shipping_tax`, `order_tax`, `total_tax`) VALUES
(99, 1, '2023-04-20 14:33:16', '0', '120', '120'),
(100, 1, '2023-04-20 14:36:35', '0', '120', '120'),
(114, 1, '2023-04-21 09:04:41', '0', '120', '120') ;

#
# End of data contents of table `wp_wc_order_tax_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_attributes_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_attributes_lookup`;


#
# Table structure of table `wp_wc_product_attributes_lookup`
#

CREATE TABLE `wp_wc_product_attributes_lookup` (
  `product_id` bigint(20) NOT NULL,
  `product_or_parent_id` bigint(20) NOT NULL,
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `term_id` bigint(20) NOT NULL,
  `is_variation_attribute` tinyint(1) NOT NULL,
  `in_stock` tinyint(1) NOT NULL,
  PRIMARY KEY (`product_or_parent_id`,`term_id`,`product_id`,`taxonomy`),
  KEY `is_variation_attribute_term_id` (`is_variation_attribute`,`term_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_attributes_lookup`
#

#
# End of data contents of table `wp_wc_product_attributes_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_download_directories`
#

DROP TABLE IF EXISTS `wp_wc_product_download_directories`;


#
# Table structure of table `wp_wc_product_download_directories`
#

CREATE TABLE `wp_wc_product_download_directories` (
  `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `url` varchar(256) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`url_id`),
  KEY `url` (`url`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_download_directories`
#
INSERT INTO `wp_wc_product_download_directories` ( `url_id`, `url`, `enabled`) VALUES
(1, 'file://C:/MAMP/htdocs/WP-Mega/wp-content/uploads/woocommerce_uploads/', 1),
(2, 'http://localhost/WP-Mega/wp-content/uploads/woocommerce_uploads/', 1) ;

#
# End of data contents of table `wp_wc_product_download_directories`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_product_meta_lookup`
#

DROP TABLE IF EXISTS `wp_wc_product_meta_lookup`;


#
# Table structure of table `wp_wc_product_meta_lookup`
#

CREATE TABLE `wp_wc_product_meta_lookup` (
  `product_id` bigint(20) NOT NULL,
  `sku` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  `virtual` tinyint(1) DEFAULT '0',
  `downloadable` tinyint(1) DEFAULT '0',
  `min_price` decimal(19,4) DEFAULT NULL,
  `max_price` decimal(19,4) DEFAULT NULL,
  `onsale` tinyint(1) DEFAULT '0',
  `stock_quantity` double DEFAULT NULL,
  `stock_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'instock',
  `rating_count` bigint(20) DEFAULT '0',
  `average_rating` decimal(3,2) DEFAULT '0.00',
  `total_sales` bigint(20) DEFAULT '0',
  `tax_status` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT 'taxable',
  `tax_class` varchar(100) COLLATE utf8mb4_unicode_520_ci DEFAULT '',
  PRIMARY KEY (`product_id`),
  KEY `virtual` (`virtual`),
  KEY `downloadable` (`downloadable`),
  KEY `stock_status` (`stock_status`),
  KEY `stock_quantity` (`stock_quantity`),
  KEY `onsale` (`onsale`),
  KEY `min_max_price` (`min_price`,`max_price`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_product_meta_lookup`
#
INSERT INTO `wp_wc_product_meta_lookup` ( `product_id`, `sku`, `virtual`, `downloadable`, `min_price`, `max_price`, `onsale`, `stock_quantity`, `stock_status`, `rating_count`, `average_rating`, `total_sales`, `tax_status`, `tax_class`) VALUES
(13, 'MegaShop - 0001', 0, 0, '599.0000', '599.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', ''),
(15, '', 0, 0, '599.0000', '599.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(16, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(17, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(18, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(19, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(20, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(21, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(22, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(23, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(24, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(25, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(26, '', 0, 0, '599.0000', '599.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(44, '', 0, 0, '199.0000', '199.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(46, 'MegaShop - 0001', 0, 0, '699.0000', '699.0000', 1, '10', 'instock', 0, '0.00', 0, 'taxable', ''),
(48, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(49, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(50, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(51, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(52, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(53, 'MegaShop - 0001-1', 0, 0, '699.0000', '699.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', ''),
(54, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(55, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(56, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(57, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(58, '', 0, 0, '699.0000', '699.0000', 1, NULL, 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(59, 'MegaShop - 0002', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', ''),
(64, '', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(65, '', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(66, '', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(67, '', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(68, '', 0, 0, '449.0000', '449.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(70, 'MegaShop - 0003', 0, 0, '199.0000', '199.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(78, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(79, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(80, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(81, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(82, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(83, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(84, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(85, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(86, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(87, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(88, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(89, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(90, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(91, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(92, '', 0, 0, '199.0000', '199.0000', 0, '10', 'instock', 0, '0.00', 0, 'taxable', 'parent'),
(93, 'MegaShop - 0101', 1, 1, '599.0000', '599.0000', 1, NULL, 'instock', 0, '0.00', 3, 'taxable', ''),
(101, 'MegaShop - 0004', 0, 0, '0.0000', '0.0000', 0, NULL, 'instock', 0, '0.00', 0, 'taxable', ''),
(105, '', 0, 0, '24.0000', '24.0000', 0, '100', 'instock', 0, '0.00', 0, 'taxable', ''),
(106, '', 0, 0, '24.0000', '24.0000', 0, '100', 'instock', 0, '0.00', 0, 'taxable', ''),
(108, '', 0, 0, '24.0000', '24.0000', 0, '100', 'instock', 0, '0.00', 0, 'taxable', ''),
(109, 'MegaShop - 0005', 0, 0, '139.0000', '139.0000', 0, '12', 'instock', 0, '0.00', 0, 'taxable', '') ;

#
# End of data contents of table `wp_wc_product_meta_lookup`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_rate_limits`
#

DROP TABLE IF EXISTS `wp_wc_rate_limits`;


#
# Table structure of table `wp_wc_rate_limits`
#

CREATE TABLE `wp_wc_rate_limits` (
  `rate_limit_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_limit_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `rate_limit_expiry` bigint(20) unsigned NOT NULL,
  `rate_limit_remaining` smallint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`rate_limit_id`),
  UNIQUE KEY `rate_limit_key` (`rate_limit_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_rate_limits`
#

#
# End of data contents of table `wp_wc_rate_limits`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_reserved_stock`
#

DROP TABLE IF EXISTS `wp_wc_reserved_stock`;


#
# Table structure of table `wp_wc_reserved_stock`
#

CREATE TABLE `wp_wc_reserved_stock` (
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `stock_quantity` double NOT NULL DEFAULT '0',
  `timestamp` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `expires` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_reserved_stock`
#

#
# End of data contents of table `wp_wc_reserved_stock`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_tax_rate_classes`
#

DROP TABLE IF EXISTS `wp_wc_tax_rate_classes`;


#
# Table structure of table `wp_wc_tax_rate_classes`
#

CREATE TABLE `wp_wc_tax_rate_classes` (
  `tax_rate_class_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_class_id`),
  UNIQUE KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_tax_rate_classes`
#
INSERT INTO `wp_wc_tax_rate_classes` ( `tax_rate_class_id`, `name`, `slug`) VALUES
(1, 'Reduced rate', 'reduced-rate'),
(2, 'Zero rate', 'zero-rate') ;

#
# End of data contents of table `wp_wc_tax_rate_classes`
# --------------------------------------------------------



#
# Delete any existing table `wp_wc_webhooks`
#

DROP TABLE IF EXISTS `wp_wc_webhooks`;


#
# Table structure of table `wp_wc_webhooks`
#

CREATE TABLE `wp_wc_webhooks` (
  `webhook_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `delivery_url` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `secret` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `topic` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `date_created` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_created_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `date_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `api_version` smallint(4) NOT NULL,
  `failure_count` smallint(10) NOT NULL DEFAULT '0',
  `pending_delivery` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`webhook_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_wc_webhooks`
#

#
# End of data contents of table `wp_wc_webhooks`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `description` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `permissions` varchar(10) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `nonces` longtext COLLATE utf8mb4_unicode_520_ci,
  `truncated_key` char(7) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_label` varchar(200) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `attribute_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_orderby` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `download_id` varchar(36) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `product_id` bigint(20) unsigned NOT NULL,
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(16),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`),
  KEY `order_id` (`order_id`),
  KEY `user_order_remaining_expires` (`user_id`,`order_id`,`downloads_remaining`,`access_expires`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#
INSERT INTO `wp_woocommerce_downloadable_product_permissions` ( `permission_id`, `download_id`, `product_id`, `order_id`, `order_key`, `user_email`, `user_id`, `downloads_remaining`, `access_granted`, `access_expires`, `download_count`) VALUES
(1, '67ea6b5b-688a-4790-ba51-6d0c35b4532e', 93, 100, 'wc_order_QvdqqVJEO3AKJ', 'mjohansson176@gmail.com', 1, '', '2023-04-20 00:00:00', NULL, 0),
(2, '67ea6b5b-688a-4790-ba51-6d0c35b4532e', 93, 99, 'wc_order_pr4We7C8sBbDO', 'mjohansson176@gmail.com', 1, '', '2023-04-20 00:00:00', NULL, 0),
(3, '67ea6b5b-688a-4790-ba51-6d0c35b4532e', 93, 114, 'wc_order_xgdQ5oAyltfJM', 'mjohansson176@gmail.com', 1, '', '2023-04-21 00:00:00', NULL, 0) ;

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_log`
#

DROP TABLE IF EXISTS `wp_woocommerce_log`;


#
# Table structure of table `wp_woocommerce_log`
#

CREATE TABLE `wp_woocommerce_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `level` smallint(4) NOT NULL,
  `source` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `message` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `context` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`log_id`),
  KEY `level` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_log`
#

#
# End of data contents of table `wp_woocommerce_log`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#
INSERT INTO `wp_woocommerce_order_itemmeta` ( `meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(1, 1, '_product_id', '93'),
(2, 1, '_variation_id', '0'),
(3, 1, '_qty', '1'),
(4, 1, '_tax_class', ''),
(5, 1, '_line_subtotal', '479.2'),
(6, 1, '_line_subtotal_tax', '120'),
(7, 1, '_line_total', '479.2'),
(8, 1, '_line_tax', '120'),
(9, 1, '_line_tax_data', 'a:2:{s:5:"total";a:1:{i:1;s:5:"119.8";}s:8:"subtotal";a:1:{i:1;s:5:"119.8";}}'),
(10, 2, 'rate_id', '1'),
(11, 2, 'label', 'Moms'),
(12, 2, 'compound', ''),
(13, 2, 'tax_amount', '120'),
(14, 2, 'shipping_tax_amount', '0'),
(15, 2, 'rate_percent', '25'),
(16, 3, '_product_id', '93'),
(17, 3, '_variation_id', '0'),
(18, 3, '_qty', '1'),
(19, 3, '_tax_class', ''),
(20, 3, '_line_subtotal', '479.2'),
(21, 3, '_line_subtotal_tax', '120'),
(22, 3, '_line_total', '479.2'),
(23, 3, '_line_tax', '120'),
(24, 3, '_line_tax_data', 'a:2:{s:5:"total";a:1:{i:1;s:5:"119.8";}s:8:"subtotal";a:1:{i:1;s:5:"119.8";}}'),
(25, 4, 'rate_id', '1'),
(26, 4, 'label', 'Moms'),
(27, 4, 'compound', ''),
(28, 4, 'tax_amount', '120'),
(29, 4, 'shipping_tax_amount', '0'),
(30, 4, 'rate_percent', '25'),
(31, 5, '_product_id', '93'),
(32, 5, '_variation_id', '0'),
(33, 5, '_qty', '1'),
(34, 5, '_tax_class', ''),
(35, 5, '_line_subtotal', '479.2'),
(36, 5, '_line_subtotal_tax', '120'),
(37, 5, '_line_total', '479.2'),
(38, 5, '_line_tax', '120'),
(39, 5, '_line_tax_data', 'a:2:{s:5:"total";a:1:{i:1;s:5:"119.8";}s:8:"subtotal";a:1:{i:1;s:5:"119.8";}}'),
(40, 6, 'rate_id', '1'),
(41, 6, 'label', 'Moms'),
(42, 6, 'compound', ''),
(43, 6, 'tax_amount', '120'),
(44, 6, 'shipping_tax_amount', '0'),
(45, 6, 'rate_percent', '25') ;

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_item_name` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#
INSERT INTO `wp_woocommerce_order_items` ( `order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(1, 'Träningsinspiration - DLC', 'line_item', 99),
(2, 'SE-MOMS-1', 'tax', 99),
(3, 'Träningsinspiration - DLC', 'line_item', 100),
(4, 'SE-MOMS-1', 'tax', 100),
(5, 'Träningsinspiration - DLC', 'line_item', 114),
(6, 'SE-MOMS-1', 'tax', 114) ;

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokenmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokenmeta`;


#
# Table structure of table `wp_woocommerce_payment_tokenmeta`
#

CREATE TABLE `wp_woocommerce_payment_tokenmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `payment_token_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `payment_token_id` (`payment_token_id`),
  KEY `meta_key` (`meta_key`(32))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokenmeta`
#

#
# End of data contents of table `wp_woocommerce_payment_tokenmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_payment_tokens`
#

DROP TABLE IF EXISTS `wp_woocommerce_payment_tokens`;


#
# Table structure of table `wp_woocommerce_payment_tokens`
#

CREATE TABLE `wp_woocommerce_payment_tokens` (
  `token_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gateway_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `token` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `type` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_payment_tokens`
#

#
# End of data contents of table `wp_woocommerce_payment_tokens`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `session_expiry` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`session_id`),
  UNIQUE KEY `session_key` (`session_key`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(2, 't_e4d710a7204e32ee7c89cc8b9cbeac', 'a:7:{s:4:"cart";s:6:"a:0:{}";s:11:"cart_totals";s:367:"a:15:{s:8:"subtotal";i:0;s:12:"subtotal_tax";i:0;s:14:"shipping_total";i:0;s:12:"shipping_tax";i:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";i:0;s:12:"discount_tax";i:0;s:19:"cart_contents_total";i:0;s:17:"cart_contents_tax";i:0;s:19:"cart_contents_taxes";a:0:{}s:9:"fee_total";i:0;s:7:"fee_tax";i:0;s:9:"fee_taxes";a:0:{}s:5:"total";i:0;s:9:"total_tax";i:0;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:8:"customer";s:716:"a:27:{s:2:"id";s:1:"0";s:13:"date_modified";s:0:"";s:8:"postcode";s:0:"";s:4:"city";s:0:"";s:9:"address_1";s:0:"";s:7:"address";s:0:"";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"SE";s:17:"shipping_postcode";s:0:"";s:13:"shipping_city";s:0:"";s:18:"shipping_address_1";s:0:"";s:16:"shipping_address";s:0:"";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"SE";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:0:"";s:10:"first_name";s:0:"";s:9:"last_name";s:0:"";s:7:"company";s:0:"";s:5:"phone";s:0:"";s:5:"email";s:0:"";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";}', 1682231120),
(3, '1', 'a:14:{s:4:"cart";s:1925:"a:3:{s:32:"f0935e4cd5920aa6c7c996a5ee53a70f";a:11:{s:3:"key";s:32:"f0935e4cd5920aa6c7c996a5ee53a70f";s:10:"product_id";i:106;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}s:5:"total";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}}s:13:"line_subtotal";d:57.60000000000000142108547152020037174224853515625;s:17:"line_subtotal_tax";d:14;s:10:"line_total";d:57.60000000000000142108547152020037174224853515625;s:8:"line_tax";d:14;}s:32:"5ccf25552359d5cde3288696eba65bd5";a:11:{s:3:"key";s:32:"5ccf25552359d5cde3288696eba65bd5";s:10:"product_id";i:70;s:12:"variation_id";i:78;s:9:"variation";a:2:{s:17:"attribute_storlek";s:2:"XS";s:14:"attribute_farg";s:5:"Svart";}s:8:"quantity";i:1;s:9:"data_hash";s:32:"a404624d03e6fc9c5f20d84c6e18543d";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:39.7999999999999971578290569595992565155029296875;}s:5:"total";a:1:{i:1;d:39.7999999999999971578290569595992565155029296875;}}s:13:"line_subtotal";d:159.19999999999998863131622783839702606201171875;s:17:"line_subtotal_tax";d:40;s:10:"line_total";d:159.19999999999998863131622783839702606201171875;s:8:"line_tax";d:40;}s:32:"2723d092b63885e0d7c260cc007e8b9d";a:11:{s:3:"key";s:32:"2723d092b63885e0d7c260cc007e8b9d";s:10:"product_id";i:109;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:27.800000000000000710542735760100185871124267578125;}s:5:"total";a:1:{i:1;d:27.800000000000000710542735760100185871124267578125;}}s:13:"line_subtotal";d:111.2000000000000028421709430404007434844970703125;s:17:"line_subtotal_tax";d:28;s:10:"line_total";d:111.2000000000000028421709430404007434844970703125;s:8:"line_tax";d:28;}}";s:11:"cart_totals";s:405:"a:15:{s:8:"subtotal";s:3:"328";s:12:"subtotal_tax";d:82;s:14:"shipping_total";s:1:"0";s:12:"shipping_tax";d:0;s:14:"shipping_taxes";a:0:{}s:14:"discount_total";d:0;s:12:"discount_tax";d:0;s:19:"cart_contents_total";s:3:"328";s:17:"cart_contents_tax";d:82;s:19:"cart_contents_taxes";a:1:{i:1;d:82;}s:9:"fee_total";s:1:"0";s:7:"fee_tax";d:0;s:9:"fee_taxes";a:0:{}s:5:"total";s:3:"410";s:9:"total_tax";d:82;}";s:15:"applied_coupons";s:6:"a:0:{}";s:22:"coupon_discount_totals";s:6:"a:0:{}";s:26:"coupon_discount_tax_totals";s:6:"a:0:{}";s:21:"removed_cart_contents";s:1246:"a:2:{s:32:"65b9eea6e1cc6bb9f0cd2a47751a186f";a:11:{s:3:"key";s:32:"65b9eea6e1cc6bb9f0cd2a47751a186f";s:10:"product_id";i:105;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:2;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:9.5999999999999996447286321199499070644378662109375;}s:5:"total";a:1:{i:1;d:9.5999999999999996447286321199499070644378662109375;}}s:13:"line_subtotal";d:38.39999999999999857891452847979962825775146484375;s:17:"line_subtotal_tax";d:10;s:10:"line_total";d:38.39999999999999857891452847979962825775146484375;s:8:"line_tax";d:10;}s:32:"a3c65c2974270fd093ee8a9bf8ae7d0b";a:11:{s:3:"key";s:32:"a3c65c2974270fd093ee8a9bf8ae7d0b";s:10:"product_id";i:108;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:9:"data_hash";s:32:"b5c1d5ca8bae6d4896cf1807cdf763f0";s:13:"line_tax_data";a:2:{s:8:"subtotal";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}s:5:"total";a:1:{i:1;d:14.4000000000000003552713678800500929355621337890625;}}s:13:"line_subtotal";d:57.60000000000000142108547152020037174224853515625;s:17:"line_subtotal_tax";d:14;s:10:"line_total";d:57.60000000000000142108547152020037174224853515625;s:8:"line_tax";d:14;}}";s:8:"customer";s:905:"a:27:{s:2:"id";s:1:"1";s:13:"date_modified";s:25:"2023-04-21T09:04:41+02:00";s:8:"postcode";s:5:"44277";s:4:"city";s:9:"Romelanda";s:9:"address_1";s:20:"Askvägen 7 lgh 1102";s:7:"address";s:20:"Askvägen 7 lgh 1102";s:9:"address_2";s:0:"";s:5:"state";s:0:"";s:7:"country";s:2:"SE";s:17:"shipping_postcode";s:5:"44277";s:13:"shipping_city";s:9:"Romelanda";s:18:"shipping_address_1";s:20:"Askvägen 7 lgh 1102";s:16:"shipping_address";s:20:"Askvägen 7 lgh 1102";s:18:"shipping_address_2";s:0:"";s:14:"shipping_state";s:0:"";s:16:"shipping_country";s:2:"SE";s:13:"is_vat_exempt";s:0:"";s:19:"calculated_shipping";s:1:"1";s:10:"first_name";s:6:"Martin";s:9:"last_name";s:9:"Johansson";s:7:"company";s:0:"";s:5:"phone";s:10:"0761889887";s:5:"email";s:23:"mjohansson176@gmail.com";s:19:"shipping_first_name";s:0:"";s:18:"shipping_last_name";s:0:"";s:16:"shipping_company";s:0:"";s:14:"shipping_phone";s:0:"";}";s:10:"wc_notices";N;s:21:"chosen_payment_method";s:3:"cod";s:22:"order_awaiting_payment";N;s:22:"shipping_for_package_0";s:1521:"a:2:{s:12:"package_hash";s:40:"wc_ship_fbe9aee6df76f7d733621fac7c6f6ebc";s:5:"rates";a:2:{s:11:"flat_rate:2";O:16:"WC_Shipping_Rate":4:{s:7:"\0*\0data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:1:{i:1;d:12.5;}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:110:"Dextro Energy Cola &times; 3, Core Essence Logo Tee W - XS, Svart &times; 1, Hypersport Bottle 20 Oz &times; 1";}s:4:"data";a:6:{s:2:"id";s:11:"flat_rate:2";s:9:"method_id";s:9:"flat_rate";s:11:"instance_id";i:2;s:5:"label";s:9:"Flat rate";s:4:"cost";s:2:"50";s:5:"taxes";a:1:{i:1;d:12.5;}}s:9:"meta_data";a:1:{s:5:"Items";s:110:"Dextro Energy Cola &times; 3, Core Essence Logo Tee W - XS, Svart &times; 1, Hypersport Bottle 20 Oz &times; 1";}}s:14:"local_pickup:3";O:16:"WC_Shipping_Rate":4:{s:7:"\0*\0data";a:6:{s:2:"id";s:14:"local_pickup:3";s:9:"method_id";s:12:"local_pickup";s:11:"instance_id";i:3;s:5:"label";s:12:"Local pickup";s:4:"cost";s:1:"0";s:5:"taxes";a:0:{}}s:12:"\0*\0meta_data";a:1:{s:5:"Items";s:110:"Dextro Energy Cola &times; 3, Core Essence Logo Tee W - XS, Svart &times; 1, Hypersport Bottle 20 Oz &times; 1";}s:4:"data";a:6:{s:2:"id";s:14:"local_pickup:3";s:9:"method_id";s:12:"local_pickup";s:11:"instance_id";i:3;s:5:"label";s:12:"Local pickup";s:4:"cost";s:1:"0";s:5:"taxes";a:0:{}}s:9:"meta_data";a:1:{s:5:"Items";s:110:"Dextro Energy Cola &times; 3, Core Essence Logo Tee W - XS, Svart &times; 1, Hypersport Bottle 20 Oz &times; 1";}}}}";s:25:"previous_shipping_methods";s:65:"a:1:{i:0;a:2:{i:0;s:11:"flat_rate:2";i:1;s:14:"local_pickup:3";}}";s:23:"chosen_shipping_methods";s:32:"a:1:{i:0;s:14:"local_pickup:3";}";s:22:"shipping_method_counts";s:14:"a:1:{i:0;i:2;}";}', 1682233464) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_locations`;


#
# Table structure of table `wp_woocommerce_shipping_zone_locations`
#

CREATE TABLE `wp_woocommerce_shipping_zone_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_id` bigint(20) unsigned NOT NULL,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `location_id` (`location_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_locations`
#
INSERT INTO `wp_woocommerce_shipping_zone_locations` ( `location_id`, `zone_id`, `location_code`, `location_type`) VALUES
(1, 1, 'SE', 'country') ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zone_methods`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zone_methods`;


#
# Table structure of table `wp_woocommerce_shipping_zone_methods`
#

CREATE TABLE `wp_woocommerce_shipping_zone_methods` (
  `zone_id` bigint(20) unsigned NOT NULL,
  `instance_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `method_id` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `method_order` bigint(20) unsigned NOT NULL,
  `is_enabled` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`instance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zone_methods`
#
INSERT INTO `wp_woocommerce_shipping_zone_methods` ( `zone_id`, `instance_id`, `method_id`, `method_order`, `is_enabled`) VALUES
(1, 1, 'free_shipping', 1, 1),
(1, 2, 'flat_rate', 2, 1),
(1, 3, 'local_pickup', 3, 1) ;

#
# End of data contents of table `wp_woocommerce_shipping_zone_methods`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_shipping_zones`
#

DROP TABLE IF EXISTS `wp_woocommerce_shipping_zones`;


#
# Table structure of table `wp_woocommerce_shipping_zones`
#

CREATE TABLE `wp_woocommerce_shipping_zones` (
  `zone_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `zone_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `zone_order` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`zone_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_shipping_zones`
#
INSERT INTO `wp_woocommerce_shipping_zones` ( `zone_id`, `zone_name`, `zone_order`) VALUES
(1, 'Sweden', 0) ;

#
# End of data contents of table `wp_woocommerce_shipping_zones`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `location_code` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `tax_rate_id` bigint(20) unsigned NOT NULL,
  `location_type` varchar(40) COLLATE utf8mb4_unicode_520_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type_code` (`location_type`(10),`location_code`(20))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(2) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(8) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) unsigned NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) unsigned NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`),
  KEY `tax_rate_state` (`tax_rate_state`(2)),
  KEY `tax_rate_class` (`tax_rate_class`(10)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#
INSERT INTO `wp_woocommerce_tax_rates` ( `tax_rate_id`, `tax_rate_country`, `tax_rate_state`, `tax_rate`, `tax_rate_name`, `tax_rate_priority`, `tax_rate_compound`, `tax_rate_shipping`, `tax_rate_order`, `tax_rate_class`) VALUES
(1, 'SE', '', '25.0000', 'Moms', 1, 0, 1, 0, '') ;

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

